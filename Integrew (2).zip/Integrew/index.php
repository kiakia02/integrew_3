<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Integrew</title>
  <link href="https://fonts.googleapis.com/css2?family=Rubik+Bubbles&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">

  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap');
    .font-logo {
      font-family: 'Fredoka One', cursive;
    }
    body h1{
      color: #D55050;
      font-family: 'Rubik Bubbles', cursive;
    }
    body p{
      font-family: 'Open Sans', sans-serif;
      color: #A6A6A6;
      font-weight: bold;
    }
    body button{
      background-color:#D55050 ;
      font-family: 'Rubik Bubbles', cursive;
      word-spacing: 3px;
    }

  </style>
</head>

<body class="bg-white min-h-screen flex items-center justify-center p-6">
  <div class="flex flex-col items-center text-center space-y-5 w-full max-w-sm">

    <img src="foto/intro.png" class="w-52 mx-auto"/>

    <h1 class="text-4xl ">Integrew</h1>
    <p class="">Belajar integral dengan<br />penuh keseruan</p>

    <button onclick="window.location.href='login/login.php'" class="mt-6 text-white py-3 px-6 rounded-full shadow-lg hover:bg-rose-600 active:scale-95 transition" >
      MASUK KE AKUN
    </button>
  </div>
</body>
</html>
