<?php
session_start(); // Mulai session

// Hapus semua data session
$_SESSION = [];
session_unset();
session_destroy();

// Redirect ke halaman login
header("Location: ../login/login.php");
exit;
?>
