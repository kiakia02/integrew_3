<?php
include '../db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$result = mysqli_query($conn, "SELECT * FROM quizsoal WHERE id = $id");
$data = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul_quiz = mysqli_real_escape_string($conn, $_POST['judul_quiz']);
    $kelas = mysqli_real_escape_string($conn, $_POST['kelas']);
    $materi = mysqli_real_escape_string($conn, $_POST['materi']);
    $soal = mysqli_real_escape_string($conn, $_POST['soal']);
    $opsi_a = mysqli_real_escape_string($conn, $_POST['opsi_a']);
    $opsi_b = mysqli_real_escape_string($conn, $_POST['opsi_b']);
    $opsi_c = mysqli_real_escape_string($conn, $_POST['opsi_c']);
    $opsi_d = mysqli_real_escape_string($conn, $_POST['opsi_d']);
    $opsijawaban = mysqli_real_escape_string($conn, $_POST['opsijawaban']);
    $jawaban = mysqli_real_escape_string($conn, $_POST['jawaban']);

    $query = "UPDATE quizsoal SET 
        judul_quiz='$judul_quiz',
        kelas='$kelas',
        materi='$materi',
        soal='$soal',
        opsi_a='$opsi_a',
        opsi_b='$opsi_b',
        opsi_c='$opsi_c',
        opsi_d='$opsi_d',
        opsijawaban='$opsijawaban',
        jawaban='$jawaban'
        WHERE id=$id";

    if (mysqli_query($conn, $query)) {
        header("Location: daftarsoalquiz.php");
        exit;
    } else {
        echo "Gagal update soal: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Soal Quiz</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #fff5f5;
      padding: 30px;
    }

    .header-box {
      background-color: maroon;
      color: white;
      padding: 18px;
      border-radius: 20px;
      text-align: center;
      margin-bottom: 25px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .header-box h2 {
      margin: 0;
      font-size: 22px;
      font-weight: bold;
    }

    form {
      max-width: 500px;
      margin: auto;
    }

    .card {
      background-color: #f5f5f5;
      border-radius: 20px;
      padding: 18px;
      margin-bottom: 20px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }

    label {
      font-weight: bold;
      font-size: 15px;
      display: block;
      margin-bottom: 6px;
    }

    input[type="text"],
    select,
    textarea {
      width: 100%;
      border: none;
      background: transparent;
      border-bottom: 2px dotted #444;
      padding: 10px;
      font-size: 15px;
      outline: none;
    }

    textarea {
      resize: none;
    }

    .btn {
      width: 100%;
      background-color: #70c26f;
      border: 2px solid #48a748;
      padding: 12px;
      font-size: 18px;
      font-weight: bold;
      color: white;
      border-radius: 20px;
      cursor: pointer;
      transition: 0.3s;
    }

    .btn:hover {
      background-color: #60b15f;
    }

    .form-footer {
      text-align: center;
      margin-top: 30px;
    }
  </style>
</head>
<body>

<div class="header-box">
  <h2>✏️ Edit Soal Quiz</h2>
</div>

<form method="POST">
  <div class="card">
    <label>Judul Quiz</label>
    <input type="text" name="judul_quiz" value="<?= htmlspecialchars($data['judul_quiz']) ?>" required>
  </div>

  <div class="card">
    <label>Kelas</label>
    <select name="kelas" required>
      <option value="1 TRPL A" <?= $data['kelas'] === '1 TRPL A' ? 'selected' : '' ?>>1 TRPL A</option>
      <option value="1 TRPL B" <?= $data['kelas'] === '1 TRPL B' ? 'selected' : '' ?>>1 TRPL B</option>
    </select>
  </div>

  <div class="card">
  <label class="form-label">📚 Materi</label>
  <select name="materi" class="form-select" required>
    <option value="">-- Pilih Materi --</option>
    <option value="materi1" <?= ($data['materi'] == 'materi1') ? 'selected' : '' ?>>Materi 1</option>
    <option value="materi2" <?= ($data['materi'] == 'materi2') ? 'selected' : '' ?>>Materi 2</option>
    <option value="materi3" <?= ($data['materi'] == 'materi3') ? 'selected' : '' ?>>Materi 3</option>
    <option value="materi4" <?= ($data['materi'] == 'materi4') ? 'selected' : '' ?>>Materi 4</option>
    <option value="materi5" <?= ($data['materi'] == 'materi5') ? 'selected' : '' ?>>Materi 5</option>
    <option value="materi6" <?= ($data['materi'] == 'materi6') ? 'selected' : '' ?>>Materi 6</option>
  </select>
</div>

  <div class="card">
    <label>Soal (Teks)</label>
    <textarea name="soal" rows="3" required><?= htmlspecialchars($data['soal']) ?></textarea>
  </div>

  <div class="card">
    <label>Opsi A</label>
    <input type="text" name="opsi_a" value="<?= htmlspecialchars($data['opsi_a']) ?>" required>
    <label>Opsi B</label>
    <input type="text" name="opsi_b" value="<?= htmlspecialchars($data['opsi_b']) ?>" required>
    <label>Opsi C</label>
    <input type="text" name="opsi_c" value="<?= htmlspecialchars($data['opsi_c']) ?>" required>
    <label>Opsi D</label>
    <input type="text" name="opsi_d" value="<?= htmlspecialchars($data['opsi_d']) ?>" required>
  </div>

  <div class="card">
    <label>✅ Jawaban yang Benar</label>
    <select name="opsijawaban" required>
      <option value="">-- Pilih Jawaban yang Benar --</option>
      <option value="A" <?= $data['opsijawaban'] == 'A' ? 'selected' : '' ?>>A</option>
      <option value="B" <?= $data['opsijawaban'] == 'B' ? 'selected' : '' ?>>B</option>
      <option value="C" <?= $data['opsijawaban'] == 'C' ? 'selected' : '' ?>>C</option>
      <option value="D" <?= $data['opsijawaban'] == 'D' ? 'selected' : '' ?>>D</option>
    </select>
  </div>

  <div class="card">
    <label>Jawaban (Teks)</label>
    <textarea name="jawaban" rows="2" required><?= htmlspecialchars($data['jawaban']) ?></textarea>
  </div>

  <div class="form-footer">
    <button class="btn" type="submit">💾 SIMPAN</button>
  </div>
  <div class="form-footer">
      <a href="daftarsoalquiz.php" class="back-link" style="color:maroon;">← Kembali ke Daftar Quiz</a>
    </div>
</form>

</body>
</html>
