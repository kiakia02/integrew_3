<?php
include '../../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Ambil data input & bersihkan
        $materi = trim($_POST['materi']);
        $judul = trim($_POST['judul_latihan']);
        $kelas = trim($_POST['kelas']);
        $opsi_a = trim($_POST['opsi_a']);
        $opsi_b = trim($_POST['opsi_b']);
        $opsi_c = trim($_POST['opsi_c']);
        $opsi_d = trim($_POST['opsi_d']);
        $jawaban_benar = trim($_POST['opsijawaban']);
        $soal = trim($_POST['soal']);
        $jawaban = trim($_POST['jawaban']);

        // Validasi sederhana
        if (empty($judul) || empty($soal) || empty($jawaban) || empty($materi) || empty($kelas) || empty($jawaban_benar)) {
            throw new Exception("Semua field wajib diisi.");
        }

        // Query insert (tanpa jenis_soal)
        $stmt = mysqli_prepare($conn, 
            "INSERT INTO latihansoal 
            (judul_latihan, soal, opsi_a, opsi_b, opsi_c, opsi_d, jawaban, kelas, materi, opsijawaban)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        mysqli_stmt_bind_param($stmt, 'ssssssssss',
            $judul, $soal,
            $opsi_a, $opsi_b, $opsi_c, $opsi_d,
            $jawaban,
            $kelas, $materi, $jawaban_benar
        );

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Soal berhasil ditambahkan!'); window.location.href = '../daftarsoallatihan.php';</script>";
        } else {
            throw new Exception("Gagal insert ke database: " . mysqli_error($conn));
        }

    } catch (Exception $e) {
        echo "<script>alert('Terjadi kesalahan: " . addslashes($e->getMessage()) . "');</script>";
    }
}
?>
