<?php 
// db.php
$host = 'localhost';
$db   = 'dbintegrew';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Ambil data untuk kelas 1 TRPL B
$kelas = '1 TRPL B';
$stmt = $pdo->prepare("SELECT * FROM nilai WHERE kelas = ? ORDER BY tanggal DESC");
$stmt->execute([$kelas]);
$data = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1 TRPL B - Nilai</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #fff;
            padding: 20px;
            text-align: center;
        }

        .cloud {
            display: inline-block;
            padding: 10px 30px;
            border: 2px dashed #000;
            border-radius: 50px;
            font-size: 24px;
            font-weight: bold;
            background-color: #fff;
            margin-bottom: 20px;
        }

        .search-box {
            margin-bottom: 20px;
        }

        .search-box input {
            padding: 8px 15px;
            width: 250px;
            border-radius: 20px;
            border: 1px solid #ccc;
            outline: none;
            font-size: 14px;
        }

        .back-wrapper {
            display: flex;
            justify-content: flex-start;
            margin-bottom: 20px;
        }

        .btn-back {
            padding: 10px 20px;
            background-color: maroon;
            color: white;
            text-decoration: none;
            border-radius: 20px;
            font-size: 14px;
        }

        .btn-back:hover {
            background-color: #a30000;
        }

        .filter-section {
            margin-bottom: 20px;
        }

        .filter-btn {
            padding: 8px 15px;
            margin: 0 5px;
            border: none;
            border-radius: 20px;
            background-color: #ddd;
            cursor: pointer;
            font-size: 14px;
        }

        .filter-btn.active {
            background-color: maroon;
            color: white;
        }

        .table-wrapper {
            overflow-x: auto;
            width: 100%;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 10px;
            min-width: 600px;
        }

        th {
            background-color: #b03a3a;
            color: white;
            padding: 10px;
            border-radius: 20px 20px 0 0;
        }

        td {
            background-color: #e9e4e4;
            padding: 12px;
            border-radius: 20px;
            font-size: 16px;
        }

        .aksi-btn {
            padding: 5px 10px;
            margin: 0 2px;
            border: none;
            border-radius: 10px;
            font-size: 12px;
            cursor: pointer;
            color: white;
        }

        .btn-edit { background-color: #3498db; text-decoration:none;}
        .btn-edit:hover { background-color: #2980b9; }

        .btn-hapus { background-color: #d9534f; text-decoration:none;}
        .btn-hapus:hover { background-color: #c9302c; }
    </style>
</head>
<body>

    <div class="cloud">1 TRPL B</div>
    <div class="filter-section">
        <button class="filter-btn active" data-filter="all">Semua</button>
        <button class="filter-btn" data-filter="quiz">Quiz</button>
        <button class="filter-btn" data-filter="latihan">Latihan</button>
    </div>

    <div class="search-box">
        <input type="text" id="searchInput" placeholder="🔍 Cari Data..." onkeyup="filterTable()">
    </div>

    <div class="back-wrapper">
        <a href="../admin.php" class="btn-back">← Kembali ke Dashboard</a>
        <a href="download_b.php" class="btn-back" style="margin-left:10px; background-color: green;">⬇ Download Nilai</a>
    </div>

    <div class="table-wrapper">
        <table id="nilaiTable">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Jenis</th>
                    <th>Materi</th>
                    <th>Nilai</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($data as $i => $row): ?>
    <tr class="nilai-row" data-jenis="<?= htmlspecialchars($row['jenis']) ?>">
        <td><?= $i+1 ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= ucfirst(htmlspecialchars($row['jenis'])) ?></td>
        <td><?= htmlspecialchars($row['materi']) ?></td>
        <td><?= htmlspecialchars($row['skor']) ?></td>
        <td><?= date('d/m/Y H:i', strtotime($row['tanggal'])) ?></td>
        <td>
            <a class="aksi-btn btn-edit" href="edit_nilaib.php?id=<?= $row['id'] ?>">Edit</a>
            <a class="aksi-btn btn-hapus" href="hapus_nilaib.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus?');">Hapus</a>
        </td>
    </tr>
    <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
    // Filter pencarian
function filterTable() {
    const input = document.getElementById("searchInput").value.toLowerCase();
    const rows = document.querySelectorAll("#nilaiTable tbody tr");
    rows.forEach(row => {
        const rowText = Array.from(row.cells).map(cell => cell.textContent.toLowerCase()).join(" ");
        if (rowText.includes(input)) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
    });
}


    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelector('.filter-btn.active').classList.remove('active');
            this.classList.add('active');
            const filter = this.dataset.filter;
            document.querySelectorAll('.nilai-row').forEach(row => {
                if (filter === 'all' || row.dataset.jenis === filter) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    });
    </script>

</body>
</html>
