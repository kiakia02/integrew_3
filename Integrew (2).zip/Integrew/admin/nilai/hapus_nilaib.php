<?php
// hapus_nilaib.php

// Include koneksi database
$host = 'localhost';
$db   = 'dbintegrew';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
];
$pdo = new PDO($dsn, $user, $pass, $options);


// Cek apakah ada parameter id yang dikirim lewat URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query hapus data
    $stmt = $pdo->prepare("DELETE FROM nilai WHERE id = ?");
    $stmt->execute([$id]);

    // Setelah berhasil hapus, redirect kembali ke halaman utama TRPL B
    header("Location: nilaitrplb.php"); // Ganti 'trplb.php' jika nama file utamanya berbeda
    exit();
} else {
    // Jika tidak ada id, redirect juga
    header("Location: nilaitrplb.php");
    exit();
}
?>
