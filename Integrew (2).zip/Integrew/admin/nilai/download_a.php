<?php
header("Content-type: application/vnd.ms-word");
header("Content-Disposition: attachment; filename=Nilai 1 TRPL A.doc");

// Koneksi ke database
$host = 'localhost';
$db   = 'dbintegrew';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Ambil data kelas 1 TRPL A
$kelas = '1 TRPL A';
$stmt = $pdo->prepare("SELECT * FROM nilai WHERE kelas = ? ORDER BY tanggal DESC");
$stmt->execute([$kelas]);
$data = $stmt->fetchAll();
?>

<html>
<head>
    <meta charset="UTF-8">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th {
            background-color: maroon;
            color: white;
            padding: 8px;
            border: 1px solid #000;
        }
        td {
            padding: 8px;
            border: 1px solid #000;
        }
    </style>
</head>
<body>
    <h2>Nilai Kelas 1 TRPL A</h2>
    <table>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Jenis</th>
            <th>Materi</th>
            <th>Nilai</th>
            <th>Tanggal</th>
        </tr>
        <?php foreach ($data as $i => $row): ?>
        <tr>
            <td><?= $i+1 ?></td>
            <td><?= htmlspecialchars($row['nama']) ?></td>
            <td><?= ucfirst(htmlspecialchars($row['jenis'])) ?></td>
            <td><?= htmlspecialchars($row['materi']) ?></td>
            <td><?= htmlspecialchars($row['skor']) ?></td>
            <td><?= date('d/m/Y H:i', strtotime($row['tanggal'])) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
