<?php
// edit_nilai_trpla.php

$host = 'localhost';
$db   = 'dbintegrew';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    exit('Koneksi gagal: ' . $e->getMessage());
}

// Ambil data
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM nilai WHERE id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();

// Jika data tidak ditemukan
if (!$row) {
    exit('Data tidak ditemukan.');
}

// Daftar materi valid
$materi_list = ['materi1', 'materi2', 'materi3', 'materi4', 'materi5', 'materi6'];

// Proses update jika form dikirim
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama    = trim($_POST['nama']);
    $jenis   = $_POST['jenis'];
    $materi  = $_POST['materi'];
    $skor    = (int)$_POST['skor'];

    // Validasi sederhana
    if (
        $nama !== '' &&
        in_array($jenis, ['quiz', 'latihan']) &&
        in_array($materi, $materi_list) &&
        $skor >= 0 && $skor <= 100
    ) {
        $update = $pdo->prepare("UPDATE nilai SET nama = ?, jenis = ?, materi = ?, skor = ? WHERE id = ?");
        $update->execute([$nama, $jenis, $materi, $skor, $id]);
        header("Location: nilaitrpla.php");
        exit;
    } else {
        echo "<p style='color:red; text-align:center;'>Data tidak valid, periksa kembali!</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Nilai - 1 TRPL A</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #fff5f5;
      padding: 30px;
    }
    .header-box {
      background-color: maroon;
      color: white;
      padding: 18px;
      border-radius: 20px;
      text-align: center;
      margin-bottom: 25px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .header-box h2 {
      margin: 0;
      font-size: 22px;
      font-weight: bold;
    }
    form {
      max-width: 500px;
      margin: auto;
    }
    .card {
      background-color: #f5f5f5;
      border-radius: 20px;
      padding: 18px;
      margin-bottom: 20px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    label {
      font-weight: bold;
      font-size: 15px;
      display: block;
      margin-bottom: 6px;
    }
    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      border: none;
      background: transparent;
      border-bottom: 2px dotted #444;
      padding: 10px;
      font-size: 15px;
      outline: none;
    }
    .btn {
      width: 100%;
      background-color: #70c26f;
      border: 2px solid #48a748;
      padding: 12px;
      font-size: 18px;
      font-weight: bold;
      color: white;
      border-radius: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    .btn:hover {
      background-color: #60b15f;
    }
    .form-footer {
      text-align: center;
      margin-top: 30px;
    }
    .back-link {
      display: inline-block;
      margin-bottom: 20px;
      color: maroon;
      text-decoration: none;
      font-size: 14px;
    }
    .back-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="header-box">
    <h2>✏️ Edit Nilai - 1 TRPL A</h2>
  </div>

  <form method="POST">
    <div class="card">
      <label>Nama</label>
      <input type="text" name="nama" value="<?= htmlspecialchars($row['nama']) ?>" required>
    </div>

    <div class="card">
      <label>Jenis</label>
      <select name="jenis" required>
        <option value="">-- Pilih Jenis --</option>
        <option value="quiz" <?= $row['jenis'] === 'quiz' ? 'selected' : '' ?>>Quiz</option>
        <option value="latihan" <?= $row['jenis'] === 'latihan' ? 'selected' : '' ?>>Latihan</option>
      </select>
    </div>

    <div class="card">
      <label>Materi</label>
      <select name="materi" required>
        <option value="">-- Pilih Materi --</option>
        <?php foreach ($materi_list as $m): ?>
          <option value="<?= $m ?>" <?= $row['materi'] === $m ? 'selected' : '' ?>><?= ucfirst(str_replace('materi','Materi ', $m)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="card">
      <label>Nilai</label>
      <input type="number" name="skor" value="<?= htmlspecialchars($row['skor']) ?>" min="0" max="100" required>
    </div>

    <div class="form-footer">
      <button class="btn" type="submit">💾 SIMPAN PERUBAHAN</button>
    </div>
    <div class="form-footer">
      <a href="nilaitrpla.php" class="back-link">← Kembali ke Nilai 1 TRPL A</a>
    </div>
  </form>

</body>
</html>
