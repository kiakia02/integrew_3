<?php
include '../db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // pastikan id adalah integer

    try {
        // Query delete
        $stmt = mysqli_prepare($conn, "DELETE FROM quizsoal WHERE id = ?");
        mysqli_stmt_bind_param($stmt, 'i', $id);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Soal berhasil dihapus!'); window.location.href = 'daftarsoalquiz.php';</script>";
        } else {
            throw new Exception("Gagal menghapus soal: " . mysqli_error($conn));
        }

    } catch (Exception $e) {
        echo "<script>alert('Terjadi kesalahan: " . addslashes($e->getMessage()) . "');</script>";
    }

} else {
    echo "<script>alert('ID soal tidak ditemukan.'); window.location.href = 'daftarsoalquiz.php';</script>";
}
?>
