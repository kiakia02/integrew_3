<?php include '../db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daftar Soal Latihan</title>
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #fef5f5;
      padding: 20px;
      margin: 0;
    }

    .header {
      text-align: center;
      background-color: maroon;
      color: white;
      padding: 15px 20px;
      border-radius: 15px;
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 20px;
    }

    .search-container {
      text-align: center;
      margin-bottom: 20px;
    }

    .search-container input {
      width: 100%;
      max-width: 300px;
      padding: 12px 20px;
      border-radius: 25px;
      border: 1px solid #ccc;
      outline: none;
      font-size: 14px;
      background-image: url('https://cdn-icons-png.flaticon.com/512/622/622669.png');
      background-size: 20px;
      background-repeat: no-repeat;
      background-position: 10px center;
      padding-left: 40px;
    }

    .btn-group {
      text-align: center;
      margin-bottom: 30px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 25px;
      font-size: 14px;
      margin: 5px;
      cursor: pointer;
      transition: all 0.3s ease;
      text-decoration: none;
      display: inline-block;
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
    }

    /* Desktop Table */
    .table-container {
      overflow-x: auto;
      background-color: white;
      border-radius: 20px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 800px;
    }

    thead th {
      background-color: maroon;
      color: white;
      padding: 14px;
      text-align: center;
      font-size: 16px;
      position: sticky;
      top: 0;
      z-index: 10;
    }

    tbody td {
      padding: 14px;
      text-align: center;
      border-bottom: 1px solid #f2f2f2;
      font-size: 15px;
    }

    tbody tr:hover {
      background-color: #f9f9f9;
    }

    img {
      max-width: 120px;
      border-radius: 10px;
      transition: 0.3s;
    }

    img:hover {
      transform: scale(1.05);
    }

    .actions button {
      display: block;
      width: 80px;
      margin: 4px auto;
      padding: 8px;
      border: none;
      border-radius: 20px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .btn-edit {
      background-color: #2980b9;
      color: white;
    }

    .btn-delete {
      background-color: #c0392b;
      color: white;
    }

    .btn-edit:hover {
      background-color: #2471a3;
      transform: translateY(-1px);
    }

    .btn-delete:hover {
      background-color: #a93226;
      transform: translateY(-1px);
    }

    /* Mobile Card Layout */
    .mobile-cards {
      display: none;
    }

    .card {
      background: white;
      border-radius: 15px;
      padding: 20px;
      margin-bottom: 15px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .card-header {
      background: maroon;
      color: white;
      padding: 10px 15px;
      margin: -20px -20px 15px -20px;
      border-radius: 15px 15px 0 0;
      font-weight: bold;
      text-align: center;
    }

    .card-content {
      display: grid;
      gap: 10px;
    }

    .card-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding: 8px 0;
      border-bottom: 1px solid #f0f0f0;
    }

    .card-row:last-child {
      border-bottom: none;
    }

    .card-label {
      font-weight: bold;
      color: maroon;
      min-width: 100px;
      flex-shrink: 0;
    }

    .card-value {
      text-align: right;
      flex: 1;
      margin-left: 15px;
      word-wrap: break-word;
    }

    .card-actions {
      display: flex;
      gap: 10px;
      justify-content: center;
      margin-top: 15px;
      padding-top: 15px;
      border-top: 2px solid #f0f0f0;
    }

    .card-actions button {
      flex: 1;
      max-width: 100px;
      padding: 10px;
      border: none;
      border-radius: 20px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .card-actions .btn-edit {
      background-color: #2980b9;
      color: white;
    }

    .card-actions .btn-delete {
      background-color: #c0392b;
      color: white;
    }

    .card-actions .btn-edit:hover {
      background-color: #2471a3;
      transform: translateY(-1px);
    }

    .card-actions .btn-delete:hover {
      background-color: #a93226;
      transform: translateY(-1px);
    }

    /* Responsive Breakpoints */
    @media screen and (max-width: 768px) {
      body {
        padding: 15px;
      }

      .header {
        font-size: 16px;
        padding: 12px 15px;
      }

      .search-container input {
        font-size: 16px; /* Prevent zoom on iOS */
      }

      .btn-nav {
        padding: 10px 20px;
        font-size: 13px;
      }

      /* Hide table, show cards */
      .table-container {
        display: none;
      }

      .mobile-cards {
        display: block;
      }
    }

    @media screen and (max-width: 480px) {
      body {
        padding: 10px;
      }

      .header {
        font-size: 14px;
        padding: 10px;
        border-radius: 10px;
      }

      .search-container input {
        padding: 10px 35px 10px 35px;
        background-size: 16px;
        background-position: 8px center;
      }

      .btn-nav {
        padding: 8px 16px;
        font-size: 12px;
      }

      .card {
        padding: 15px;
        border-radius: 10px;
      }

      .card-header {
        margin: -15px -15px 10px -15px;
        border-radius: 10px 10px 0 0;
        font-size: 14px;
      }

      .card-label {
        font-size: 13px;
        min-width: 80px;
      }

      .card-value {
        font-size: 13px;
      }

      .card-actions button {
        font-size: 12px;
        padding: 8px;
      }
    }

    /* Landscape phone */
    @media screen and (max-width: 896px) and (orientation: landscape) {
      .table-container {
        display: block;
      }
      
      .mobile-cards {
        display: none;
      }
    }
  </style>
</head>
<body>

  <div class="header">Daftar Soal Latihan</div>

  <div class="search-container">
    <input type="text" placeholder="🔍 Cari soal atau judul..." id="searchInput">
  </div>

  <div class="btn-group">
    <button class="btn-nav" onclick="window.location.href='admin.php'">← Kembali ke Admin</button>
  </div>

  <!-- Desktop Table View -->
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>Judul Latihan</th>
          <th>Materi</th>
          <th>Soal</th>
          <th>Opsi Jawaban Benar</th>
          <th>Jawaban</th>
          <th>Kelas</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody id="tableBody">
        <?php
        $no = 1;
        $result = mysqli_query($conn, "SELECT * FROM latihansoal ORDER BY id DESC");
        while ($row = mysqli_fetch_assoc($result)) {
          echo "<tr>
            <td>{$no}</td>
            <td>" . htmlspecialchars($row['judul_latihan']) . "</td>
            <td>" . htmlspecialchars($row['materi']) . "</td>
            <td>" . htmlspecialchars($row['soal']) . "</td>
            <td>" . htmlspecialchars($row['opsijawaban']) . "</td>
            <td>" . htmlspecialchars($row['jawaban']) . "</td>
            <td>" . htmlspecialchars($row['kelas']) . "</td>
            <td class='actions'>
              <form method='GET' action='editsoallatihan.php'>
                <input type='hidden' name='id' value='{$row['id']}'>
                <button type='submit' class='btn-edit'>Edit</button>
              </form>
              <form method='GET' action='hapussoal.php' onsubmit=\"return confirm('Yakin ingin menghapus soal ini?')\">
                <input type='hidden' name='id' value='{$row['id']}'>
                <button type='submit' class='btn-delete'>Hapus</button>
              </form>
            </td>
          </tr>";
          $no++;
        }
        ?>
      </tbody>
    </table>
  </div>

  <!-- Mobile Card View -->
  <div class="mobile-cards" id="mobileCards">
    <?php
    $no = 1;
    mysqli_data_seek($result, 0); // Reset pointer
    while ($row = mysqli_fetch_assoc($result)) {
      echo "<div class='card'>
        <div class='card-header'>Soal #{$no}</div>
        <div class='card-content'>
          <div class='card-row'>
            <span class='card-label'>Judul:</span>
            <span class='card-value'>" . htmlspecialchars($row['judul_latihan']) . "</span>
          </div>
          <div class='card-row'>
            <span class='card-label'>Materi:</span>
            <span class='card-value'>" . htmlspecialchars($row['materi']) . "</span>
          </div>
          <div class='card-row'>
            <span class='card-label'>Soal:</span>
            <span class='card-value'>" . htmlspecialchars(substr($row['soal'], 0, 100)) . (strlen($row['soal']) > 100 ? '...' : '') . "</span>
          </div>
          <div class='card-row'>
            <span class='card-label'>Opsi:</span>
            <span class='card-value'>" . htmlspecialchars($row['opsijawaban']) . "</span>
          </div>
          <div class='card-row'>
            <span class='card-label'>Jawaban:</span>
            <span class='card-value'>" . htmlspecialchars($row['jawaban']) . "</span>
          </div>
          <div class='card-row'>
            <span class='card-label'>Kelas:</span>
            <span class='card-value'>" . htmlspecialchars($row['kelas']) . "</span>
          </div>
        </div>
        <div class='card-actions'>
          <form method='GET' action='editsoallatihan.php' style='flex: 1; max-width: 100px;'>
            <input type='hidden' name='id' value='{$row['id']}'>
            <button type='submit' class='btn-edit'>Edit</button>
          </form>
          <form method='GET' action='hapussoal.php' onsubmit=\"return confirm('Yakin ingin menghapus soal ini?')\" style='flex: 1; max-width: 100px;'>
            <input type='hidden' name='id' value='{$row['id']}'>
            <button type='submit' class='btn-delete'>Hapus</button>
          </form>
        </div>
      </div>";
      $no++;
    }
    ?>
  </div>

  <script>
    // Simple search functionality
    document.getElementById('searchInput').addEventListener('input', function() {
      const searchTerm = this.value.toLowerCase();
      const tableRows = document.querySelectorAll('#tableBody tr');
      const mobileCards = document.querySelectorAll('.card');
      
      // Filter table rows
      tableRows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
      });
      
      // Filter mobile cards
      mobileCards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(searchTerm) ? '' : 'none';
      });
    });
  </script>

</body>
</html>