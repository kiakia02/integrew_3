<!DOCTYPE html>
<html lang="id">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Admin</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f9f9f9;
    }

    .topbar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 20px 30px;
    }

    .topbar .username {
      margin-right: 10px;
      font-weight: bold;
    }

    .avatar {
      width: 40px;
      height: 40px;
      background-color: #eee;
      border-radius: 50%;
      background-image: url('https://cdn-icons-png.flaticon.com/512/3135/3135715.png');
      background-size: cover;
      background-position: center;
    }

    .section {
      background-color: #f1f1f1;
      margin: 20px 40px;
      padding: 30px;
      border-radius: 20px;
    }

    .section h2 {
      margin-bottom: 20px;
    }

    .card-container {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
    }

    .card {
      width: 120px;
      height: 120px;
      background-color: white;
      border: 3px solid maroon;
      border-radius: 30px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-weight: bold;
      color: maroon;
      text-align: center;
      text-decoration: none;
      transition: transform 0.3s;
      cursor: pointer;
    }

    .card:hover {
      transform: scale(1.05);
    }

    .tambah-soal {
      font-size: 28px;
    }

    .logout-btn {
      margin-left: 20px;
      padding: 6px 14px;
      background-color: #d9534f;
      color: white;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
    }

    .logout-btn:hover {
      background-color: #c9302c;
    }

    .footer-flowers {
      width: 100%;
      height: 100px;
      background-image: url('https://png.pngtree.com/png-clipart/20230428/original/pngtree-spring-flowers-grass-border-design-png-image_9108605.png');
      background-repeat: repeat-x;
      background-size: contain;
      background-position: bottom;
      margin-top: 60px;
    }

    /* Modal Overlay */
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(8px);
      display: none;
      justify-content: center;
      align-items: center;
      z-index: 1000;
      animation: fadeIn 0.3s ease;
    }

    .modal-overlay.show {
      display: flex;
    }

    /* Modal Container */
    .modal-container {
      background: white;
      border-radius: 20px;
      padding: 40px;
      max-width: 500px;
      width: 90%;
      position: relative;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      transform: translateY(-50px);
      animation: modalSlideIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
    }

    /* Modal Header */
    .modal-header {
      text-align: center;
      margin-bottom: 30px;
    }

    .modal-icon {
      width: 80px;
      height: 80px;
      background: linear-gradient(135deg, #800000, #a52a2a);
      border-radius: 50%;
      margin: 0 auto 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 36px;
      color: white;
      animation: bounce 0.6s ease-in-out;
    }

    .modal-title {
      font-size: 24px;
      font-weight: bold;
      color: #333;
      margin-bottom: 10px;
    }

    .modal-subtitle {
      font-size: 16px;
      color: #666;
      line-height: 1.5;
    }

    /* Modal Content */
    .modal-content {
      text-align: center;
      margin-bottom: 30px;
    }

    .option-card {
      background: linear-gradient(135deg, #f8f9fa, #e9ecef);
      border: 3px solid transparent;
      border-radius: 15px;
      padding: 25px;
      margin: 15px 0;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }

    .option-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
      transition: left 0.5s;
    }

    .option-card:hover::before {
      left: 100%;
    }

    .option-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 30px rgba(128, 0, 0, 0.2);
      border-color: maroon;
    }

    .option-card.latihan {
      background: linear-gradient(135deg, #e3f2fd, #bbdefb);
    }

    .option-card.latihan:hover {
      border-color: #2196f3;
      box-shadow: 0 15px 30px rgba(33, 150, 243, 0.3);
    }

    .option-card.kuis {
      background: linear-gradient(135deg, #fff3e0, #ffcc02);
    }

    .option-card.kuis:hover {
      border-color: #ff9800;
      box-shadow: 0 15px 30px rgba(255, 152, 0, 0.3);
    }

    .option-icon {
      font-size: 48px;
      margin-bottom: 15px;
      display: block;
    }

    .option-title {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 8px;
      color: #333;
    }

    .option-description {
      font-size: 14px;
      color: #666;
      line-height: 1.4;
    }

    /* Modal Footer */
    .modal-footer {
      text-align: center;
      border-top: 1px solid #eee;
      padding-top: 20px;
    }

    .btn-cancel {
      background: #6c757d;
      color: white;
      border: none;
      border-radius: 12px;
      padding: 12px 30px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .btn-cancel:hover {
      background: #5a6268;
      transform: translateY(-2px);
    }

    /* Animations */
    @keyframes fadeIn {
      from {
        opacity: 0;
      }

      to {
        opacity: 1;
      }
    }

    @keyframes modalSlideIn {
      from {
        transform: scale(0.8) translateY(-100px);
        opacity: 0;
      }

      to {
        transform: scale(1) translateY(0);
        opacity: 1;
      }
    }

    @keyframes bounce {

      0%,
      20%,
      50%,
      80%,
      100% {
        transform: translateY(0);
      }

      40% {
        transform: translateY(-10px);
      }

      60% {
        transform: translateY(-5px);
      }
    }

    /* Responsive */
    @media(max-width: 768px) {
      .card-container {
        justify-content: center;
      }

      .modal-container {
        padding: 30px 20px;
        margin: 20px;
      }

      .option-card {
        padding: 20px;
      }

      .option-icon {
        font-size: 40px;
      }
    }

    @media screen and (max-width: 600px) {
      .card-container {
        justify-content: flex-start;
      }

      .card {
        width: 100%;
        max-width: 300px;
        height: auto;
        padding: 15px 10px;
        font-size: 16px;
        margin: 0 auto;
        text-align: center;
      }

      .tambah-soal {
        font-size: 24px;
      }

      .option-card {
        padding: 20px;
      }

      .option-title {
        font-size: 18px;
      }

      .option-description {
        font-size: 14px;
      }

      .modal-container {
        width: 95%;
        padding: 25px;
      }

      .modal-icon {
        width: 60px;
        height: 60px;
        font-size: 30px;
      }

      .modal-title {
        font-size: 20px;
      }

      .modal-subtitle {
        font-size: 14px;
      }
    }

    @media screen and (max-width: 390px) {
      .modal-container {
        width: 92%;
        padding: 16px;
        border-radius: 14px;
        max-height: 90vh;
        overflow-y: auto;
      }

      .modal-header {
        margin-bottom: 20px;
      }

      .modal-icon {
        width: 40px;
        height: 40px;
        font-size: 24px;
      }

      .modal-title {
        font-size: 16px;
      }

      .modal-subtitle {
        font-size: 12px;
      }

      .option-card {
        padding: 16px 12px;
        margin: 10px 0;
      }

      .option-icon {
        font-size: 24px;
      }

      .option-title {
        font-size: 14px;
      }

      .option-description {
        font-size: 11px;
      }

      .btn-cancel {
        font-size: 13px;
        padding: 8px 20px;
      }
    }
  </style>
</head>

<body>
  <!-- Topbar -->
  <div class="topbar">
    <span class="username">Admin User</span>
    <div class="avatar"></div>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>

  <!-- Soal & Quiz -->
  <div class="section">
    <h2>Soal & Quiz</h2>
    <div class="card-container" style="gap: 32px; justify-content: flex-start;">
      <div class="card" onclick="showSoalOption()" style="background: linear-gradient(135deg, #e3f2fd, #fff);">
        <div style="display: flex; flex-direction: column; align-items: center;">
          <div class="tambah-soal" style="font-size: 36px; margin-bottom: 8px;">✚</div>
          <span style="font-size: 17px; font-weight: 600;">Tambah Soal</span>
        </div>
      </div>
      <div class="card" onclick="window.location.href='daftarsoallatihan.php'" style="background: linear-gradient(135deg, #fff3e0, #fff);">
        <div style="display: flex; flex-direction: column; align-items: center;">
          <div class="tambah-soal" style="font-size: 36px; margin-bottom: 8px;">📄</div>
          <span style="font-size: 17px; font-weight: 600;">Lihat Soal Latihan</span>
        </div>
      </div>
      <div class="card" onclick="window.location.href='daftarsoalquiz.php'" style="background: linear-gradient(135deg, #fff3e0, #fff);">
        <div style="display: flex; flex-direction: column; align-items: center;">
          <div class="tambah-soal" style="font-size: 36px; margin-bottom: 8px;">📄</div>
          <span style="font-size: 17px; font-weight: 600;">Lihat Soal Quiz</span>
        </div>
      </div>
    </div>
    </div>
  </div>

   
  </div>

  <!-- Daftar Nilai -->
  <div class="section">
    <h2>Daftar Nilai</h2>
    <div class="card-container">
      <a href="./nilai/nilaitrpla.php?kelas=1 TRPL B" class="card">1 TRPL A</a>
      <a href="./nilai/nilaitrplb.php?kelas=1 TRPL A" class="card">1 TRPL B</a>
    </div>
  </div>

  <!-- Manajemen User -->
  <div class="section">
    <h2>Manajemen User</h2>
    <div class="card-container">
      <a href="user/kelas.php?tipe=mahasiswa" class="card">MAHASISWA</a>
    </div>
  </div>

  <!-- Modal Konfirmasi -->
  <div class="modal-overlay" id="modalOverlay">
    <div class="modal-container">
      <div class="modal-header">
        <div class="modal-icon">📚</div>
        <div class="modal-title">Pilih Jenis Soal</div>
        <div class="modal-subtitle">Silakan pilih jenis soal yang ingin Anda buat</div>
      </div>

      <div class="modal-content">
        <div class="option-card latihan" onclick="selectOption('latihan')">
          <span class="option-icon">✏️</span>
          <div class="option-title">Soal Latihan</div>
          <div class="option-description">Buat soal untuk latihan siswa dengan feedback langsung</div>
        </div>

        <div class="option-card kuis" onclick="selectOption('kuis')">
          <span class="option-icon">🏆</span>
          <div class="option-title">Soal Kuis</div>
          <div class="option-description">Buat soal kuis untuk evaluasi dengan penilaian</div>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn-cancel" onclick="closeModal()">Batal</button>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <div class="footer-flowers"></div>

  <script>
    function showSoalOption() {
      const modal = document.getElementById('modalOverlay');
      modal.classList.add('show');
      document.body.style.overflow = 'hidden';
    }

    function closeModal() {
      const modal = document.getElementById('modalOverlay');
      modal.classList.remove('show');
      document.body.style.overflow = 'auto';
    }

    function selectOption(type) {
      closeModal();

      // Add a nice loading effect
      const loadingOverlay = document.createElement('div');
      loadingOverlay.style.cssText = `
        padding: 20px; text-align: center;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(128, 0, 0, 0.9);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 2000;
        color: white;
        font-size: 18px;
        font-weight: bold;
      `;
      loadingOverlay.innerHTML = `
  <div style="text-align: center;">
    <div style="font-size: 36px; margin-bottom: 16px; animation: spin 1s linear infinite;">⚙️</div>
    <div style="font-size: 16px;">Memuat halaman...</div>
  </div>
`;


      document.body.appendChild(loadingOverlay);

      // Simulate loading then redirect
      setTimeout(() => {
        if (type === 'latihan') {
          window.location.href = "./latihan/tambahlatihansoal.php";
        } else {
          window.location.href = "./quiz/tambahsoal.php";
        }
      }, 1000);
    }

    // Close modal when clicking outside
    document.getElementById('modalOverlay').addEventListener('click', function(e) {
      if (e.target === this) {
        closeModal();
      }
    });

    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        closeModal();
      }
    });
  </script>
</body>

</html>