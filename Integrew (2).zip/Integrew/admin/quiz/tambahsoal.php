<!-- tambahsoal.php -->

<!DOCTYPE html>
<html lang="id">
<head>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Soal Quiz</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      max-width: 900px;
      margin: 0 auto;
      background: rgba(255, 255, 255, 0.95);
      border-radius: 30px;
      backdrop-filter: blur(20px);
      box-shadow: 0 30px 80px rgba(0, 0, 0, 0.2);
      overflow: hidden;
      animation: slideUp 0.8s ease;
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .header {
      background: linear-gradient(135deg, #800000, #a52a2a);
      color: white;
      padding: 40px;
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .header::before {
      content: '';
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
      animation: rotate 20s linear infinite;
    }

    @keyframes rotate {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    .header h2 {
      font-size: 32px;
      font-weight: 700;
      margin-bottom: 10px;
      position: relative;
      z-index: 1;
    }

    .header p {
      font-size: 16px;
      opacity: 0.9;
      position: relative;
      z-index: 1;
    }

    .form-container {
      padding: 40px;
    }

    .form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
      margin-bottom: 30px;
    }

    .form-group {
      background: #f8f9ff;
      border: 2px solid transparent;
      border-radius: 20px;
      padding: 25px;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }

    .form-group::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(128, 0, 0, 0.05), transparent);
      transition: left 0.6s;
    }

    .form-group:hover::before {
      left: 100%;
    }

    .form-group:hover {
      transform: translateY(-5px);
      border-color: #800000;
      box-shadow: 0 15px 40px rgba(128, 0, 0, 0.1);
    }

    .form-group.full-width {
      grid-column: 1 / -1;
    }

    .form-label {
      display: block;
      font-weight: 600;
      color: #333;
      margin-bottom: 12px;
      font-size: 16px;
      position: relative;
    }

    .form-label::before {
      content: '';
      position: absolute;
      left: -20px;
      top: 50%;
      transform: translateY(-50%);
      width: 4px;
      height: 20px;
      background: linear-gradient(135deg, #800000, #a52a2a);
      border-radius: 2px;
    }

    .form-input,
    .form-select,
    .form-textarea {
      width: 100%;
      border: 2px solid #e1e5e9;
      background: white;
      border-radius: 12px;
      padding: 15px 20px;
      font-size: 16px;
      transition: all 0.3s ease;
      font-family: inherit;
    }

    .form-input:focus,
    .form-select:focus,
    .form-textarea:focus {
      outline: none;
      border-color: #800000;
      box-shadow: 0 0 20px rgba(128, 0, 0, 0.1);
      transform: scale(1.02);
    }

    .form-textarea {
      resize: vertical;
      min-height: 120px;
    }

    .file-input-wrapper {
      position: relative;
      display: inline-block;
      width: 100%;
    }

    .file-input {
      position: absolute;
      opacity: 0;
      width: 100%;
      height: 100%;
      cursor: pointer;
    }

    .file-input-display {
      background: linear-gradient(135deg, #667eea, #764ba2);
      color: white;
      padding: 15px 20px;
      border-radius: 12px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: 600;
    }

    .file-input-display:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
    }

    .options-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-top: 15px;
    }

    .option-input {
      position: relative;
    }

    .option-input input {
      padding-left: 50px;
    }

    .option-label {
      position: absolute;
      left: 20px;
      top: 50%;
      transform: translateY(-50%);
      background: linear-gradient(135deg, #800000, #a52a2a);
      color: white;
      width: 25px;
      height: 25px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 14px;
    }

    .toggle-section {
      margin-top: 20px;
      padding: 20px;
      background: rgba(128, 0, 0, 0.05);
      border-radius: 15px;
      border-left: 4px solid #800000;
    }

    .submit-section {
      text-align: center;
      padding: 30px 0;
      border-top: 2px solid #f0f0f0;
      margin-top: 30px;
    }

    .btn-submit {
      background: linear-gradient(135deg, #4CAF50, #45a049);
      color: white;
      border: none;
      padding: 18px 60px;
      font-size: 18px;
      font-weight: 700;
      border-radius: 50px;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 8px 25px rgba(76, 175, 80, 0.3);
      position: relative;
      overflow: hidden;
    }

    .btn-submit::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
      transition: left 0.6s;
    }

    .btn-submit:hover::before {
      left: 100%;
    }

    .btn-submit:hover {
      transform: translateY(-3px);
      box-shadow: 0 15px 40px rgba(76, 175, 80, 0.4);
    }

    .btn-submit:active {
      transform: translateY(-1px);
    }

    .icon {
      margin-right: 8px;
      font-size: 18px;
    }

    .hidden {
      display: none;
    }

    .fade-in {
      animation: fadeIn 0.5s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

     .back-btn {
  display: inline-block;
  background: rgba(255, 80, 80, 0.2);
  color: black;
  border: 2px solid rgba(240, 76, 76, 0.3);
  border-radius: 50px;
  padding: 12px 24px;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s ease;

  margin-top: 20px;
}
.back-btn:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: translateY(-2px);
}


    /* Success animation */
    .success-check {
      display: none;
      color: #4CAF50;
      font-size: 24px;
      margin-left: 10px;
      animation: checkmark 0.6s ease;
    }

    @keyframes checkmark {
      0% { transform: scale(0); }
      50% { transform: scale(1.3); }
      100% { transform: scale(1); }
    }

/* Responsif untuk handphone kecil */
@media (max-width: 480px) {
  body {
    padding: 10px;
  }

  .container {
    border-radius: 20px;
  }

  .header {
    padding: 20px 10px;
  }

  .header h2 {
    font-size: 20px;
  }

  .header p {
    font-size: 14px;
  }

  .form-container {
    padding: 15px;
  }

  .form-label {
    font-size: 14px;
    margin-bottom: 8px;
  }

  .form-input,
  .form-select,
  .form-textarea {
    font-size: 14px;
    padding: 12px 15px;
  }

  .form-grid {
    grid-template-columns: 1fr;
    gap: 15px;
  }

  .options-grid {
    grid-template-columns: 1fr;
    gap: 10px;
  }

  .btn-submit {
    padding: 14px 30px;
    font-size: 16px;
  }

  .back-btn {
    margin-top: 15px;
    padding: 10px 18px;
    font-size: 14px;
  }

  .option-label {
    width: 22px;
    height: 22px;
    font-size: 12px;
    left: 15px;
  }

  .option-input input {
    padding-left: 45px;
  }

  .file-input-display {
    font-size: 14px;
    padding: 12px 15px;
  }
}

  </style>
</head>
<body>
<div class="container">
  <div class="header">
    <h2>📝 Tambah Soal Quiz</h2>
    <p>Buat soal quiz yang menarik untuk siswa</p>
  </div>

  <div class="form-container">
    <form method="POST" action="prosestambahsoal.php" enctype="multipart/form-data" id="quizForm">
      <div class="form-grid">
        <div class="form-group">
          <label class="form-label">🎯 Judul Quiz</label>
          <input type="text" name="judul_quiz" class="form-input" placeholder="Masukkan judul quiz..." required>
        </div>

        <div class="form-group">
          <label class="form-label">🏫 Kelas</label>
          <select name="kelas" class="form-select" required>
            <option value="">-- Pilih Kelas --</option>
            <option value="1 TRPL A">1 TRPL A</option>
            <option value="1 TRPL B">1 TRPL B</option>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">📚 Materi</label>
          <select name="materi" class="form-select" required>
            <option value="">-- Pilih Materi --</option>
            <option value="materi1">Materi 1</option>
            <option value="materi2">Materi 2</option>
            <option value="materi3">Materi 3</option>
            <option value="materi4">Materi 4</option>
            <option value="materi5">Materi 5</option>
            <option value="materi6">Materi 6</option>
          </select>
        </div>
      </div>

      <div class="form-group full-width">
        <label class="form-label">❓ Soal</label>
        <textarea name="soal" class="form-textarea" placeholder="Masukkan pertanyaan soal di sini..." rows="4" required></textarea>
      </div>

      <div class="form-group full-width">
        <label class="form-label">🔤 Pilihan Jawaban</label>
        <div class="options-grid">
          <div class="option-input">
            <span class="option-label">A</span>
            <input type="text" name="opsi_a" class="form-input" placeholder="Opsi A" required>
          </div>
          <div class="option-input">
            <span class="option-label">B</span>
            <input type="text" name="opsi_b" class="form-input" placeholder="Opsi B" required>
          </div>
          <div class="option-input">
            <span class="option-label">C</span>
            <input type="text" name="opsi_c" class="form-input" placeholder="Opsi C" required>
          </div>
          <div class="option-input">
            <span class="option-label">D</span>
            <input type="text" name="opsi_d" class="form-input" placeholder="Opsi D" required>
          </div>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">✅ Jawaban yang Benar</label>
        <select name="opsijawaban" class="form-select" required>
          <option value="">-- Pilih Jawaban yang Benar --</option>
          <option value="A">A</option>
          <option value="B">B</option>
          <option value="C">C</option>
          <option value="D">D</option>
        </select>
      </div>

      <div class="form-group full-width">
        <label class="form-label">💭 Penjelasan Jawaban</label>
        <textarea name="jawaban" class="form-textarea" placeholder="Berikan penjelasan mengapa jawaban ini benar..." rows="3" required></textarea>
      </div>

      <div class="submit-section">
        <button type="submit" class="btn-submit">
          <span class="icon">💾</span>
          SIMPAN SOAL
          <span class="success-check" id="successCheck">✓</span>
        </button>
        <a href="../admin.php" class="back-btn">← Kembali</a>
      </div>
    </form>
  </div>
</div>
      </form>
    </div>
  </div>

<script>
  // Form submission animation
  document.getElementById('quizForm').addEventListener('submit', function(e) {
    const submitBtn = document.querySelector('.btn-submit');
    const successCheck = document.getElementById('successCheck');

    submitBtn.style.transform = 'scale(0.95)';
    successCheck.style.display = 'inline';

    setTimeout(() => {
      submitBtn.style.transform = 'scale(1)';
    }, 200);
  });

  // Tambahkan efek animasi ke form-group saat load
  const formGroups = document.querySelectorAll('.form-group');
  formGroups.forEach((group, index) => {
    group.style.animationDelay = `${index * 0.1}s`;
    group.classList.add('fade-in');
  });

  // Animasi scale untuk input saat focus/blur
  const inputs = document.querySelectorAll('.form-input, .form-textarea');
  inputs.forEach(input => {
    input.addEventListener('focus', function() {
      this.style.transform = 'scale(1.02)';
    });
    input.addEventListener('blur', function() {
      this.style.transform = 'scale(1)';
    });
  });
</script>

</body>
</html>