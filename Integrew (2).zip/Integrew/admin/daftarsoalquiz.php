<?php include '../db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Daftar Soal Quiz</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #fef5f5;
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .header {
      text-align: center;
      background-color: maroon;
      color: white;
      padding: 20px;
      border-radius: 15px;
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 20px;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.2);
    }

    .search-container {
      text-align: center;
      margin-bottom: 20px;
    }

    .search-container input {
      width: 100%;
      max-width: 400px;
      padding: 15px 20px;
      border-radius: 25px;
      border: 1px solid #ccc;
      outline: none;
      font-size: 16px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      background: white;
    }

    .search-container input::placeholder {
      color: #999;
    }

    .btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }

    /* Desktop Table */
    .table-container {
      background: white;
      border-radius: 15px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
      overflow: hidden;
      display: block;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    thead th {
      background-color: maroon;
      color: white;
      padding: 15px;
      text-align: center;
      font-size: 14px;
      font-weight: 600;
    }

    tbody td {
      padding: 15px;
      text-align: center;
      border-bottom: 1px solid #f0f0f0;
      font-size: 14px;
      vertical-align: middle;
    }

    tbody tr:hover {
      background-color: #fdf2f2;
    }

    .actions {
      display: flex;
      gap: 8px;
      justify-content: center;
      align-items: center;
    }

    .actions form {
      margin: 0;
    }

    .actions button {
      padding: 8px 15px;
      border: none;
      border-radius: 20px;
      font-size: 12px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
      min-width: 60px;
    }

    .btn-edit {
      background-color: #c0392b;
      color: white;
    }

    .btn-delete {
      background-color: #a93226;
      color: white;
    }

    .btn-edit:hover {
      background-color: #a93226;
      transform: translateY(-1px);
    }

    .btn-delete:hover {
      background-color: #922b21;
      transform: translateY(-1px);
    }

    /* Mobile Cards */
    .mobile-cards {
      display: none;
    }

    .quiz-card {
      background: white;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      margin-bottom: 15px;
      padding: 20px;
      transition: transform 0.3s ease;
    }

    .quiz-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 2px solid #f0f0f0;
    }

    .card-number {
      background-color: maroon;
      color: white;
      width: 35px;
      height: 35px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 14px;
    }

    .card-title {
      font-size: 18px;
      font-weight: bold;
      color: #333;
      flex: 1;
      margin-left: 15px;
    }

    .card-info {
      margin-bottom: 15px;
    }

    .info-row {
      display: flex;
      margin-bottom: 8px;
      align-items: flex-start;
    }

    .info-label {
      font-weight: bold;
      color: maroon;
      width: 80px;
      flex-shrink: 0;
      font-size: 14px;
    }

    .info-value {
      color: #333;
      flex: 1;
      font-size: 14px;
      word-break: break-word;
    }

    .card-actions {
      display: flex;
      gap: 10px;
      justify-content: center;
      margin-top: 15px;
      padding-top: 15px;
      border-top: 1px solid #f0f0f0;
    }

    .card-actions button {
      flex: 1;
      padding: 12px;
      border: none;
      border-radius: 10px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      body {
        padding: 15px;
      }

      .header {
        font-size: 20px;
        padding: 15px;
      }

      .search-container input {
        font-size: 16px;
        padding: 12px 18px;
      }

      .table-container {
        display: none;
      }

      .mobile-cards {
        display: block;
      }

      .btn-nav {
        padding: 10px 20px;
        font-size: 14px;
      }
    }

    @media (max-width: 480px) {
      body {
        padding: 10px;
      }

      .header {
        font-size: 18px;
        padding: 12px;
      }

      .quiz-card {
        padding: 15px;
      }

      .card-title {
        font-size: 16px;
      }

      .card-actions button {
        padding: 10px;
        font-size: 13px;
      }

      .info-label {
        width: 70px;
        font-size: 13px;
      }

      .info-value {
        font-size: 13px;
      }
    }

    /* Utility classes */
    .text-truncate {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: 200px;
    }

    @media (max-width: 768px) {
      .text-truncate {
        white-space: normal;
        max-width: none;
      }
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="header">📚 Daftar Soal Quiz</div>

    <div class="search-container">
      <input type="text" id="searchInput" placeholder="🔍 Cari soal, judul, atau materi..." onkeyup="searchQuiz()">
    </div>

    <div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='admin.php'">← Kembali ke Admin</button>
    </div>

    <!-- Desktop Table -->
    <div class="table-container">
      <table id="quizTable">
        <thead>
          <tr>
            <th>No</th>
            <th>Judul Quiz</th>
            <th>Materi</th>
            <th>Soal</th>
            <th>Opsi Jawaban</th>
            <th>Jawaban</th>
            <th>Kelas</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no = 1;
          $result = mysqli_query($conn, "SELECT * FROM quizsoal ORDER BY id DESC");
          while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
              <td>{$no}</td>
              <td><div class='text-truncate'>" . htmlspecialchars($row['judul_quiz']) . "</div></td>
              <td>" . htmlspecialchars($row['materi']) . "</td>
              <td><div class='text-truncate'>" . htmlspecialchars($row['soal']) . "</div></td>
              <td><div class='text-truncate'>" . htmlspecialchars($row['opsijawaban']) . "</div></td>
              <td>" . htmlspecialchars($row['jawaban']) . "</td>
              <td>" . htmlspecialchars($row['kelas']) . "</td>
              <td class='actions'>
                <form method='GET' action='editsoalquiz.php'>
                  <input type='hidden' name='id' value='{$row['id']}'>
                  <button type='submit' class='btn-edit'>✏️ Edit</button>
                </form>
                <form method='GET' action='hapussoalquiz.php' onsubmit=\"return confirm('Yakin ingin menghapus soal ini?')\">
                  <input type='hidden' name='id' value='{$row['id']}'>
                  <button type='submit' class='btn-delete'>🗑️ Hapus</button>
                </form>
              </td>
            </tr>";
            $no++;
          }
          ?>
        </tbody>
      </table>
    </div>

    <!-- Mobile Cards -->
    <div class="mobile-cards" id="mobileCards">
      <?php
      $no = 1;
      $result = mysqli_query($conn, "SELECT * FROM quizsoal ORDER BY id DESC");
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='quiz-card'>
          <div class='card-header'>
            <div class='card-number'>{$no}</div>
            <div class='card-title'>" . htmlspecialchars($row['judul_quiz']) . "</div>
          </div>
          <div class='card-info'>
            <div class='info-row'>
              <div class='info-label'>Materi:</div>
              <div class='info-value'>" . htmlspecialchars($row['materi']) . "</div>
            </div>
            <div class='info-row'>
              <div class='info-label'>Soal:</div>
              <div class='info-value'>" . htmlspecialchars($row['soal']) . "</div>
            </div>
            <div class='info-row'>
              <div class='info-label'>Opsi:</div>
              <div class='info-value'>" . htmlspecialchars($row['opsijawaban']) . "</div>
            </div>
            <div class='info-row'>
              <div class='info-label'>Jawaban:</div>
              <div class='info-value'><strong>" . htmlspecialchars($row['jawaban']) . "</strong></div>
            </div>
            <div class='info-row'>
              <div class='info-label'>Kelas:</div>
              <div class='info-value'>" . htmlspecialchars($row['kelas']) . "</div>
            </div>
          </div>
          <div class='card-actions'>
            <form method='GET' action='editsoalquiz.php'>
              <input type='hidden' name='id' value='{$row['id']}'>
              <button type='submit' class='btn-edit'>✏️ Edit</button>
            </form>
            <form method='GET' action='hapussoalquiz.php' onsubmit=\"return confirm('Yakin ingin menghapus soal ini?')\">
              <input type='hidden' name='id' value='{$row['id']}'>
              <button type='submit' class='btn-delete'>🗑️ Hapus</button>
            </form>
          </div>
        </div>";
        $no++;
      }
      ?>
    </div>
  </div>

  <script>
    function searchQuiz() {
      const input = document.getElementById('searchInput');
      const filter = input.value.toLowerCase();
      
      // Search in table (desktop)
      const table = document.getElementById('quizTable');
      const rows = table.getElementsByTagName('tr');
      
      for (let i = 1; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName('td');
        let found = false;
        
        for (let j = 0; j < cells.length - 1; j++) {
          if (cells[j].textContent.toLowerCase().includes(filter)) {
            found = true;
            break;
          }
        }
        
        rows[i].style.display = found ? '' : 'none';
      }
      
      // Search in cards (mobile)
      const cards = document.querySelectorAll('.quiz-card');
      cards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(filter) ? 'block' : 'none';
      });
    }
  </script>

</body>
</html>