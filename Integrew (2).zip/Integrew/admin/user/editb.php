<?php
// koneksi ke database
include '../../db.php';

// Pastikan ID dikirim
if (!isset($_GET['id'])) {
    echo "ID tidak ditemukan!";
    exit;
}

$id = $_GET['id'];

// Ambil data user dari database
$query = "SELECT * FROM user WHERE id = $id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    echo "Data user tidak ditemukan!";
    exit;
}

$user = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Edit Data User - 1 TRPL B</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #fff4f4;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 600px;
      margin: 30px auto;
      background-color: #fff;
      padding: 25px;
      border-radius: 16px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: maroon;
      margin-bottom: 25px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
    }

    label {
      font-weight: 600;
      margin-bottom: 6px;
      color: #333;
    }

    input {
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 8px;
      transition: border 0.3s;
    }

    input:focus {
      border-color: maroon;
      outline: none;
    }

    small {
      font-weight: normal;
      color: #777;
      font-size: 13px;
    }

    button {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px;
      font-size: 16px;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #a30000;
    }

    .back-link {
      margin-top: 20px;
      text-align: center;
    }

    .back-link a {
      text-decoration: none;
      color: maroon;
      font-weight: 600;
      transition: color 0.3s;
    }

    .back-link a:hover {
      color: #a30000;
      text-decoration: underline;
    }

    @media (max-width: 600px) {
      .container {
        margin: 15px 10px;
        padding: 20px;
      }

      input, button {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Edit Data User</h2>
  <form action="prosesedituserb.php" method="POST">
    <input type="hidden" name="id" value="<?= $user['id'] ?>">
    <input type="hidden" name="kelas" value="1 TRPL B">
    <input type="hidden" name="role" value="Mahasiswa">

    <div class="form-group">
      <label for="username">Username:</label>
      <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
    </div>

    <div class="form-group">
      <label for="password">Password: <small>(Kosongkan jika tidak ingin mengubah)</small></label>
      <input type="password" id="password" name="password">
    </div>

    <div class="form-group">
      <label for="nama">Nama Mahasiswa:</label>
      <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($user['nama']) ?>" required>
    </div>

    <button type="submit">Update Data</button>
  </form>

  <div class="back-link">
    <a href="user1trplb.php">← Kembali ke Manajemen User</a>
  </div>
</div>

</body>
</html>
