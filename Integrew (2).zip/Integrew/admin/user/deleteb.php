<?php
// Koneksi ke database
include '../../db.php';

// Pastikan parameter ID dikirim
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk menghapus user berdasarkan ID
    $query = "DELETE FROM user WHERE id = $id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Redirect ke halaman user list dengan pesan sukses
        header("Location: user1trplb.php?status=deleted");
        exit;
    } else {
        echo "Gagal menghapus data: " . mysqli_error($conn);
    }
} else {
    echo "ID tidak ditemukan.";
}
?>
