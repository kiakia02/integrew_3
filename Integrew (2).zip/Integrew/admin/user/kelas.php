<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pilih Kelas - Mahasiswa</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f9f9f9;
    }

        body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f9f9f9;
    }

    .topbar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 20px 30px;
    }

    .topbar .username {
      margin-right: 10px;
      font-weight: bold;
    }

    .avatar {
      width: 40px;
      height: 40px;
      background-color: #eee;
      border-radius: 50%;
      background-image: url('https://cdn-icons-png.flaticon.com/512/3135/3135715.png');
      background-size: cover;
      background-position: center;
    }


    .user-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .logout-btn {
      margin-left: 20px;
      padding: 8px 14px;
      background-color: #d9534f;
      color: white;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
    }

    .logout-btn:hover {
      background-color: #c9302c;
    }

    .section {
      background-color: #f1f1f1;
      margin: 20px;
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0 3px 8px rgba(0, 0, 0, 0.05);
    }

    .section h2 {
      margin-bottom: 20px;
      text-align: center;
      color: maroon;
    }

    .card-container {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 20px;
      margin-bottom: 30px;
    }

    .card {
      width: 120px;
      height: 120px;
      background-color: white;
      border: 3px solid maroon;
      border-radius: 30px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-weight: bold;
      color: maroon;
      text-align: center;
      text-decoration: none;
      transition: transform 0.3s;
    }

    .card:hover {
      transform: scale(1.05);
    }

    .back-wrapper {
      text-align: center;
    }

    .back-button {
      display: inline-block;
      padding: 12px 20px;
      background-color: maroon;
      color: white;
      text-decoration: none;
      border-radius: 10px;
      font-weight: bold;
      transition: background 0.3s;
    }

    .back-button:hover {
      background-color: #a30000;
    }

    .footer-flowers {
      width: 100%;
      height: 100px;
      background-image: url('https://png.pngtree.com/png-clipart/20230428/original/pngtree-spring-flowers-grass-border-design-png-image_9108605.png');
      background-repeat: repeat-x;
      background-size: contain;
      background-position: bottom;
      margin-top: 60px;
    }

@media(max-width: 768px) {
      .card-container {
        justify-content: center;
      }
    }
  </style>
</head>
<body>

  <!-- Topbar Kanan -->
  <div class="topbar">
    <div class="user-info">
      <span class="username"><?= htmlspecialchars($username) ?></span>
      <div class="avatar"></div>
      <a href="logout.php" class="logout-btn">Logout</a>
    </div>
  </div>

  <!-- Pilih Kelas -->
  <div class="section">
    <h2>Pilih Kelas - Mahasiswa</h2>
    <div class="card-container">
      <a href="user1trpla.php" class="card">1 TRPL A</a>
      <a href="user1trplb.php" class="card">1 TRPL B</a>
    </div>

    <!-- Tombol Kembali -->
    <div class="back-wrapper">
      <a href="../admin.php" class="back-button">← Kembali ke Halaman Admin</a>
    </div>
  </div>

  <div class="footer-flowers"></div>
</body>
</html>
