<?php include '../../db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Data User - 1 TRPL A</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #fff4f4;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 600px;
      margin: 30px auto;
      background-color: #fff;
      padding: 25px;
      border-radius: 16px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: maroon;
      margin-bottom: 25px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
    }

    label {
      font-weight: 600;
      margin-bottom: 6px;
      color: #333;
    }

    input {
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 8px;
      transition: border 0.3s;
    }

    input:focus {
      border-color: maroon;
      outline: none;
    }

    button {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px;
      font-size: 16px;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #a30000;
    }

    .back-link {
      margin-top: 20px;
      text-align: center;
    }

    .back-link a {
      text-decoration: none;
      color: maroon;
      font-weight: 600;
      transition: color 0.3s;
    }

    .back-link a:hover {
      color: #a30000;
      text-decoration: underline;
    }

    @media (max-width: 600px) {
      .container {
        margin: 15px 10px;
        padding: 20px;
      }

      input, button {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Tambah Data User</h2>
  <form action="prosestambahuser.php" method="POST">
    
    <div class="form-group">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required>
    </div>

    <div class="form-group">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>
    </div>

    <div class="form-group">
      <label for="nama">Nama Mahasiswa</label>
      <input type="text" id="nama" name="nama" required>
    </div>

    <!-- Hidden Kelas dan Role -->
    <input type="hidden" name="kelas" value="1 TRPL A">
    <input type="hidden" name="role" value="Mahasiswa">

    <button type="submit">Simpan Data</button>
  </form>

  <div class="back-link">
    <a href="user1trpla.php">← Kembali ke Manajemen User</a>
  </div>
</div>

</body>
</html>
