<?php
// koneksi ke database
include '../../db.php';

// Ambil data dari form
$username = $_POST['username'];
$password = $_POST['password']; // Tidak di-hash, langsung digunakan
$nama     = $_POST['nama'];
$kelas    = $_POST['kelas'];
$role     = $_POST['role'];

// Validasi data
if (empty($username) || empty($password) || empty($nama) || empty($kelas) || empty($role)) {
    echo "Semua field wajib diisi!";
    exit;
}

// Masukkan ke database (password langsung tanpa hashing)
$query = "INSERT INTO user (username, password, nama, kelas, role) 
          VALUES ('$username', '$password', '$nama', '$kelas', '$role')";

$result = mysqli_query($conn, $query);

if ($result) {
    // Redirect ke halaman user list
    header("Location: user1trplb.php?status=sukses");
    exit;
} else {
    echo "Gagal menambahkan data: " . mysqli_error($conn);
}
?>
