<?php include '../../db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manajemen User - 1 TRPL A</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 20px;
      background-color: #fff4f4;
    }

    h2 {
      background-color: maroon;
      color: white;
      text-align: center;
      padding: 10px 20px;
      border-radius: 30px;
      margin: 0 auto 20px auto;
      font-size: 20px;
      display: inline-block;
    }

    .search-box {
      display: flex;
      justify-content: center;
      margin-bottom: 15px;
    }

    .search-box input {
      padding: 8px 12px;
      border: 2px solid #ccc;
      border-radius: 20px;
      width: 80%;
      max-width: 300px;
    }

    .btn_tambah, .btn_back {
      background-color: maroon;
      color: white;
      padding: 10px 15px;
      text-decoration: none;
      border-radius: 20px;
      font-size: 14px;
      display: inline-block;
      margin-bottom: 10px;
    }

    .btn_back {
      margin-right: 10px;
    }

    .table-wrapper {
      overflow-x: auto;
      background-color: white;
      border-radius: 12px;
      box-shadow: 0 0 5px rgba(0,0,0,0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 500px;
    }

    th, td {
      padding: 10px;
      text-align: center;
    }

    th {
      background-color: maroon;
      color: white;
    }

    td {
      background-color: #f7eaea;
    }

    td.actions a button {
      background-color: maroon;
      color: white;
      border: none;
      padding: 6px 12px;
      margin: 2px;
      border-radius: 8px;
      cursor: pointer;
    }

    td.actions a button:hover {
      background-color: #a30000;
    }

    @media (max-width: 600px) {
      body {
        padding: 10px;
      }

      h2 {
        font-size: 16px;
        padding: 8px 12px;
      }

      .btn_tambah, .btn_back {
        font-size: 13px;
        padding: 8px 10px;
      }

      .search-box input {
        width: 95%;
        font-size: 14px;
      }

      table, th, td {
        font-size: 13px;
      }
    }
  </style>
</head>
<body>

<div style="text-align: center;">
  <h2>1 TRPL A</h2>
</div>

<div class="search-box">
  <input type="text" id="searchInput" placeholder="🔍 Cari nama mahasiswa...">
</div>

<div style="margin-bottom: 15px;">
  <a href="kelas.php" class="btn_back">← Kembali ke Kelas</a>
  <a href="tambahdata_a.php" class="btn_tambah">➕ Tambah Data</a>
</div>

<div class="table-wrapper">
  <table>
    <thead>
      <tr>
        <th>Username</th>
        <th>Password</th>
        <th>Nama Mahasiswa</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody id="userTable">
      <?php
      $result = mysqli_query($conn, "SELECT * FROM user WHERE kelas='1 TRPL A'");
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
          <td>{$row['username']}</td>
          <td>{$row['password']}</td>
          <td class='nama'>{$row['nama']}</td>
          <td class='actions'>
            <a href='edit.php?id={$row['id']}'><button>Edit</button></a>
            <a href='delete.php?id={$row['id']}' onclick=\"return confirm('Hapus user ini?')\"><button>Hapus</button></a>
          </td>
        </tr>";
      }
      ?>
    </tbody>
  </table>
</div>

<script>
  // Live search by nama mahasiswa
  document.getElementById('searchInput').addEventListener('input', function () {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#userTable tr');

    rows.forEach(row => {
      const nama = row.querySelector('.nama').textContent.toLowerCase();
      if (nama.includes(filter)) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  });
</script>

</body>
</html>
