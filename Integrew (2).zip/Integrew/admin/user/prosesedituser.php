<?php
// koneksi ke database
include '../../db.php';

// Ambil data dari form
$id       = $_POST['id'];
$username = $_POST['username'];
$password = $_POST['password'];
$nama     = $_POST['nama'];
$kelas    = $_POST['kelas'];
$role     = $_POST['role'];

// Validasi dasar
if (empty($id) || empty($username) || empty($nama) || empty($kelas) || empty($role)) {
    echo "Semua field wajib diisi (kecuali password jika tidak ingin diubah)!";
    exit;
}

// Jika password tidak kosong, update semua termasuk password
if (!empty($password)) {
    // Jika ingin password tidak di-hash, gunakan baris ini:
    $query = "UPDATE user SET username='$username', password='$password', nama='$nama', kelas='$kelas', role='$role' WHERE id=$id";
} else {
    // Jika password tidak diubah
    $query = "UPDATE user SET username='$username', nama='$nama', kelas='$kelas', role='$role' WHERE id=$id";
}

$result = mysqli_query($conn, $query);

if ($result) {
    header("Location: user1trpla.php?status=edit_sukses");
    exit;
} else {
    echo "Gagal mengupdate data: " . mysqli_error($conn);
}
?>
