<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'mahasiswa') {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kalkulator Integral</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f9f9f9;
    }

    .topbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 30px;
      background-color: maroon;
      color: white;
      flex-wrap: wrap;
    }

    .topbar .username {
      font-style: italic;
      font-size: 1rem;
    }

    .logout-btn {
      background-color: #d9534f;
      color: white;
      padding: 8px 16px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
      margin-top: 10px;
      transition: background-color 0.3s;
    }

    .logout-btn:hover {
      background-color: #c9302c;
    }

    .container {
      padding: 30px 40px;
    }

    h1 {
      color: maroon;
      text-align: center;
      margin-bottom: 30px;
    }

    .button-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
      gap: 20px;
    }

    .feature-button {
      padding: 24px;
      border-radius: 20px;
      background-color: white;
      border: 2px solid maroon;
      color: maroon;
      text-align: center;
      font-size: 1.1rem;
      font-weight: bold;
      text-decoration: none;
      transition: background-color 0.3s, color 0.3s;
    }

    .feature-button:hover {
      background-color: maroon;
      color: white;
    }

    /* RESPONSIVE */
    @media (max-width: 768px) {
      .topbar {
        padding: 15px 20px;
        flex-direction: column;
        align-items: flex-start;
      }

      .container {
        padding: 20px 15px;
      }

      .feature-button {
        font-size: 1rem;
        padding: 20px;
      }

      h1 {
        font-size: 1.5rem;
      }
    }

    @media (max-width: 480px) {
      .feature-button {
        font-size: 0.95rem;
        padding: 18px;
      }

      .logout-btn {
        width: 100px
        text-align: center;
        margin-top: 10px;
      }

      .topbar .username {
        font-size: 0.95rem;
      }
    }
    .btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="username">Halo, <?= htmlspecialchars($_SESSION['username']) ?>!</div>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>

  <div class="container">
    <h1>Kalkulasi Integral</h1>
    <div class="button-grid">
      <a href="luas_datar.php" class="feature-button">
        Menghitung Luas Daerah Datar
      </a>
      <a href="volumebendaruang.php" class="feature-button">
       Volume Benda dalam Ruang
      </a>
      <a href="volumebendaputar.php" class="feature-button">
        Volume Benda Putar
      </a>
      <a href="panjang_kurva.php" class="feature-button">
        Panjang Kurva
      </a>
    </div>
    <div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='dashboardmahasiswa.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>
  </div>

</body>
</html>
