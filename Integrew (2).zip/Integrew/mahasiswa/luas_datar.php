<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalkulator Luas Daerah Datar</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjs/11.11.0/math.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 10px;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 20px;
            padding: 20px 10px;
        }

        .header h1 {
            font-size: clamp(1.8rem, 5vw, 2.5rem);
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            word-wrap: break-word;
        }

        .header p {
            font-size: clamp(1rem, 3vw, 1.2rem);
            opacity: 0.9;
        }

        .card {
            background: white;
            border-radius: 15px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
        }

        .section-title {
            font-size: clamp(1.2rem, 4vw, 1.8rem);
            color: #4a5568;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
            word-wrap: break-word;
        }

        .section-title::before {
            content: '';
            width: 4px;
            height: 25px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            border-radius: 2px;
            flex-shrink: 0;
        }

        .theory-section {
            display: grid;
            gap: 15px;
        }

        .formula-box {
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            border-left: 4px solid #667eea;
            padding: 15px;
            border-radius: 10px;
            margin: 10px 0;
        }

        .formula-box h3 {
            font-size: clamp(1rem, 3vw, 1.1rem);
            margin-bottom: 8px;
        }

        .formula {
            font-size: clamp(1.1rem, 3.5vw, 1.4rem);
            text-align: center;
            font-weight: bold;
            color: #2d3748;
            margin: 10px 0;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .formula-box p {
            font-size: clamp(0.9rem, 2.5vw, 1rem);
            line-height: 1.5;
        }

        .calculator-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
            margin-top: 20px;
        }

        .input-section {
            background: #f8fafc;
            padding: 20px;
            border-radius: 15px;
            border: 2px solid #e2e8f0;
            order: 1;
        }

        .chart-container {
            background: white;
            padding: 15px;
            border-radius: 15px;
            border: 2px solid #e2e8f0;
            height: 300px;
            position: relative;
            order: 2;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            color: #4a5568;
            font-size: clamp(0.9rem, 2.5vw, 1rem);
        }

        .input-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: clamp(0.9rem, 2.5vw, 1rem);
            transition: all 0.3s ease;
            background: white;
            -webkit-appearance: none;
            -moz-appearance: textfield;
        }

        .input-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 15px 20px;
            border-radius: 25px;
            font-size: clamp(0.9rem, 2.5vw, 1.1rem);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
            margin-top: 10px;
            min-height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }

        .btn:active {
            transform: translateY(0);
        }

        .btn-example {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            margin: 8px 0;
            padding: 12px 15px;
            font-size: clamp(0.8rem, 2vw, 0.9rem);
            width: 100%;
            min-height: 45px;
        }

        .result-section {
            background: linear-gradient(135deg, #f0fff4 0%, #e6fffa 100%);
            border: 2px solid #48bb78;
            border-radius: 15px;
            padding: 20px;
            margin-top: 20px;
        }

        .result-title {
            font-size: clamp(1.1rem, 3vw, 1.3rem);
            color: #2f855a;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .result-value {
            font-size: clamp(1.3rem, 4vw, 2rem);
            color: #1a202c;
            font-weight: bold;
            text-align: center;
            margin: 15px 0;
            padding: 15px;
            background: white;
            border-radius: 10px;
            border: 2px solid #48bb78;
            word-wrap: break-word;
        }

        .steps {
            margin-top: 15px;
        }

        .step {
            background: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 10px;
            border-left: 4px solid #667eea;
            font-size: clamp(0.9rem, 2.5vw, 1rem);
            line-height: 1.6;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .examples-section {
            display: grid;
            gap: 15px;
        }

        .example-card {
            background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
            border: 2px solid #fc8181;
            border-radius: 15px;
            padding: 15px;
        }

        .example-title {
            font-size: clamp(1rem, 3vw, 1.2rem);
            color: #c53030;
            font-weight: bold;
            margin-bottom: 12px;
            word-wrap: break-word;
        }

        .example-content {
            color: #2d3748;
            line-height: 1.6;
            font-size: clamp(0.9rem, 2.5vw, 1rem);
        }

        .example-content p {
            margin-bottom: 8px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .tab-container {
            display: flex;
            margin-bottom: 20px;
            background: #f1f5f9;
            border-radius: 10px;
            padding: 5px;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .tab {
            flex: 1;
            min-width: 100px;
            padding: 12px 10px;
            text-align: center;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            font-size: clamp(0.8rem, 2.5vw, 1rem);
            white-space: nowrap;
        }

        .tab.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }
        .btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
        .error {
            color: #e53e3e;
            background: #fed7d7;
            padding: 10px;
            border-radius: 8px;
            margin-top: 10px;
            font-size: clamp(0.8rem, 2.5vw, 0.9rem);
            word-wrap: break-word;
        }

        /* Tablet breakpoint */
        @media (min-width: 768px) {
            .container {
                padding: 20px;
            }
            
            .card {
                padding: 25px;
            }
            
            .calculator-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .input-section {
                order: 0;
            }
            
            .chart-container {
                height: 400px;
                order: 0;
            }
            
            .btn-example {
                width: auto;
                display: inline-block;
                margin: 10px 5px;
            }
        }

        /* Desktop breakpoint */
        @media (min-width: 1024px) {
            .container {
                padding: 20px;
            }
            
            .card {
                padding: 30px;
            }
            
            .calculator-grid {
                gap: 30px;
            }
            
            .input-section {
                padding: 25px;
            }
            
            .chart-container {
                padding: 20px;
            }
        }

        /* Very small screens */
        @media (max-width: 480px) {
            .container {
                padding: 8px;
            }
            
            .header {
                padding: 15px 5px;
                margin-bottom: 15px;
            }
            
            .card {
                padding: 12px;
                border-radius: 12px;
            }
            
            .tab-container {
                margin-bottom: 15px;
            }
            
            .tab {
                padding: 10px 8px;
                min-width: 80px;
            }
            
            .input-section {
                padding: 15px;
            }
            
            .chart-container {
                height: 250px;
                padding: 10px;
            }
            
            .result-section {
                padding: 15px;
            }
            
            .example-card {
                padding: 12px;
            }
            
            .formula {
                font-size: 1rem;
                padding: 5px;
            }
        }

        /* Extra small screens */
        @media (max-width: 320px) {
            .header h1 {
                font-size: 1.5rem;
            }
            
            .header p {
                font-size: 0.9rem;
            }
            
            .tab {
                font-size: 0.7rem;
                padding: 8px 6px;
            }
            
            .chart-container {
                height: 200px;
            }
        }

        /* Landscape orientation on mobile */
        @media (max-height: 500px) and (orientation: landscape) {
            .header {
                margin-bottom: 10px;
                padding: 10px;
            }
            
            .chart-container {
                height: 200px;
            }
        }

        /* Touch-friendly improvements */
        @media (hover: none) and (pointer: coarse) {
            .btn, .tab {
                min-height: 44px;
            }
            
            .input-group input {
                min-height: 44px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Kalkulator Luas Daerah Datar</h1>
            <p>Menghitung luas daerah dengan integral tentu</p>
        </div>

        <div class="card">
            <div class="tab-container">
                <div class="tab active" onclick="switchTab('theory')">📚 Materi</div>
                <div class="tab" onclick="switchTab('calculator')">🧮 Kalkulator</div>
                <div class="tab" onclick="switchTab('examples')">📝 Contoh Soal</div>
            </div>

            <div id="theory" class="tab-content active">
                <h2 class="section-title">Rumus Luas Daerah Datar</h2>
                <div class="theory-section">
                    <div class="formula-box">
                        <h3>1. Luas antara dua kurva:</h3>
                        <div class="formula">L = ∫[a to b] |f(x) - g(x)| dx</div>
                        <p>Dimana f(x) adalah kurva atas dan g(x) adalah kurva bawah</p>
                    </div>
                    
                    <div class="formula-box">
                        <h3>2. Luas di atas sumbu x:</h3>
                        <div class="formula">L = ∫[a to b] f(x) dx</div>
                        <p>Untuk f(x) ≥ 0 pada interval [a,b]</p>
                    </div>
                    
                    <div class="formula-box">
                        <h3>3. Luas di bawah sumbu x:</h3>
                        <div class="formula">L = ∫[a to b] |f(x)| dx = -∫[a to b] f(x) dx</div>
                        <p>Untuk f(x) ≤ 0 pada interval [a,b]</p>
                    </div>
                </div>
            </div>

            <div id="calculator" class="tab-content">
                <h2 class="section-title">Kalkulator Luas Daerah</h2>
                <div class="calculator-grid">
                    <div class="input-section">
                        <div class="input-group">
                            <label for="upperCurve">Kurva Atas f(x):</label>
                            <input type="text" id="upperCurve" placeholder="Contoh: x^2 + 1" value="x^2 + 1">
                        </div>
                        
                        <div class="input-group">
                            <label for="lowerCurve">Kurva Bawah g(x):</label>
                            <input type="text" id="lowerCurve" placeholder="Contoh: 0 atau x" value="0">
                        </div>
                        
                        <div class="input-group">
                            <label for="lowerBound">Batas Bawah (a):</label>
                            <input type="number" id="lowerBound" placeholder="0" value="0" step="0.1">
                        </div>
                        
                        <div class="input-group">
                            <label for="upperBound">Batas Atas (b):</label>
                            <input type="number" id="upperBound" placeholder="2" value="2" step="0.1">
                        </div>
                        
                        <button class="btn" onclick="calculateArea()">🔍 Hitung Luas</button>
                        <div id="error-message"></div>
                    </div>
                    
                    <div class="chart-container">
                        <canvas id="functionChart"></canvas>
                    </div>
                </div>
                
                <div id="result" class="result-section" style="display: none;">
                    <div class="result-title">📊 Hasil Perhitungan</div>
                    <div class="result-value" id="areaResult">0</div>
                    <div class="steps" id="calculationSteps"></div>
                </div>
            </div>

            <div id="examples" class="tab-content">
                <h2 class="section-title">Contoh Soal</h2>
                <div class="examples-section">
                    <div class="example-card">
                        <div class="example-title">Contoh 1: Luas di atas sumbu x</div>
                        <div class="example-content">
                            <p><strong>Soal:</strong> Hitunglah luas daerah yang dibatasi oleh kurva y = x² + 1, sumbu x, x = 0, dan x = 2</p>
                            <p><strong>Penyelesaian:</strong></p>
                            <p>L = ∫₀² (x² + 1) dx</p>
                            <button class="btn btn-example" onclick="loadExample(1)">Hitung di Kalkulator</button>
                        </div>
                    </div>
                    
                    <div class="example-card">
                        <div class="example-title">Contoh 2: Luas antara dua kurva</div>
                        <div class="example-content">
                            <p><strong>Soal:</strong> Hitunglah luas daerah yang dibatasi oleh kurva y = x² dan y = 2x dari x = 0 sampai x = 2</p>
                            <p><strong>Penyelesaian:</strong></p>
                            <p>L = ∫₀² |2x - x²| dx</p>
                            <button class="btn btn-example" onclick="loadExample(2)">Hitung di Kalkulator</button>
                        </div>
                    </div>
                    
                    <div class="example-card">
                        <div class="example-title">Contoh 3: Luas dengan kurva parabola</div>
                        <div class="example-content">
                            <p><strong>Soal:</strong> Hitunglah luas daerah yang dibatasi oleh kurva y = 4 - x² dan sumbu x</p>
                            <p><strong>Penyelesaian:</strong></p>
                            <p>L = ∫₋₂² (4 - x²) dx</p>
                            <button class="btn btn-example" onclick="loadExample(3)">Hitung di Kalkulator</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='dashboardmahasiswa.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>
    </div>

    <script>
        let chart = null;

        function switchTab(tabName) {
            // Hide all tab contents
            const contents = document.querySelectorAll('.tab-content');
            contents.forEach(content => content.classList.remove('active'));
            
            // Remove active class from all tabs
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => tab.classList.remove('active'));
            
            // Show selected tab content
            document.getElementById(tabName).classList.add('active');
            
            // Add active class to clicked tab
            event.target.classList.add('active');
            
            // If switching to calculator tab, update chart
            if (tabName === 'calculator') {
                setTimeout(() => updateChart(), 100);
            }
        }

        function evaluateFunction(expr, x) {
            try {
                const scope = { x: x };
                return math.evaluate(expr, scope);
            } catch (error) {
                throw new Error(`Error evaluating function: ${error.message}`);
            }
        }

        function numericalIntegration(f, a, b, n = 1000) {
            const h = (b - a) / n;
            let sum = 0;
            
            for (let i = 0; i <= n; i++) {
                const x = a + i * h;
                const weight = (i === 0 || i === n) ? 1 : (i % 2 === 0) ? 2 : 4;
                sum += weight * f(x);
            }
            
            return (h / 3) * sum;
        }

        function calculateArea() {
            try {
                const upperCurve = document.getElementById('upperCurve').value.trim();
                const lowerCurve = document.getElementById('lowerCurve').value.trim() || '0';
                const a = parseFloat(document.getElementById('lowerBound').value);
                const b = parseFloat(document.getElementById('upperBound').value);
                
                if (!upperCurve) {
                    throw new Error('Masukkan kurva atas');
                }
                
                if (isNaN(a) || isNaN(b)) {
                    throw new Error('Masukkan batas integrasi yang valid');
                }
                
                if (a >= b) {
                    throw new Error('Batas atas harus lebih besar dari batas bawah');
                }

                // Clear error message
                document.getElementById('error-message').innerHTML = '';

                // Define the difference function
                const diffFunction = (x) => {
                    const upper = evaluateFunction(upperCurve, x);
                    const lower = evaluateFunction(lowerCurve, x);
                    return Math.abs(upper - lower);
                };

                // Calculate the area using numerical integration
                const area = numericalIntegration(diffFunction, a, b);

                // Display result
                document.getElementById('areaResult').textContent = area.toFixed(4) + ' satuan luas';
                
                // Generate calculation steps
                const steps = generateSteps(upperCurve, lowerCurve, a, b, area);
                document.getElementById('calculationSteps').innerHTML = steps;
                
                // Show result section
                document.getElementById('result').style.display = 'block';
                
                // Update chart
                updateChart();
                
            } catch (error) {
                document.getElementById('error-message').innerHTML = `<div class="error">❌ ${error.message}</div>`;
                document.getElementById('result').style.display = 'none';
            }
        }

        function generateSteps(upper, lower, a, b, result) {
            let steps = '';
            
            steps += `<div class="step">
                <strong>Langkah 1:</strong> Menentukan fungsi yang akan diintegralkan<br>
                f(x) = ${upper}<br>
                g(x) = ${lower}
            </div>`;
            
            steps += `<div class="step">
                <strong>Langkah 2:</strong> Menentukan batas integrasi<br>
                Batas bawah (a) = ${a}<br>
                Batas atas (b) = ${b}
            </div>`;
            
            steps += `<div class="step">
                <strong>Langkah 3:</strong> Menyusun integral<br>
                L = ∫[${a} to ${b}] |${upper} - (${lower})| dx
            </div>`;
            
            steps += `<div class="step">
                <strong>Langkah 4:</strong> Hasil perhitungan numerik<br>
                L = ${result.toFixed(4)} satuan luas
            </div>`;
            
            return steps;
        }

        function updateChart() {
            const canvas = document.getElementById('functionChart');
            const ctx = canvas.getContext('2d');
            
            if (chart) {
                chart.destroy();
            }

            try {
                const upperCurve = document.getElementById('upperCurve').value.trim() || 'x^2 + 1';
                const lowerCurve = document.getElementById('lowerCurve').value.trim() || '0';
                const a = parseFloat(document.getElementById('lowerBound').value) || 0;
                const b = parseFloat(document.getElementById('upperBound').value) || 2;

                // Generate data points
                const numPoints = 100;
                const step = (b - a) / numPoints;
                const xValues = [];
                const upperValues = [];
                const lowerValues = [];
                const areaValues = [];

                for (let i = 0; i <= numPoints; i++) {
                    const x = a + i * step;
                    xValues.push(x);
                    
                    try {
                        const upperY = evaluateFunction(upperCurve, x);
                        const lowerY = evaluateFunction(lowerCurve, x);
                        upperValues.push(upperY);
                        lowerValues.push(lowerY);
                        areaValues.push(Math.max(upperY, lowerY));
                    } catch (error) {
                        upperValues.push(null);
                        lowerValues.push(null);
                        areaValues.push(null);
                    }
                }

                chart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: xValues.map(x => x.toFixed(2)),
                        datasets: [
                            {
                                label: `f(x) = ${upperCurve}`,
                                data: upperValues,
                                borderColor: '#667eea',
                                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                                borderWidth: 3,
                                fill: false,
                                tension: 0.4
                            },
                            {
                                label: `g(x) = ${lowerCurve}`,
                                data: lowerValues,
                                borderColor: '#48bb78',
                                backgroundColor: 'rgba(72, 187, 120, 0.1)',
                                borderWidth: 3,
                                fill: false,
                                tension: 0.4
                            },
                            {
                                label: 'Area',
                                data: areaValues,
                                backgroundColor: 'rgba(102, 126, 234, 0.2)',
                                borderColor: 'rgba(102, 126, 234, 0.5)',
                                borderWidth: 1,
                                fill: 'origin',
                                tension: 0.4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            title: {
                                display: true,
                                text: 'Grafik Fungsi dan Daerah yang Diarsir',
                                font: {
                                    size: window.innerWidth < 768 ? 12 : 16,
                                    weight: 'bold'
                                }
                            },
                            legend: {
                                display: true,
                                position: 'top',
                                labels: {
                                    font: {
                                        size: window.innerWidth < 768 ? 10 : 12
                                    }
                                }
                            }
                        },
                        scales: {
                            x: {
                                title: {
                                    display: true,
                                    text: 'x',
                                    font: {
                                        size: window.innerWidth < 768 ? 10 : 12
                                    }
                                },
                                grid: {
                                    display: true,
                                    color: 'rgba(0,0,0,0.1)'
                                },
                                ticks: {
                                    font: {
                                        size: window.innerWidth < 768 ? 8 : 10
                                    }
                                }
                            },
                            y: {
                                title: {
                                    display: true,
                                    text: 'y',
                                    font: {
                                        size: window.innerWidth < 768 ? 10 : 12
                                    }
                                },
                                grid: {
                                    display: true,
                                    color: 'rgba(0,0,0,0.1)'
                                },
                                ticks: {
                                    font: {
                                        size: window.innerWidth < 768 ? 8 : 10
                                    }
                                }
                            }
                        },
                        interaction: {
                            intersect: false,
                            mode: 'index'
                        }
                    }
                });
            } catch (error) {
                console.error('Chart update error:', error);
            }
        }

        function loadExample(exampleNum) {
            switchTab('calculator');
            
            setTimeout(() => {
                switch(exampleNum) {
                    case 1:
                        document.getElementById('upperCurve').value = 'x^2 + 1';
                        document.getElementById('lowerCurve').value = '0';
                        document.getElementById('lowerBound').value = '0';
                        document.getElementById('upperBound').value = '2';
                        break;
                    case 2:
                        document.getElementById('upperCurve').value = '2*x';
                        document.getElementById('lowerCurve').value = 'x^2';
                        document.getElementById('lowerBound').value = '0';
                        document.getElementById('upperBound').value = '2';
                        break;
                    case 3:
                        document.getElementById('upperCurve').value = '4 - x^2';
                        document.getElementById('lowerCurve').value = '0';
                        document.getElementById('lowerBound').value = '-2';
                        document.getElementById('upperBound').value = '2';
                        break;
                }
                
                // Auto calculate after loading example
                setTimeout(() => {
                    calculateArea();
                }, 100);
            }, 100);
        }

        // Initialize chart when page loads
        window.addEventListener('load', function() {
            setTimeout(() => {
                updateChart();
            }, 500);
        });

        // Update chart when inputs change
        document.getElementById('upperCurve').addEventListener('input', updateChart);
        document.getElementById('lowerCurve').addEventListener('input', updateChart);
        document.getElementById('lowerBound').addEventListener('input', updateChart);
        document.getElementById('upperBound').addEventListener('input', updateChart);
    </script>
</body>
</html>