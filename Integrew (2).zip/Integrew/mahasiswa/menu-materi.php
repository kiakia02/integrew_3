<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // arahkan kembali ke halaman login
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Integrew</title>
  <script src="https://cdn.tailwindcss.com"></script>

  <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
  <link href="https://fonts.cdnfonts.com/css/chunkfive" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">


  <style>
    @import url('https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap');
    .font-logo {
      font-family: 'Fredoka One', cursive;
    }
    .materi{
        padding: 1rem 1.2rem 0px 1.2rem;
    }
    .header{
        display: flex;
        margin: 2rem 2rem 0rem 2rem;
        justify-content: right;
    }
    #menu-materi .materi a{
        margin: 1px ;
    }
    #menu-materi a #rumus{
        font-size: 14px;
        font-family: 'Anton', sans-serif;
        color:#cc5e5e ;

    }
    #menu-materi a p{
        font-family: 'ChunkFive', serif;
        color:#cc5e5e ;
    }
    #menu-materi .materi h4{
        font-family: 'Open Sans', sans-serif;
    }

    .bunga {
        width: 100%;
        margin: 0;
        padding: 0;
    }
    .bunga img {
        display: block;
        width: 100%;
        height: auto;
        margin: 0;
        padding: 0;
    }
    .materi a{
        border: 1px  solid #cc5e5e;
        border-bottom: 4px solid #cc5e5e ;
        border-radius: 35px;
    }
    .uji{
        display:flex;
        flex-direction:column;
        align-items:center;
        justify-content:center;
    }
    .uji img{
        width: 70px;
        justify-content:center;
    }
    .uji p{
        font-size:13px;
    }
    .btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
  </style>
</head>

<body class="bg-white min-h-screen flex flex-col justify-between" id="menu-materi">
  <!-- Header -->
  <div class="header">
    <div class="flex items-center space-x-2">
      <span class="font-semibold text-gray-700">
    <?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Tamu' ?>
</span>

    </div>
  </div>

  <!-- Grid Materi -->
   <div class="materi">
        <div class="px-6 py-4">
            <h2 class="text-xl font-semibold">Materi</h2>
            <div class="grid grid-cols-2 gap-4 bg-gray-100 p-4 rounded-xl">

            <!-- Materi Card -->
            <!-- Materi Card 1 -->
            <a href="materi1/index.php" class="relative bg-white border-2  rounded-xl text-center p-4 shadow-sm hover:shadow-md transition">
                <div class="absolute -top-3 -left-3 bg-green-500 text-white text-sm w-6 h-6 flex items-center justify-center rounded-full">1</div>
                <p class="text-red-600 text-xl" id="rumus">∫ 4x</p>
                <p class="text-xs mt-2">Dasar Integral</p>
            </a>

            <!-- Materi Card 2 -->
            <a href="materi2/index.php" class="relative bg-white border-2 border-red-300 rounded-xl text-center p-4 shadow-sm hover:shadow-md transition">
                <div class="absolute -top-3 -left-3 bg-green-500 text-white text-sm w-6 h-6 flex items-center justify-center rounded-full">2</div>
                <p class="text-red-600 text-xl" id="rumus">∫ f(x) - g(x)</p>
                <p class="text-xs mt-2">Menghitung luas daerah</p>
            </a>

            <!-- Materi Card 3 -->
            <a href="materi3/index.php" class="relative bg-white border-2 border-red-300 rounded-xl text-center p-4 shadow-sm hover:shadow-md transition">
                <div class="absolute -top-3 -left-3 bg-green-500 text-white text-sm w-6 h-6 flex items-center justify-center rounded-full">3</div>
                <p class="text-red-600 text-xl" id="rumus">D = b² - 4ac</p>
                <p class="text-xs mt-2">Luas daerah dengan rumus</p>
            </a>

            <!-- Materi Card 4 -->
            <a href="materi4/index.php" class="relative bg-white border-2 border-red-300 rounded-xl text-center p-4 shadow-sm hover:shadow-md transition">
                <div class="absolute -top-3 -left-3 bg-green-500 text-white text-sm w-6 h-6 flex items-center justify-center rounded-full">4</div>
                <p class="text-red-600 text-xl" id="rumus">V = π ∫ f(x)² dx</p>
                <p class="text-xs mt-2">Volume benda dalam ruang</p>
            </a>

            <!-- Materi Card 5 -->
            <a href="materi5/index.php" class="relative bg-white border-2 border-red-300 rounded-xl text-center p-4 shadow-sm hover:shadow-md transition">
                <div class="absolute -top-3 -left-3 bg-green-500 text-white text-sm w-6 h-6 flex items-center justify-center rounded-full">5</div>
                <p class="text-red-600 text-xl" id="rumus">V = π ∫ (f(x))²</p>
                <p class="text-xs mt-2">Volume benda putar</p>
            </a>

            <!-- Materi Card 6 -->
            <a href="materi6/index.php" class="relative bg-white border-2 border-red-300 rounded-xl text-center p-4 shadow-sm hover:shadow-md transition">
                <div class="absolute -top-3 -left-3 bg-green-500 text-white text-sm w-6 h-6 flex items-center justify-center rounded-full">6</div>
                <p class="text-red-600 text-xl" id="rumus">∫ 4x</p>
                <p class="text-xs mt-2">Panjang busur dengan integral</p>
            </a>
        </div>
    </div>  
 </div>
 <div class="uji">
    <p>Pelajari secara bertahap</p>
    <a href="uji-pemahaman/index.php">
        <img src="../foto/start.png" alt="">
    </a>
 </div>
     <div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='dashboardmahasiswa.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>
  <!-- Footer Dekorasi -->
  <div class="bunga">
    <img src="../foto/bunga.png" class="block w-full" />
    </div>
</body>
</html>