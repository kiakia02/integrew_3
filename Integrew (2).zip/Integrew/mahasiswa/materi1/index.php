<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dasar Integral</title>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Rubik+Bubbles&display=swap" rel="stylesheet">
  
  <style>
    body {
      font-family: 'Open Sans', sans-serif;
      text-align: center;
      background-color: #fff;
      padding: 2rem;
    }

    .title-box {
      display: inline-block;
      border: 4px solid black;
      border-radius: 20px;
      padding: 1rem 2rem;
      font-family: 'Rubik Bubbles', cursive;
      font-size: 30px;
      color: #D55050;
      box-shadow: 4px 6px #db719b;
      margin-bottom: 2rem;
    }

    h2 {
      font-family: 'Rubik Bubbles', cursive;
      font-size: 25px;
      color: #cc5e5e;
      letter-spacing: 1px;
    }

    .button-row {
      display: flex;
      justify-content: center;
      gap: 2rem;
      margin-bottom: 2rem;
    }

    .math-button, .nav-button {
      background: linear-gradient(to bottom, #f55 70%, #d94457 30%);
      color: white;
      font-weight: bold;
      padding: 1rem 2rem;
      border-radius: 30px;
      box-shadow: 4px 6px #c94f6b;
      border: none;
      font-size: 1rem;
      min-width: 120px;
    }

    .math-button {
      font-family: 'Times New Roman', serif;
      font-style: italic;
    }
    .rumus{
        display: flex;
        justify-content: space-between;
        margin-top: 50px;
    }
    .rumus img{
        width: 100px;
        border-radius: 10px;

    }
    .rumus-integral-fungsi, .rumus-integral{
        background-color: #c55e5e;
        display: flex;
        align-items: center;
        padding: 5px 26px;
        border: 2px solid #f4b9d3;
        border-bottom: 6px solid #a73832;
        border-radius: 30px;
    }
    .button{
        display: flex;
        flex-direction: column;
        margin-top: 100px;
    }
    .button button{
        margin: 10px;
        padding: 10px 5px;
        background-color: #ff5757;
        border: 2px solid #f4b9d3;
        border-bottom: 6px solid #a73832;
        color: white;
        font-family: 'Rubik Bubbles', cursive;
        font-size: 20px;
        border-radius: 30px;
    }
    .popup {
  display: none;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #ffffcc;
  border: 2px solid #333;
  padding: 20px;
  width: 300px;
  z-index: 1000;
  border-radius: 15px;
  box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
  text-align: left;
  font-weight: 100;
}
.popup p{
  font-size:10px;
}
.close-btn {
  position: absolute;
  right: 12px;
  top: 8px;
  font-size: 20px;
  cursor: pointer;
  color: #a73832;
}
    .btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
  </style>
</head>
<body>
  <div class="title-box">
    Dasar Integral</div>
  <h2>Integral Tak Tentu</h2>

  <div class="rumus">
    <div class="rumus-integral-fungsi">
        <img src="gambar/integral-fungsi.jpeg">
    </div>
    <div class="rumus-integral">
        <img src="gambar/integral.jpeg" >
    </div>
  </div>
  
<div class="button">
  <button onclick="location.href='latihansoal.php'">Latihan Soal</button>
  <button onclick="location.href='kuis.php'">Kuis</button>
</div>
<div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='../menu-materi.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>


  <!-- Load MathJax for LaTeX rendering -->
  <script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
  <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

  <!-- Popup Element -->
<div id="popup" class="popup">
  <span class="close-btn" id="closePopup">&times;</span>
  <p><strong><b>Keterangan</b></strong></p>
  <p><strong>∫ f(x)</strong> : notasi integral tak tentu</p>
  <p><strong>F(x) + c</strong> : fungsi antiturunan</p>
  <p><strong>f(x)</strong> : fungsi yang diintegralkan (integran)</p>
  <p><strong>c</strong> : konstanta</p>
  <p><strong>d(x)</strong> : diferensial (turunan) dari x</p>
</div>

<script>
  const popup = document.getElementById("popup");
  const closeBtn = document.getElementById("closePopup");

  // Tampilkan pop-up saat gambar diklik
  document.querySelector(".rumus-integral-fungsi img").addEventListener("click", () => {
    popup.style.display = "block";
  });
  document.querySelector(".rumus-integral img").addEventListener("click", () => {
    popup.style.display = "block";
  });

  // Tutup pop-up saat tombol silang diklik
  closeBtn.addEventListener("click", () => {
    popup.style.display = "none";
  });

  // Tutup pop-up jika klik di luar area pop-up
  window.addEventListener("click", function(event) {
    if (event.target === popup) {
      popup.style.display = "none";
    }
  });
</script>

</body>
</html>
