<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Uji Pemahaman</title>
    <style>
      body {
        margin: 0;
        padding: 0;
        background: url("../../foto/map-uji.png") no-repeat center center fixed;
        background-size: cover;
        overflow-x: hidden;
      }

      .title {
        text-align: center;
        margin: 20px;
        font-weight: bold;
        font-size: 1.5rem;
        color: white;
        background: #1e3a8a;
        display: inline-block;
        padding: 0.4rem 1.5rem;
        border-radius: 20px;
      }

      .map-container {
        position: relative;
        width: 100%;
        max-width: 480px;
        margin: auto;
        height: 90vh;
      }

      .level-btn {
        position: absolute;
        width: 60px;
        height: 60px;
        background-size: cover;
        border: none;
        background-repeat: no-repeat;
        background-position: center;
        background-color: transparent;
        cursor: pointer;
      }

      /* Posisi dan gambar setiap level */
      .l1 {
        bottom: 150px;
        left: 10%;
        background-image: url("../../foto/no-1.png");
      }
      .l2 {
        bottom: 190px;
        left: 33%;
        background-image: url("../../foto/no-2.png");
      }
      .l3 {
        bottom: 190px;
        left: 60%;
        background-image: url("../../foto/no-3.png");
      }
      .l4 {
        bottom: 250px;
        left: 75%;
        background-image: url("../../foto/no-4.png");
      }
      .l5 {
        bottom: 320px;
        left: 60%;
        background-image: url("../../foto/no-5.png");
      }
      .l6 {
        bottom: 325px;
        left: 35%;
        background-image: url("../../foto/no-6.png");
      }
      .l7 {
        bottom: 360px;
        left: 10%;
        background-image: url("../../foto/no-7.png");
      }
      .l8 {
        bottom: 450px;
        left: 25%;
        background-image: url("../../foto/no-8.png");
      }

      .level-btn:hover {
        transform: scale(1.1);
      }
      
    </style>
  </head>
  <body>
    <div class="title">Uji Pemahamanmu</div>

    <div class="map-container">
      <button class="level-btn l1" onclick="goToLevel(1)"></button>
      <button class="level-btn l2" onclick="goToLevel(2)"></button>
      <button class="level-btn l3" onclick="goToLevel(3)"></button>
      <button class="level-btn l4" onclick="goToLevel(4)"></button>
      <button class="level-btn l5" onclick="goToLevel(5)"></button>
      <button class="level-btn l6" onclick="goToLevel(6)"></button>
      <button class="level-btn l7" onclick="goToLevel(7)"></button>
      <button class="level-btn l8" onclick="goToLevel(8)"></button>
    </div>
    <button onclick="window.location.href='../menu-materi.php'" 
  style="
    position: fixed;
    bottom: 60px;
    right: 20px;
    background: none;
    border: none;
    padding: 0;
    cursor: pointer;
    z-index: 9999;">
  <img src="../../foto/back.png" alt="Kembali" style="width:100px; height: auto;">
</button>


    <script>
      function goToLevel(id) {
        window.location.href = "soal_level.php?id_level=" + id;
      }
    </script>
  </body>
</html>
