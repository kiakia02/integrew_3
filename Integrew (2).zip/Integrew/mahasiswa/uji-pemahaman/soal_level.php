<?php
include '../../db.php'; // sesuaikan path jika perlu

$id_level = isset($_GET['id_level']) ? (int)$_GET['id_level'] : 1;

// Ambil data level
$level = $conn->query("SELECT * FROM level WHERE id_level = $id_level")->fetch_assoc();

// Ambil soal-soal level ini
$soal = $conn->query("SELECT * FROM soal_level WHERE id_level = $id_level");

$semua_soal = [];
while ($row = $soal->fetch_assoc()) {
  $row['pertanyaan'] = $row['pertanyaan']; // Tidak perlu htmlspecialchars() untuk MathJax
  $row['pembahasan'] = $row['pembahasan']; // Tambahkan pembahasan
    $semua_soal[] = $row;
    
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Level <?= $id_level ?> - <?= $level['nama_level'] ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
  <script id="MathJax-script" async
        src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

  <style>
    body {
      font-family: sans-serif;
      padding: 1.5rem;
      background:rgb(197, 223, 213);
      max-width: 500px;
      margin: auto;
    }
    .soal-box {
      background: white;
      padding: 1.5rem;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .opsi {
      margin: 10px 0;
    }
    .opsi button {
      width: 100%;
      padding: 10px;
      margin: 5px 0;
      font-size: 1rem;
      border-radius: 10px;
      border: 1px solid #ccc;
      cursor: pointer;
    }
    .opsi button:hover {
      background: #e0f7fa;
    }
    .feedback {
      margin-top: 1rem;
      font-weight: bold;
    }
    .btn-next {
      margin-top: 1rem;
      padding: 0.5rem 1rem;
      font-weight: bold;
      background: #4caf50;
      color: white;
      border: none;
      border-radius: 8px;
      display: none;
      cursor: pointer;
    }
    .btn-pembahasan {
      margin-top: 0.5rem;
      padding: 0.5rem 1rem;
      font-weight: bold;
      background: #2196f3;
      color: white;
      border: none;
      border-radius: 8px;
      text-decoration: none;
      display: none;
      cursor: pointer;
      margin-right: 10px;
    }
    .btn-pembahasan:hover {
      background: #1976d2;
      color: white;
      text-decoration: none;
    }
    .pembahasan-box {
      margin-top: 1rem;
      padding: 1rem;
      background: #f5f5f5;
      border-radius: 8px;
      border-left: 4px solid #2196f3;
      display: none;
      max-height: 60vh;
      overflow-y: auto;
      word-wrap: break-word;
      word-break: break-word;
    }
    .pembahasan-box h4 {
      margin: 0 0 10px 0;
      color: #2196f3;
    }
    .pembahasan-box #pembahasanContent {
      font-size: 0.9rem;
      line-height: 1.4;
    }
    /* Responsive untuk layar kecil */
    @media (max-width: 480px) {
      .pembahasan-box {
        max-height: 50vh;
        padding: 0.8rem;
        font-size: 0.85rem;
      }
    }
  </style>
</head>
<body>

  <h2>Level <?= $id_level ?>: <?= $level['nama_level'] ?></h2>
  <p><?= $level['deskripsi'] ?></p>

  <div class="soal-box">
    <div id="pertanyaan"></div>
    <div class="opsi" id="opsi"></div>
    <div class="feedback" id="feedback"></div>
    <div class="pembahasan-box" id="pembahasanBox">
      <h4>💡 Pembahasan:</h4>
      <div id="pembahasanContent"></div>
    </div>
    <div style="margin-top: 1rem;">
      <a href="#" class="btn-pembahasan" id="lihatPembahasan" onclick="tampilkanPembahasan()">📖 Lihat Pembahasan</a>
      <button class="btn-next" id="nextBtn" onclick="loadBerikut()">Soal Selanjutnya</button>
    </div>
  </div>

  <script>
  const semuaSoal = <?= json_encode($semua_soal, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;

  let index = 0;
  let skor = 0; // Untuk menghitung jawaban benar

  function tampilkanSoal(i) {
    if (!semuaSoal || semuaSoal.length === 0 || !semuaSoal[i]) {
      document.getElementById("pertanyaan").innerHTML = "<strong>Tidak ada soal untuk level ini.</strong>";
      return;
    }

    const soal = semuaSoal[i];
    const opsiDiv = document.getElementById("opsi");
    const opsi = ['A', 'B', 'C', 'D'];
    opsiDiv.innerHTML = "";

    let html = `<strong>${soal.pertanyaan}</strong>`;
    if (soal.gambar) {
      html += `<br><img src='gambar-soal/${soal.gambar}' style='max-width:50%; margin-top:10px; display: block; margin-left: auto; margin-right: auto;'>`;
    }
    document.getElementById("pertanyaan").innerHTML = html;

    opsi.forEach(o => {
      const btn = document.createElement("button");
      btn.innerText = o + ". " + soal["opsi_" + o.toLowerCase()];
      btn.onclick = () => cekJawaban(o, soal.jawaban_benar);
      opsiDiv.appendChild(btn);
    });

    // Reset tampilan
    document.getElementById("feedback").innerText = "";
    document.getElementById("nextBtn").style.display = "none";
    document.getElementById("lihatPembahasan").style.display = "none";
    document.getElementById("pembahasanBox").style.display = "none";

    // Set konten pembahasan
    document.getElementById("pembahasanContent").innerHTML = soal.pembahasan || "Pembahasan tidak tersedia.";

    if (window.MathJax) {
      MathJax.typesetPromise();
    }
  }

  function cekJawaban(pilih, benar) {
    const feedback = document.getElementById("feedback");
    if (pilih === benar) {
      feedback.innerText = "✅ Jawaban benar!";
      feedback.style.color = "green";
      skor++;
    } else {
      feedback.innerText = "❌ Jawaban salah. Jawaban yang benar adalah " + benar + ".";
      feedback.style.color = "red";
    }

    // Disable semua button opsi
    document.querySelectorAll("#opsi button").forEach(b => b.disabled = true);
    
    // Tampilkan button next dan lihat pembahasan
    document.getElementById("nextBtn").style.display = "inline-block";
    document.getElementById("lihatPembahasan").style.display = "inline-block";
  }

  function tampilkanPembahasan() {
    const pembahasanBox = document.getElementById("pembahasanBox");
    const lihatPembahasanBtn = document.getElementById("lihatPembahasan");
    
    if (pembahasanBox.style.display === "none" || pembahasanBox.style.display === "") {
      pembahasanBox.style.display = "block";
      lihatPembahasanBtn.innerText = "🔼 Sembunyikan Pembahasan";
      
      // Re-render MathJax jika ada formula matematika dalam pembahasan
      if (window.MathJax) {
        MathJax.typesetPromise([pembahasanBox]);
      }
    } else {
      pembahasanBox.style.display = "none";
      lihatPembahasanBtn.innerText = "📖 Lihat Pembahasan";
    }
  }

  function loadBerikut() {
    index++;
    if (index < semuaSoal.length) {
      tampilkanSoal(index);
    } else {
      const total = semuaSoal.length;
      const nilai = Math.round((skor / total) * 100);
      document.querySelector(".soal-box").innerHTML = `
        <h3>🎉 Semua soal sudah selesai!</h3>
        <p>✔️ Jawaban benar: ${skor} dari ${total} soal</p>
        <p>📊 Skor akhir: <strong>${nilai}%</strong></p>
        <a href="index.php" class="btn-next" style="margin-top:20px; display: inline-block;">← Kembali</a>
      `;
    }
  }

  // Jalankan saat halaman siap
  tampilkanSoal(index);

  </script>
 <a href="index.php" style="position: fixed; top: 20px; left: 20px; z-index: 999;">
  <img src="../../foto/back.png" alt="Kembali" style="width: 100px; height: auto; position: fixed;
    bottom: 100px;
    right: 20px;
    background: none;
    border: none;
    padding: 0;
    cursor: pointer;
    z-index: 9999;" />
</a>

</body>
</html>