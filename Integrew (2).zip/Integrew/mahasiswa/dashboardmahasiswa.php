<?php
session_start();
$nama_user = $_SESSION['nama'] ?? '';
$role = $_SESSION['role'] ?? '';

if ($role !== 'mahasiswa') {
    header('Location: login.php'); exit;
}

$host     = 'localhost';
$dbname   = 'dbintegrew';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// Hitung jumlah materi unik (jenis = 'materi')
$stmt = $pdo->prepare("SELECT COUNT(DISTINCT materi) as jumlah_materi FROM nilai WHERE nama = ? AND jenis = 'materi'");
$stmt->execute([$nama_user]);
$jumlah_materi = (int)$stmt->fetch()['jumlah_materi'];

// Hitung total poin dari quiz + latihan
$stmt = $pdo->prepare("SELECT SUM(skor) as total_poin FROM nilai WHERE nama = ? AND jenis IN ('quiz','latihan')");
$stmt->execute([$nama_user]);
$total_poin = (int)$stmt->fetch()['total_poin'];

// Ambil nilai quiz dan latihan pertama
$stmt = $pdo->prepare("SELECT materi, skor, jenis FROM nilai WHERE nama = ? AND jenis IN ('quiz', 'latihan') ORDER BY tanggal ASC");
$stmt->execute([$nama_user]);
$nilai_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Inisialisasi array untuk menyimpan poin
$quiz_points = [];
$latihan_points = [];

// Proses nilai untuk quiz dan latihan
foreach ($nilai_data as $nilai) {
    if ($nilai['jenis'] === 'quiz' && !isset($quiz_points[$nilai['materi']])) {
        $quiz_points[$nilai['materi']] = $nilai['skor'];
    } elseif ($nilai['jenis'] === 'latihan' && !isset($latihan_points[$nilai['materi']])) {
        $latihan_points[$nilai['materi']] = $nilai['skor'];
    }
}

// Hitung jumlah quiz dan latihan
$jumlah_quiz = count($quiz_points);
$jumlah_latihan = count($latihan_points);

// Hitung progress
$total_materi = 6; // total materi yang tersedia di sistem
$progress = $total_materi > 0 ? ($jumlah_materi / $total_materi) * 100 : 0;

?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Integrew - Game Edukasi</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
  <style>
    :root {
      --primary: #6366f1;
      --primary-dark: #4f46e5;
      --secondary: #f59e0b;
      --accent: #10b981;
      --danger: #ef4444;
      --success: #22c55e;
      --light: #f8fafc;
      --dark: #1e293b;
      --card-bg: #ffffff;
      --text-light: #64748b;
      --border: #e2e8f0;
      --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
      --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
      --gradient-primary: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      background: var(--gradient-primary);
      min-height: 100vh;
      color: var(--dark);
      overflow-x: hidden;
    }

    /* Animated Background */
    .bg-decoration {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -1;
      overflow: hidden;
    }

    .floating-shape {
      position: absolute;
      opacity: 0.08;
      animation: float 8s ease-in-out infinite;
      color: white;
    }

    .floating-shape:nth-child(1) {
      top: 15%;
      left: 10%;
      animation-delay: 0s;
      font-size: 3rem;
    }

    .floating-shape:nth-child(2) {
      top: 25%;
      right: 15%;
      animation-delay: 2.5s;
      font-size: 2.5rem;
    }

    .floating-shape:nth-child(3) {
      bottom: 20%;
      left: 25%;
      animation-delay: 5s;
      font-size: 3.5rem;
    }

    .floating-shape:nth-child(4) {
      top: 60%;
      right: 25%;
      animation-delay: 7s;
      font-size: 2rem;
    }

    @keyframes float {
      0%, 100% { 
        transform: translateY(0px) rotate(0deg) scale(1); 
      }
      25% { 
        transform: translateY(-15px) rotate(5deg) scale(1.1); 
      }
      50% { 
        transform: translateY(-25px) rotate(10deg) scale(1.05); 
      }
      75% { 
        transform: translateY(-10px) rotate(-5deg) scale(1.08); 
      }
    }

    /* Header Styles */
    .header {
      background: linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 100%);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,0.2);
      color: white;
      padding: 24px 20px;
      text-align: center;
      border-radius: 0 0 30px 30px;
      position: relative;
      margin-bottom: 24px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
    }

    .header::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%);
      animation: shimmer 4s infinite;
      border-radius: 0 0 30px 30px;
    }

    @keyframes shimmer {
      0% { transform: translateX(-100%); }
      100% { transform: translateX(100%); }
    }

    .header h1 {
      font-size: 2.5rem;
      font-weight: 800;
      margin-bottom: 10px;
      text-shadow: 2px 2px 8px rgba(0,0,0,0.3);
      position: relative;
      z-index: 2;
      background: linear-gradient(45deg, #ffffff, #f0f9ff);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .header-subtitle {
      font-size: 1.1rem;
      font-weight: 500;
      opacity: 0.95;
      margin-bottom: 12px;
      position: relative;
      z-index: 2;
      text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
    }

    .header-username {
      font-size: 0.95rem;
      background: rgba(255,255,255,0.25);
      padding: 8px 16px;
      border-radius: 25px;
      display: inline-block;
      position: relative;
      z-index: 2;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.3);
      font-weight: 500;
    }

    .logout-btn {
      position: absolute;
      right: 20px;
      top: 20px;
      padding: 10px 18px;
      background: var(--danger);
      color: white;
      border: none;
      border-radius: 25px;
      text-decoration: none;
      font-size: 0.9rem;
      font-weight: 600;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      z-index: 3;
      box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    }

    .logout-btn:hover {
      background: #dc2626;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
    }

    .logout-btn i {
      margin-right: 6px;
    }

    /* Container */
    .container {
      padding: 0 20px 24px;
      max-width: 500px;
      margin: 0 auto;
    }

    /* Game Cards */
    .game-menu {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 18px;
      margin-bottom: 28px;
    }

    .game-card {
      background: var(--card-bg);
      border-radius: 24px;
      padding: 24px 16px;
      text-align: center;
      box-shadow: 0 8px 25px rgba(0,0,0,0.08);
      border: 1px solid rgba(255,255,255,0.8);
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
      position: relative;
      overflow: hidden;
      text-decoration: none;
      color: inherit;
      min-height: 150px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      backdrop-filter: blur(10px);
    }

    .game-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: var(--gradient-primary);
      opacity: 0;
      transition: opacity 0.4s ease;
      border-radius: 24px;
    }

    .game-card:hover {
      transform: translateY(-12px) scale(1.03);
      box-shadow: 0 20px 40px rgba(0,0,0,0.15);
      border-color: rgba(255,255,255,1);
    }

    .game-card:hover::before {
      opacity: 0.05;
    }

    .game-card:active {
      transform: translateY(-4px) scale(0.98);
    }

    .game-card i {
      font-size: 2.8rem;
      margin-bottom: 14px;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      z-index: 2;
    }

    .game-card:hover i {
      transform: scale(1.15) rotate(5deg);
    }

    .game-card h3 {
      font-size: 1.2rem;
      font-weight: 700;
      margin-bottom: 8px;
      color: var(--dark);
      position: relative;
      z-index: 2;
    }

    .game-card p {
      font-size: 0.9rem;
      color: var(--text-light);
      font-weight: 500;
      position: relative;
      z-index: 2;
      line-height: 1.4;
    }

    /* Card specific colors */
    .game-card.materi i { 
      color: var(--accent);
    }
    .game-card.kalkulator i { 
      color: var(--secondary); 
    }
    .game-card.quiz i { 
      color: var(--danger); 
    }
    .game-card.progress i { 
      color: var(--primary); 
    }

    .game-card.materi:hover i { color: #059669; }
    .game-card.kalkulator:hover i { color: #d97706; }
    .game-card.quiz:hover i { color: #dc2626; }
    .game-card.progress:hover i { color: var(--primary-dark); }

    /* Progress Section */
    .progress-section {
      background: var(--card-bg);
      border-radius: 24px;
      padding: 28px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.08);
      border: 1px solid rgba(255,255,255,0.8);
      margin-bottom: 24px;
      backdrop-filter: blur(10px);
    }

    .progress-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 20px;
    }

    .progress-header h3 {
      font-size: 1.3rem;
      font-weight: 700;
      color: var(--dark);
    }

    .progress-header i {
      margin-right: 8px;
      color: var(--primary);
    }

    .progress-percentage {
      background: var(--gradient-primary);
      color: white;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 0.9rem;
      font-weight: 700;
      box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
    }

    .progress-bar-container {
      background: #e2e8f0;
      height: 14px;
      border-radius: 12px;
      overflow: hidden;
      margin-bottom: 16px;
      position: relative;
      box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
    }

    .progress-bar {
      height: 100%;
      background: linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%);
      width: 65%;
      border-radius: 12px;
      position: relative;
      animation: progressFill 2.5s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 2px 8px rgba(99, 102, 241, 0.4);
    }

    .progress-bar::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.4) 50%, transparent 100%);
      animation: progressShine 3s infinite;
      border-radius: 12px;
    }

    @keyframes progressFill {
      from { width: 0%; }
      to { width: 65%; }
    }

    @keyframes progressShine {
      0% { transform: translateX(-100%); }
      100% { transform: translateX(100%); }
    }

    .progress-stats {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
      margin-top: 20px;
    }

    .stat-item {
      text-align: center;
      padding: 16px 12px;
      background: var(--light);
      border-radius: 16px;
      border: 1px solid var(--border);
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }

    .stat-item::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: var(--gradient-primary);
    }

    .stat-item:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow);
    }

    .stat-number {
      font-size: 1.4rem;
      font-weight: 800;
      color: var(--primary);
      display: block;
      margin-bottom: 4px;
    }

    .stat-label {
      font-size: 0.8rem;
      color: var(--text-light);
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    /* Achievements Section */
    .achievements {
      background: var(--card-bg);
      border-radius: 24px;
      padding: 24px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.08);
      border: 1px solid rgba(255,255,255,0.8);
      backdrop-filter: blur(10px);
    }

    .achievements h3 {
      font-size: 1.2rem;
      font-weight: 700;
      margin-bottom: 20px;
      color: var(--dark);
      text-align: center;
    }

    .achievements h3 i {
      margin-right: 8px;
      color: var(--secondary);
    }

    .achievement-list {
      display: flex;
      gap: 14px;
      overflow-x: auto;
      padding-bottom: 8px;
      scrollbar-width: none;
      -ms-overflow-style: none;
    }

    .achievement-list::-webkit-scrollbar {
      display: none;
    }

    .achievement-item {
      min-width: 70px;
      text-align: center;
      padding: 16px 12px;
      background: var(--light);
      border-radius: 16px;
      border: 2px solid var(--border);
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }

    .achievement-item.earned {
      background: linear-gradient(135deg, var(--secondary) 0%, #f59e0b 100%);
      color: white;
      transform: scale(1.05);
      border-color: var(--secondary);
      box-shadow: 0 8px 25px rgba(245, 158, 11, 0.3);
    }

    .achievement-item.earned::before {
      content: '';
      position: absolute;
      top: -2px;
      left: -2px;
      right: -2px;
      bottom: -2px;
      background: linear-gradient(45deg, #f59e0b, #fbbf24, #f59e0b);
      z-index: -1;
      border-radius: 16px;
      animation: achievementGlow 2s infinite alternate;
    }

    @keyframes achievementGlow {
      0% { opacity: 0.8; }
      100% { opacity: 1; }
    }

    .achievement-item:hover:not(.earned) {
      transform: translateY(-4px);
      border-color: var(--primary);
    }

    .achievement-item i {
      font-size: 1.6rem;
      margin-bottom: 6px;
      color: var(--text-light);
      transition: all 0.3s ease;
    }

    .achievement-item.earned i {
      color: white;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }

    .achievement-label {
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }

    /* Add Quiz Card */
    .quiz-coming-soon {
      opacity: 0.7;
      position: relative;
    }

    .quiz-coming-soon::after {
      content: 'Segera';
      position: absolute;
      top: 8px;
      right: 8px;
      background: var(--accent);
      color: white;
      font-size: 0.7rem;
      padding: 4px 8px;
      border-radius: 12px;
      font-weight: 600;
      z-index: 3;
    }

    /* Responsive Design */
    @media (max-width: 480px) {
      .header {
        padding: 20px 16px;
      }
      
      .header h1 {
        font-size: 2rem;
      }
      
      .container {
        padding: 0 16px 20px;
      }
      
      .game-menu {
        gap: 14px;
      }
      
      .game-card {
        padding: 20px 14px;
        min-height: 130px;
      }
      
      .game-card i {
        font-size: 2.3rem;
      }
      
      .progress-section {
        padding: 24px 20px;
      }
      
      .logout-btn {
        padding: 8px 14px;
        font-size: 0.85rem;
        right: 16px;
        top: 16px;
      }

      .achievements {
        padding: 20px;
      }
    }

    @media (max-width: 360px) {
      .game-menu {
        grid-template-columns: 1fr;
      }
      
      .game-card {
        padding: 24px 20px;
        min-height: 120px;
      }
      
      .progress-stats {
        grid-template-columns: repeat(2, 1fr);
      }

      .stat-item:last-child {
        grid-column: 1 / -1;
        max-width: 200px;
        margin: 0 auto;
      }
    }

    /* Loading Animation */
    .loading {
      display: inline-block;
      width: 20px;
      height: 20px;
      border: 3px solid rgba(255,255,255,0.3);
      border-radius: 50%;
      border-top-color: white;
      animation: spin 1s ease-in-out infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    /* Enhanced Ripple Effect */
    .ripple {
      position: absolute;
      border-radius: 50%;
      background: rgba(99, 102, 241, 0.3);
      transform: scale(0);
      animation: ripple-animation 0.6s linear;
      pointer-events: none;
    }

    @keyframes ripple-animation {
      to {
        transform: scale(4);
        opacity: 0;
      }
    }

    /* Smooth transitions for all interactive elements */
    * {
      transition: transform 0.2s ease;
    }

    /* Dark mode support */
    @media (prefers-color-scheme: dark) {
      :root {
        --card-bg: #1e293b;
        --light: #0f172a;
        --dark: #f1f5f9;
        --text-light: #94a3b8;
        --border: #334155;
      }
      
      .header {
        background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%);
      }
    }

    /* Accessibility improvements */
    @media (prefers-reduced-motion: reduce) {
      *,
      *::before,
      *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
      }
    }

    /* Focus styles for keyboard navigation */
    .game-card:focus,
    .logout-btn:focus {
      outline: 3px solid rgba(99, 102, 241, 0.5);
      outline-offset: 2px;
    }
  </style>
</head>
<body>
  <!-- Animated Background -->
  <div class="bg-decoration">
    <div class="floating-shape">
      <i class="fas fa-calculator"></i>
    </div>
    <div class="floating-shape">
      <i class="fas fa-chart-line"></i>
    </div>
    <div class="floating-shape">
      <i class="fas fa-book"></i>
    </div>
    <div class="floating-shape">
      <i class="fas fa-graduation-cap"></i>
    </div>
  </div>

  <!-- Header -->
  <header class="header">
    <a href="logout.php" class="logout-btn">
      <i class="fas fa-sign-out-alt"></i> Logout
    </a>
    <h1><i class="fas fa-graduation-cap"></i> Integrew</h1>
    <p class="header-subtitle">Game Edukasi Integral</p>
    <div class="header-username">
      <i class="fas fa-user"></i> Halo, <?= htmlspecialchars($_SESSION['username']) ?>!
    </div>
  </header>

  <!-- Main Container -->
  <div class="container">
    <!-- Game Menu -->
    <div class="game-menu">
      <a href="menu-materi.php" class="game-card materi">
        <i class="fas fa-book-open"></i>
        <h3>Materi</h3>
        <p>Pelajari Dasar Integral</p>
      </a>

      <a href="kalkulator.php" class="game-card kalkulator" style="margin-top:3px;">
        <i class="fas fa-calculator "></i>
        <h3>Kalkulator</h3>
        <p>Hitung Integral</p>
      </a>
  </div>


<script>
    // Enhanced JavaScript functionality
    document.addEventListener('DOMContentLoaded', function() {
  const progressBar = document.querySelector('.progress-bar');
  if (progressBar) {
    const targetWidth = progressBar.getAttribute('data-target'); // ambil dari data attribute
    progressBar.style.width = '0%'; // mulai dari 0%
    setTimeout(() => {
      progressBar.style.width = targetWidth + '%'; // animasi ke target
    }, 300);
  }
});


      // Animate achievement badges on scroll
      const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
      };

      const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.style.animation = 'fadeIn 0.6s ease-out forwards';
            entry.target.style.animationDelay = '0.2s';
          }
        });
      }, observerOptions);

      // Observe achievement items
      document.querySelectorAll('.achievement-item').forEach(item => {
        observer.observe(item);
      });

      // Add loading states for navigation
      document.querySelectorAll('a[href]').forEach(link => {
        link.addEventListener('click', function(e) {
          const icon = this.querySelector('i');
          if (icon && !icon.classList.contains('fa-sign-out-alt')) {
            const originalClass = icon.className;
            icon.className = 'fas fa-spinner fa-spin';
            
            // Restore original icon if navigation fails
            setTimeout(() => {
              icon.className = originalClass;
            }, 3000);
          }
        });
      });

      // Keyboard navigation support
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
          document.body.classList.add('keyboard-navigation');
        }
      });

      document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-navigation');
      });

      // Add smooth scrolling for better UX
      document.documentElement.style.scrollBehavior = 'smooth';
    });

    // Enhanced quiz modal with better UX
    function showQuizModal() {
      // Create modal overlay
      const overlay = document.createElement('div');
      overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
        backdrop-filter: blur(5px);
      `;

      const modal = document.createElement('div');
      modal.style.cssText = `
        background: white;
        padding: 32px;
        border-radius: 24px;
        text-align: center;
        max-width: 400px;
        margin: 20px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        animation: modalSlideIn 0.3s ease-out;
      `;

      modal.innerHTML = `
        <div style="font-size: 3rem; color: #6366f1; margin-bottom: 16px;">
          <i class="fas fa-gamepad"></i>
        </div>
        <h3 style="color: #1e293b; margin-bottom: 12px; font-size: 1.4rem;">Quiz Game</h3>
        <p style="color: #64748b; margin-bottom: 24px; line-height: 1.5;">
          Fitur Quiz Game sedang dalam pengembangan dan akan segera tersedia! 🎮
        </p>
        <div style="display: flex; gap: 12px; justify-content: center;">
          <button onclick="this.closest('.modal-overlay').remove()" 
                  style="padding: 12px 24px; background: #6366f1; color: white; border: none; 
                         border-radius: 12px; font-weight: 600; cursor: pointer; 
                         transition: all 0.3s ease;">
            OK, Mengerti
          </button>
        </div>
      `;

      overlay.className = 'modal-overlay';
      overlay.appendChild(modal);
      document.body.appendChild(overlay);

      // Add modal animation CSS
      if (!document.getElementById('modal-styles')) {
        const style = document.createElement('style');
        style.id = 'modal-styles';
        style.textContent = `
          @keyframes modalSlideIn {
            from {
              opacity: 0;
              transform: translateY(-50px) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translateY(0) scale(1);
            }
          }
          .modal-overlay button:hover {
            background: #4f46e5 !important;
            transform: translateY(-2px);
          }
        `;
        document.head.appendChild(style);
      }

      // Close modal on overlay click
      overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
          overlay.remove();
        }
      });

      // Close modal on Escape key
      const escapeHandler = function(e) {
        if (e.key === 'Escape') {
          overlay.remove();
          document.removeEventListener('keydown', escapeHandler);
        }
      };
      document.addEventListener('keydown', escapeHandler);
    }
document.addEventListener('DOMContentLoaded', function() {
  const progressBar = document.querySelector('.progress-bar');
  if (progressBar) {
    const targetWidth = progressBar.getAttribute('data-target');
    progressBar.style.width = '0%';
    setTimeout(() => {
      progressBar.style.width = targetWidth + '%';
    }, 300);
  }
});

// Fungsi showPoints tetap
function showPoints(type) {
  let points = '';
  if (type === 'quiz') {
    points = <?= json_encode($quiz_points) ?>;
    let message = 'Poin untuk Quiz:\n';
    for (const [materi, skor] of Object.entries(points)) {
      message += `Quiz - ${materi}: ${skor} Poin\n`;
    }
    alert(message);
  } else if (type === 'latihan') {
    points = <?= json_encode($latihan_points) ?>;
    let message = 'Poin untuk Latihan:\n';
    for (const [materi, skor] of Object.entries(points)) {
      message += `Latihan - ${materi}: ${skor} Poin\n`;
    }
    alert(message);
  } else if (type === 'total') {
    alert('Total Poin: ' + <?= json_encode($total_poin) ?>);
  }
}
    // Event listeners for quiz and latihan cards
    document.querySelector('.game-card.quiz').addEventListener('click', function() {
      if (<?= $quiz_done ?>) {
        alert('Anda sudah menyelesaikan kuis ini.');
      } else {
        showPoints('quiz');
      }
    });

    document.querySelector('.game-card.latihan').addEventListener('click', function() {
      if (<?= $latihan_done ?>) {
        alert('Anda sudah menyelesaikan latihan ini.');
      } else {
        showPoints('latihan');
      }
    });
    // Service Worker Registration for PWA capabilities
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js').then(function(registration) {
          console.log('SW registered: ', registration);
        }).catch(function(registrationError) {
          console.log('SW registration failed: ', registrationError);
        });
      });
    }

    // Performance optimization - lazy load non-critical features
    setTimeout(() => {
      // Add fade-in animation for achievement items
      const style = document.createElement('style');
      style.textContent = `
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `;
      document.head.appendChild(style);
    }, 100);

    // Add touch feedback for mobile devices
    if ('ontouchstart' in window) {
      document.querySelectorAll('.game-card, .logout-btn, .stat-item').forEach(element => {
        element.addEventListener('touchstart', function() {
          this.style.transform = 'scale(0.95)';
        });
        
        element.addEventListener('touchend', function() {
          setTimeout(() => {
            this.style.transform = '';
          }, 150);
        });
      });
    }

    // Add error handling for navigation
    window.addEventListener('beforeunload', function(e) {
      const loadingIcons = document.querySelectorAll('.fa-spinner');
      loadingIcons.forEach(icon => {
        // Reset any loading states
        icon.className = icon.getAttribute('data-original-class') || 'fas fa-gamepad';
      });
    });
  </script>
</body>
</html>