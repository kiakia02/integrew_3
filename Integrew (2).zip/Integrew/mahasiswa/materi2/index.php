<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Luas Daerah dengan Integral</title>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Rubik+Bubbles&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Open Sans', sans-serif;
      text-align: center;
      background-color: #fff;
      padding: 2rem;
    }

    .title-box {
      display: inline-block;
      border: 4px solid black;
      border-radius: 20px;
      padding: 1rem 2rem;
      font-family: 'Rubik Bubbles', cursive;
      font-size: 20px;
      color: #D55050;
      box-shadow: 4px 6px #db719b;
      margin-bottom: 2rem;
    }

    h2 {
      font-family: 'Rubik Bubbles', cursive;
      font-size: 24x;
      color: #cc5e5e;
      letter-spacing: 1px;
      margin-bottom: 30px;
    }

    .rumus {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      gap: 2rem;
      flex-wrap: wrap;
      margin-bottom: 3rem;
    }

    .rumus-box {
      display: flex;
      flex-direction: column;
      align-items: center;
      max-width: 180px;
      cursor: pointer;
    }

    .rumus-title {
      font-family: 'Rubik Bubbles', cursive;
      font-size: 12px;
      color: #cc5e5e;
      margin-bottom: 0.5rem;
    }

    .rumus-box img {
      width: 100%;
      max-width: 180px;
      height: auto;
      border-radius: 15px;
    }

    .button {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
    }

    .button button {
      padding: 12px 20px;
      background-color: #ff5757;
      border: 2px solid #f4b9d3;
      border-bottom: 6px solid #a73832;
      color: white;
      font-family: 'Rubik Bubbles', cursive;
      font-size: 20px;
      border-radius: 30px;
      width: 200px;
      cursor: pointer;
    }

    .popup {
  display: none;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #ffffcc;
  border: 2px solid #333;
  padding: 20px;
  width: 90%;
  max-width: 320px;
  z-index: 1000;
  border-radius: 15px;
  box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
  text-align: left;
  font-weight: bold;
  box-sizing: border-box; 
}

    .close-btn {
      position: absolute;
      right: 12px;
      top: 8px;
      font-size: 20px;
      cursor: pointer;
      color: #a73832;
    }

    @media screen and (max-width: 500px) {
      .rumus {
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: center;
        gap: 1rem;
      }

      .rumus-box {
        width: 45%;
      }

      .rumus-box img {
        width: 100%;
      }

      .popup {
        width: calc(100% - 40px); /* ✅ biar ada celah kiri kanan 20px */
        font-size: 10px;
        font-weight:100;
        }
    }
        .btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
  </style>
</head>
<body>

  <div class="title-box">Menghitung luas daerah menggunakan integral</div>

  <div class="rumus">
    <div class="rumus-box" id="rumusY">
      <div class="rumus-title">Luas berdasarkan garis Y</div>
      <img src="gambar/integrew-1.png" alt="Rumus Garis Y">
    </div>
    <div class="rumus-box" id="rumusX">
      <div class="rumus-title">Luas berdasarkan garis X</div>
      <img src="gambar/integrew-2.png" alt="Rumus Garis X">
    </div>
  </div>

  <div class="button">
    <button onclick="location.href='latihansoal.php'">Latihan Soal</button>
  <button onclick="location.href='kuis.php'">Kuis</button>
  </div>
  <div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='../menu-materi.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>

  <!-- Popup Penjelasan Garis Y (dx) -->
  <div class="popup" id="popupY">
    <span class="close-btn" onclick="closePopup('popupY')">&times;</span>
    <p><strong><b>Keterangan</b></strong></p>
    <ul style="padding-left: 1rem;">
      <li><strong>x<sub>2</sub>, x<sub>1</sub></strong> = batas bawah dan atas integral pada sumbu <strong>x</strong>.</li>
      <li><strong>y<sub>atas</sub></strong> = fungsi di bagian <strong>atas</strong> dari daerah (terhadap x).</li>
      <li><strong>y<sub>bawah</sub></strong> = fungsi di bagian <strong>bawah</strong> dari daerah (terhadap x).</li>
      <li><strong>dx</strong> = elemen panjang kecil pada sumbu x (lebar potongan vertikal).</li>
    </ul>
  </div>

  <!-- Popup Penjelasan Garis X (dy) -->
  <div class="popup" id="popupX">
    <span class="close-btn" onclick="closePopup('popupX')">&times;</span>
    <p><strong><b>Keterangan</b></strong></p>
    <ul style="padding-left: 1rem;">
      <li><strong>y<sub>2</sub>, y<sub>1</sub></strong> = batas bawah dan atas integral pada sumbu <strong>y</strong>.</li>
      <li><strong>x<sub>kanan</sub></strong> = fungsi paling <strong>kanan</strong>(terhadap y).</li>
      <li><strong>x<sub>kiri</sub></strong> = fungsi paling<strong> kiri</strong>(terhadap y).</li>
      <li><strong>dy</strong> = elemen panjang kecil pada sumbu y (lebar potongan horizontal).</li>
    </ul>
  </div>

  <script>
    function closePopup(id) {
      document.getElementById(id).style.display = "none";
    }

    document.getElementById("rumusY").addEventListener("click", function () {
      document.getElementById("popupY").style.display = "block";
    });

    document.getElementById("rumusX").addEventListener("click", function () {
      document.getElementById("popupX").style.display = "block";
    });

    window.addEventListener("click", function (event) {
      if (event.target.classList.contains("popup")) {
        event.target.style.display = "none";
      }
    });
  </script>

</body>
</html>
