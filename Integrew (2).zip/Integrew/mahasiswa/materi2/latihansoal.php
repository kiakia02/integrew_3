<?php
// latihansoal.php
session_start();

// Konfigurasi database
$host     = 'localhost';
$dbname   = 'dbintegrew';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// Pastikan user sudah login dan punya kelas
if (!isset($_SESSION['kelas']) || empty($_SESSION['kelas'])) {
    die("Anda harus login terlebih dahulu dan memiliki kelas yang terdaftar.");
}

// Ambil kelas user dari session dan bersihkan dari spasi berlebih
$kelas_user = trim($_SESSION['kelas']); // contoh: '1 TRPL A' atau '1 TRPL B'

// Ambil parameter latihan_id (opsional)
$latihan_id = isset($_GET['latihan_id']) ? (int)$_GET['latihan_id'] : null;

// Tentukan materi khusus
$materi_khusus = 'materi2';

// Siapkan query sesuai kondisi
if ($latihan_id) {
    // Ambil soal sesuai latihan_id, materi, dan kelas
    $stmt = $pdo->prepare("SELECT * FROM latihansoal WHERE id = ? AND materi = ? AND TRIM(kelas) = ? ORDER BY id ASC");
    $stmt->execute([$latihan_id, $materi_khusus, $kelas_user]);
} else {
    // Ambil semua soal untuk materi dan kelas user
    $stmt = $pdo->prepare("SELECT * FROM latihansoal WHERE materi = ? AND TRIM(kelas) = ? ORDER BY id ASC");
    $stmt->execute([$materi_khusus, $kelas_user]);
}

// Ambil hasilnya
$soal_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Cek jika tidak ada soal
if (empty($soal_data)) {
    // Cek apakah ada soal untuk kelas ini di database (untuk debugging)
    $check_stmt = $pdo->prepare("SELECT COUNT(*) as total FROM latihansoal WHERE materi = ?");
    $check_stmt->execute([$materi_khusus]);
    $total_soal_materi = $check_stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    if ($total_soal_materi > 0) {
        die("Tidak ada soal latihan untuk kelas: <strong>" . htmlspecialchars($kelas_user) . "</strong> pada materi: <strong>" . htmlspecialchars($materi_khusus) . "</strong>.<br>
             Silakan hubungi admin untuk menambahkan soal untuk kelas Anda.");
    } else {
        die("Tidak ada soal latihan untuk materi: <strong>" . htmlspecialchars($materi_khusus) . "</strong>.<br>
             Silakan hubungi admin untuk menambahkan soal.");
    }
}

// Validasi bahwa semua soal benar-benar untuk kelas user
$valid_soal = [];
foreach ($soal_data as $soal) {
    if (trim($soal['kelas']) === $kelas_user) {
        $valid_soal[] = $soal;
    }
}

// Gunakan soal yang valid
$soal_data = $valid_soal;

// Cek lagi setelah validasi
if (empty($soal_data)) {
    die("Tidak ada soal latihan yang valid untuk kelas: <strong>" . htmlspecialchars($kelas_user) . "</strong>");
}

// Siapkan data latihan
$first_soal = $soal_data[0]; // pakai soal pertama sebagai sumber judul dll

$latihan_data = [
    'judul_latihan' => $first_soal['judul_latihan'],
    'kelas'         => $first_soal['kelas'],
    'materi'        => $first_soal['materi'],
    'soal'          => []
];

// Format soal
foreach ($soal_data as $soal) {
    $latihan_data['soal'][] = [
        'id'           => $soal['id'],
        'soal_text'    => $soal['soal'],
        'opsi_a'       => $soal['opsi_a'],
        'opsi_b'       => $soal['opsi_b'],
        'opsi_c'       => $soal['opsi_c'],
        'opsi_d'       => $soal['opsi_d'],
        'jawaban'      => $soal['jawaban'],
        'opsijawaban'  => $soal['opsijawaban']
    ];
}

// Hitung total soal
$total_soal = count($latihan_data['soal']);

// Log aktivitas (opsional - untuk tracking)
try {
    $log_stmt = $pdo->prepare("INSERT INTO latihan_log (kelas, materi, total_soal, tanggal_akses) VALUES (?, ?, ?, NOW())");
    $log_stmt->execute([$kelas_user, $materi_khusus, $total_soal]);
} catch (Exception $e) {
    // Jika tabel log tidak ada, abaikan error ini
    // error_log("Latihan log error: " . $e->getMessage());
}

// Sekarang $latihan_data siap digunakan di halaman tampilan (HTML)
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $latihan_data['judul_latihan']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 30px;
            backdrop-filter: blur(20px);
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            animation: slideUp 0.8s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header {
            background: linear-gradient(135deg, #4a90e2, #357abd);
            color: white;
            padding: 40px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }

        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .header h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
        }

        .latihan-info {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 20px;
            position: relative;
            z-index: 1;
        }

        .info-item {
            background: rgba(255, 255, 255, 0.2);
            padding: 10px 20px;
            border-radius: 20px;
            font-weight: 600;
        }

        .latihan-container {
            padding: 40px;
        }

        .progress-section {
            margin-bottom: 30px;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e0e0e0;
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4CAF50, #45a049);
            width: 0%;
            border-radius: 10px;
            transition: width 0.5s ease;
        }

        .progress-text {
            text-align: center;
            margin-top: 10px;
            font-weight: 600;
            color: #333;
        }

        .question-card {
            background: #f8f9ff;
            border: 2px solid transparent;
            border-radius: 25px;
            padding: 40px;
            margin-bottom: 30px;
            transition: all 0.3s ease;
            display: none;
            animation: fadeInUp 0.6s ease;
        }

        .question-card.active {
            display: block;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .question-number {
            background: linear-gradient(135deg, #4a90e2, #357abd);
            color: white;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 18px;
            margin-bottom: 20px;
        }

        .question-text {
            font-size: 20px;
            font-weight: 600;
            color: #333;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .options-container {
            display: grid;
            gap: 15px;
        }

        .option {
            background: white;
            border: 2px solid #e1e5e9;
            border-radius: 15px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .option::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(74, 144, 226, 0.05), transparent);
            transition: left 0.6s;
        }

        .option:hover::before {
            left: 100%;
        }

        .option:hover {
            border-color: #4a90e2;
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(74, 144, 226, 0.1);
        }

        .option.selected {
            border-color: #4a90e2;
            background: linear-gradient(135deg, rgba(74, 144, 226, 0.1), rgba(53, 122, 189, 0.1));
        }

        .option.correct {
            border-color: #4CAF50;
            background: linear-gradient(135deg, rgba(76, 175, 80, 0.1), rgba(69, 160, 73, 0.1));
        }

        .option.wrong {
            border-color: #f44336;
            background: linear-gradient(135deg, rgba(244, 67, 54, 0.1), rgba(229, 57, 53, 0.1));
        }

        .option-label {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 35px;
            height: 35px;
            background: linear-gradient(135deg, #4a90e2, #357abd);
            color: white;
            border-radius: 50%;
            font-weight: bold;
            margin-right: 15px;
            font-size: 16px;
        }

        .option-text {
            font-size: 16px;
            font-weight: 500;
        }

        .navigation-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 40px;
            padding-top: 30px;
            border-top: 2px solid #f0f0f0;
        }

        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #4a90e2, #357abd);
            color: white;
            box-shadow: 0 8px 25px rgba(74, 144, 226, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(74, 144, 226, 0.4);
        }

        .btn-secondary {
            background: #f8f9fa;
            color: #333;
            border: 2px solid #e1e5e9;
        }

        .btn-secondary:hover {
            background: #e9ecef;
            transform: translateY(-2px);
        }

        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none !important;
        }

        .explanation {
            background: linear-gradient(135deg, rgba(76, 175, 80, 0.05), rgba(69, 160, 73, 0.05));
            border: 2px solid #4CAF50;
            border-radius: 20px;
            padding: 25px;
            margin-top: 20px;
            display: none;
            animation: fadeIn 0.5s ease;
        }

        .explanation.show {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .explanation-title {
            font-weight: 700;
            color: #4CAF50;
            margin-bottom: 10px;
            font-size: 18px;
        }

        .explanation-text {
            color: #333;
            line-height: 1.6;
        }

        .results-section {
            display: none;
            text-align: center;
            padding: 60px 40px;
        }

        .results-section.show {
            display: block;
            animation: fadeInUp 0.8s ease;
        }

        .score-circle {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: conic-gradient(#4CAF50 0deg, #4CAF50 0deg, #e0e0e0 0deg);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            position: relative;
            animation: scoreAnimation 2s ease;
        }

        @keyframes scoreAnimation {
            from { transform: scale(0) rotate(0deg); }
            to { transform: scale(1) rotate(360deg); }
        }

        .score-text {
            font-size: 48px;
            font-weight: 700;
            color: #333;
        }

        .results-title {
            font-size: 32px;
            font-weight: 700;
            color: #333;
            margin-bottom: 20px;
        }

        .results-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 40px 0;
        }

        .result-item {
            background: #f8f9ff;
            padding: 25px;
            border-radius: 20px;
            border: 2px solid #e1e5e9;
        }

        .result-value {
            font-size: 36px;
            font-weight: 700;
            color: #4a90e2;
            margin-bottom: 10px;
        }

        .result-label {
            color: #666;
            font-weight: 600;
        }

        .back-btn {
            display: inline-block;
            background: rgba(74, 144, 226, 0.2);
            color: black;
            border: 2px solid rgba(74, 144, 226, 0.3);
            border-radius: 50px;
            padding: 12px 24px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-top: 20px;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .latihan-info {
                flex-direction: column;
                gap: 15px;
            }

            .latihan-container {
                padding: 20px;
            }

            .question-card {
                padding: 25px;
            }

            .navigation-buttons {
                flex-direction: column;
                gap: 15px;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }

            .results-details {
                grid-template-columns: 1fr;
            }
        }

        .option {
            transition: all 0.3s ease;
        }

        .option.correct {
            background-color: #4CAF50 !important;
            color: white !important;
            border-color: #4CAF50 !important;
        }

        .option.wrong {
            background-color: #f44336 !important;
            color: white !important;
            border-color: #f44336 !important;
        }

        .option.selected {
            border: 2px solid #2196F3;
            background-color: #e3f2fd;
        }

        .explanation {
            display: none;
            margin-top: 15px;
            padding: 15px;
            background-color: #f0f8ff;
            border-left: 4px solid #2196F3;
            border-radius: 4px;
        }

        .explanation.show {
            display: block;
        }

        .explanation-title {
            font-weight: bold;
            color: #2196F3;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📚 <?php echo $latihan_data['judul_latihan']; ?></h1>
            <div class="latihan-info">
                <div class="info-item">🏫 <?php echo $latihan_data['kelas']; ?></div>
                <div class="info-item">📖 <?php echo $latihan_data['materi']; ?></div>
                <div class="info-item">📝 <?php echo $total_soal; ?> Soal</div>
            </div>
        </div>

        <div class="latihan-container">
            <div class="progress-section">
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
                <div class="progress-text" id="progressText">Soal 1 dari <?php echo $total_soal; ?></div>
            </div>

            <?php foreach ($latihan_data['soal'] as $index => $soal): ?>
            <div class="question-card" id="question-<?php echo $index; ?>" <?php echo $index === 0 ? 'style="display: block;"' : ''; ?>>             
                <div class="question-text"><?php echo htmlspecialchars($soal['soal_text']); ?></div>
                
                <div class="options-container">
                    <div class="option" onclick="selectOption(this, '<?php echo $index; ?>', 'A')">
                        <span class="option-label">A</span>
                        <span class="option-text"><?php echo htmlspecialchars($soal['opsi_a']); ?></span>
                    </div>
                    <div class="option" onclick="selectOption(this, '<?php echo $index; ?>', 'B')">
                        <span class="option-label">B</span>
                        <span class="option-text"><?php echo htmlspecialchars($soal['opsi_b']); ?></span>
                    </div>
                    <div class="option" onclick="selectOption(this, '<?php echo $index; ?>', 'C')">
                        <span class="option-label">C</span>
                        <span class="option-text"><?php echo htmlspecialchars($soal['opsi_c']); ?></span>
                    </div>
                    <div class="option" onclick="selectOption(this, '<?php echo $index; ?>', 'D')">
                        <span class="option-label">D</span>
                        <span class="option-text"><?php echo htmlspecialchars($soal['opsi_d']); ?></span>
                    </div>
                </div>

                <div class="explanation" id="explanation-<?php echo $index; ?>">
                    <div class="explanation-title">💡 Penjelasan:</div>
                    <div class="explanation-text"><?php echo htmlspecialchars($soal['jawaban']); ?></div>
                </div>

                <div class="navigation-buttons">
                    <button class="btn btn-secondary" onclick="previousQuestion()" <?php echo $index === 0 ? 'style="visibility: hidden;"' : ''; ?>>
                        ← Sebelumnya
                    </button>
                    
                    <?php if ($index < $total_soal - 1): ?>
                        <button class="btn btn-primary" id="next-btn-<?php echo $index; ?>" onclick="nextQuestion()" disabled>
                            Selanjutnya →
                        </button>
                    <?php else: ?>
                        <button class="btn btn-primary" id="finish-btn" onclick="finishLatihan()" disabled>
                            🏁 Selesai
                        </button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>

            <div class="results-section" id="resultsSection">
                <div class="score-circle" id="scoreCircle">
                    <div class="score-text" id="scoreText">0%</div>
                </div>
                <div class="results-title">Hasil Latihan Soal Anda</div>
                <div class="results-details">
                    <div class="result-item">
                        <div class="result-value" id="correctAnswers">0</div>
                        <div class="result-label">Jawaban Benar</div>
                    </div>
                    <div class="result-item">
                        <div class="result-value" id="wrongAnswers">0</div>
                        <div class="result-label">Jawaban Salah</div>
                    </div>
                    <div class="result-item">
                        <div class="result-value" id="finalScore">0%</div>
                        <div class="result-label">Skor Akhir</div>
                    </div>
                </div>
                <a href="../menu-materi.php" class="back-btn">← Kembali Menu Materi</a>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const correctAnswers = <?php echo json_encode(array_column($latihan_data['soal'], 'opsijawaban')); ?>;
    const totalQuestions = <?php echo $total_soal; ?>;
    const userKelas = <?php echo json_encode($kelas_user); ?>;

    let currentQuestion = 0;
    let userAnswers = [];
    let score = 0;

    function selectOption(element, questionIndex, answer) {
        const options = element.parentElement.querySelectorAll('.option');
        options.forEach(opt => opt.classList.remove('selected'));
        element.classList.add('selected');
        userAnswers[questionIndex] = answer;
        showExplanation(questionIndex, answer);
        const nextOrFinishBtn = document.querySelector(`#question-${questionIndex} .btn-primary`);
        if (nextOrFinishBtn) nextOrFinishBtn.disabled = false;
    }

    function showExplanation(questionIndex, userAnswer) {
        const correct = correctAnswers[questionIndex];
        const options = document.querySelectorAll(`#question-${questionIndex} .option`);
        const explanation = document.getElementById(`explanation-${questionIndex}`);

        options.forEach(option => {
            const label = option.querySelector('.option-label').textContent;
            if (label === correct) {
                option.classList.add('correct');
            } else if (label === userAnswer && userAnswer !== correct) {
                option.classList.add('wrong');
            }
            option.style.pointerEvents = 'none';
        });

        explanation.classList.add('show');
        if (userAnswer === correct) score++;
    }

    function nextQuestion() {
        if (!userAnswers[currentQuestion]) {
            alert('Silakan jawab dulu!');
            return;
        }
        document.getElementById(`question-${currentQuestion}`).style.display = 'none';
        currentQuestion++;
        document.getElementById(`question-${currentQuestion}`).style.display = 'block';
        updateProgress();
    }

    function previousQuestion() {
        document.getElementById(`question-${currentQuestion}`).style.display = 'none';
        currentQuestion--;
        document.getElementById(`question-${currentQuestion}`).style.display = 'block';
        updateProgress();
    }

    function updateProgress() {
        const progress = ((currentQuestion + 1) / totalQuestions) * 100;
        document.getElementById('progressFill').style.width = progress + '%';
        document.getElementById('progressText').textContent = `Soal ${currentQuestion + 1} dari ${totalQuestions}`;
    }

    function finishLatihan() {
        if (!userAnswers[currentQuestion]) {
            alert('Silakan jawab dulu!');
            return;
        }

        // Hitung persentase
        const percentage = Math.round((score / totalQuestions) * 100);
        showResults(score, totalQuestions - score, percentage);

        // Simpan ke server
        fetch('../../simpan_nilai.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                skor: percentage,
                materi: '<?php echo $materi_khusus; ?>',
                jenis: 'latihan'
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status !== 'success') {
                alert('Gagal menyimpan nilai: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error saat kirim nilai:', error);
        });
    }

    function showResults(correct, wrong, percentage) {
        document.querySelectorAll('.question-card').forEach(card => card.style.display = 'none');
        const scoreCircle = document.getElementById('scoreCircle');
        const angle = (percentage / 100) * 360;
        scoreCircle.style.background = `conic-gradient(#4CAF50 ${angle}deg, #e0e0e0 ${angle}deg)`;

        document.getElementById('correctAnswers').textContent = correct;
        document.getElementById('wrongAnswers').textContent = wrong;
        document.getElementById('finalScore').textContent = percentage + '%';

        const scoreText = document.getElementById('scoreText');
        let current = 0;
        const increment = percentage > 0 ? Math.ceil(percentage / 30) : 1;
        const interval = setInterval(() => {
            if (current < percentage) {
                current += increment;
                if (current > percentage) current = percentage;
                scoreText.textContent = current + '%';
            } else {
                clearInterval(interval);
            }
        }, 30);

        document.getElementById('resultsSection').classList.add('show');
        document.getElementById('progressFill').style.width = '100%';
        document.getElementById('progressText').textContent = 'Latihan Selesai!';
    }

    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowLeft' && currentQuestion > 0) {
            previousQuestion();
        } else if (e.key === 'ArrowRight' && userAnswers[currentQuestion] && currentQuestion < totalQuestions - 1) {
            nextQuestion();
        }
    });

    updateProgress();
    window.selectOption = selectOption;
    window.nextQuestion = nextQuestion;
    window.previousQuestion = previousQuestion;
    window.finishLatihan = finishLatihan;
});
</script>

</body>
</html>