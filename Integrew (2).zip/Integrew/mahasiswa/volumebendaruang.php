<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalkulator Volume Benda dalam Ruang</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjs/11.11.0/math.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
.btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        .tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .tab-button {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .tab-button:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }

        .tab-button.active {
            background: rgba(255,255,255,0.9);
            color: #333;
            font-weight: bold;
        }

        .tab-content {
            display: none;
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 30px;
            backdrop-filter: blur(10px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .tab-content.active {
            display: block;
        }

        .method-card {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            border-left: 5px solid #667eea;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .method-card h3 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 1.4rem;
        }

        .formula {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 10px;
            margin: 15px 0;
            font-family: 'Courier New', monospace;
            font-size: 1.1rem;
            text-align: center;
            border: 2px solid #2196f3;
        }

        .calculator-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-top: 20px;
        }

        .calculator-panel {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }

        .calculate-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 25px;
            font-size: 1.1rem;
            cursor: pointer;
            width: 100%;
            transition: transform 0.3s ease;
        }

        .calculate-btn:hover {
            transform: translateY(-2px);
        }

        .result {
            background: #e8f5e8;
            border: 2px solid #4caf50;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
            text-align: center;
        }

        .result h4 {
            color: #2e7d32;
            margin-bottom: 10px;
        }

        .result-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: #1b5e20;
        }

        #visualization {
            width: 100%;
            height: 500px;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        }

        .visualization-controls {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
        }

        .control-btn {
            background: #667eea;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .control-btn:hover {
            background: #5a6fd8;
            transform: translateY(-1px);
        }

        .control-btn.active {
            background: #4caf50;
        }

        .error {
            background: #ffebee;
            border: 2px solid #f44336;
            color: #c62828;
            padding: 15px;
            border-radius: 10px;
            margin-top: 15px;
        }

        @media (max-width: 768px) {
            .header h1 {
                font-size: 2rem;
            }
            
            .calculator-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .tabs {
                flex-direction: column;
                align-items: center;
            }
            
            .tab-button {
                width: 100%;
                max-width: 300px;
            }
            
            .container {
                padding: 15px;
            }
            
            .tab-content {
                padding: 20px;
            }
            
            #visualization {
                height: 400px;
            }
        }

        @media (max-width: 480px) {
            .header h1 {
                font-size: 1.8rem;
            }
            
            .method-card {
                padding: 20px;
            }
            
            .calculator-panel {
                padding: 20px;
            }
        }

        .loading {
            display: none;
            text-align: center;
            margin: 20px 0;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .info-panel {
            background: #e3f2fd;
            border: 2px solid #2196f3;
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
        }

        .info-panel h4 {
            color: #1976d2;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧮 Kalkulator Volume Benda dalam Ruang</h1>
            <p>Menghitung volume dengan metode cakram dan cincin</p>
        </div>

        <div class="tabs">
            <button class="tab-button active" onclick="showTab('materi')">📚 Materi</button>
            <button class="tab-button" onclick="showTab('kalkulator')">🧮 Kalkulator</button>
            <button class="tab-button" onclick="showTab('visualisasi')">🎯 Visualisasi 3D</button>
        </div>

        <!-- Tab Materi -->
        <div id="materi" class="tab-content active">
            <div class="method-card">
                <h3>🔵 Metode Cakram (Disk Method)</h3>
                <p><strong>Kapan digunakan:</strong> Metode cakram digunakan saat benda padat diputar dan tidak memiliki lubang di tengah. Kita cukup mengkuadratkan fungsi dan mengalikan dengan π, lalu integralkan.</p>
                
                <div class="formula">
                    V = π ∫[a to b] [f(x)]² dx
                </div>
                
                <p><strong>Langkah-langkah:</strong></p>
                <ol>
                    <li>Tentukan fungsi f(x) yang akan diputar</li>
                    <li>Tentukan batas integrasi [a, b]</li>
                    <li>Kuadratkan fungsi: [f(x)]²</li>
                    <li>Kalikan dengan π</li>
                    <li>Integralkan dari a ke b</li>
                </ol>
                
                <p><strong>Contoh:</strong> Jika y = x² diputar terhadap sumbu x dari x = 0 ke x = 2, maka volume = π ∫[0 to 2] (x²)² dx = π ∫[0 to 2] x⁴ dx</p>
            </div>

            <div class="method-card">
                <h3>🔘 Metode Cincin (Washer Method)</h3>
                <p><strong>Kapan digunakan:</strong> Metode ini digunakan jika benda padat berongga — yaitu, ada lubang di tengah. Setiap irisan berbentuk cincin (seperti donat) yang terdiri dari dua lingkaran konsentris.</p>
                
                <div class="formula">
                    V = π ∫[a to b] ([R(x)]² - [r(x)]²) dx
                </div>
                
                <p><strong>Keterangan:</strong></p>
                <ul>
                    <li>R(x) = jari-jari luar (fungsi yang lebih besar)</li>
                    <li>r(x) = jari-jari dalam (fungsi yang lebih kecil)</li>
                </ul>
                
                <p><strong>Langkah-langkah:</strong></p>
                <ol>
                    <li>Tentukan fungsi luar R(x) dan fungsi dalam r(x)</li>
                    <li>Tentukan batas integrasi [a, b]</li>
                    <li>Hitung [R(x)]² - [r(x)]²</li>
                    <li>Kalikan dengan π</li>
                    <li>Integralkan dari a ke b</li>
                </ol>
            </div>
        </div>

        <!-- Tab Kalkulator -->
        <div id="kalkulator" class="tab-content">
            <div class="calculator-grid">
                <div class="calculator-panel">
                    <h3>⚙️ Pengaturan Perhitungan</h3>
                    
                    <div class="form-group">
                        <label for="method">Pilih Metode:</label>
                        <select id="method" onchange="toggleMethod()">
                            <option value="disk">Metode Cakram (Disk)</option>
                            <option value="washer">Metode Cincin (Washer)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="function1">Fungsi f(x) (atau fungsi luar untuk metode cincin):</label>
                        <input type="text" id="function1" placeholder="Contoh: x^2, sin(x), sqrt(x)" value="x^2">
                    </div>

                    <div class="form-group" id="function2-group" style="display: none;">
                        <label for="function2">Fungsi g(x) (fungsi dalam untuk metode cincin):</label>
                        <input type="text" id="function2" placeholder="Contoh: x, 1, 0" value="0">
                    </div>

                    <div class="form-group">
                        <label for="lowerBound">Batas Bawah (a):</label>
                        <input type="number" id="lowerBound" value="0" step="0.1">
                    </div>

                    <div class="form-group">
                        <label for="upperBound">Batas Atas (b):</label>
                        <input type="number" id="upperBound" value="2" step="0.1">
                    </div>

                    <button class="calculate-btn" onclick="calculateVolume()">🧮 Hitung Volume</button>

                    <div class="loading" id="loading">
                        <div class="spinner"></div>
                        <p>Menghitung...</p>
                    </div>

                    <div id="result-container"></div>
                </div>

                <div class="calculator-panel">
                    <h3>📊 Langkah Perhitungan</h3>
                    <div id="steps-container">
                        <p>Masukkan fungsi dan parameter, lalu klik "Hitung Volume" untuk melihat langkah-langkah perhitungan.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tab Visualisasi -->
        <div id="visualisasi" class="tab-content">
            <div class="calculator-panel">
                <h3>🎯 Visualisasi 3D Benda Putar</h3>
                
                <div class="visualization-controls">
                    <button class="control-btn" onclick="toggleAnimation()">▶️ Putar/Berhenti</button>
                    <button class="control-btn" onclick="toggleWireframe()">🔲 Mode Wireframe</button>
                    <button class="control-btn" onclick="resetView()">🔄 Reset View</button>
                    <button class="control-btn" onclick="toggleSlices()">📐 Tampilkan Irisan</button>
                </div>
                
                <div id="visualization"></div>
                
                <div class="info-panel">
                    <h4>💡 Kontrol Visualisasi:</h4>
                    <p>• <strong>Mouse:</strong> Klik dan drag untuk memutar objek</p>
                    <p>• <strong>Scroll:</strong> Zoom in/out</p>
                    <p>• <strong>Animasi:</strong> Objek akan berputar otomatis menunjukkan bentuk 3D</p>
                    <p>• <strong>Irisan:</strong> Tampilkan potongan-potongan yang membentuk volume</p>
                </div>
                
                <div id="visualization-info"></div>
            </div>
        </div>
        <div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='dashboardmahasiswa.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>
    </div>

    <script>
        let scene, camera, renderer, currentMesh, animationId;
        let calculationResult = null;
        let isAnimating = false;
        let showWireframe = false;
        let showSlices = false;
        let sliceMeshes = [];
        let controls = {};

        // Initialize 3D visualization
        function initVisualization() {
            const container = document.getElementById('visualization');
            if (!container) return;

            // Clear existing renderer
            if (renderer) {
                container.removeChild(renderer.domElement);
            }

            // Scene setup
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x0f1419);

            // Camera setup
            camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
            camera.position.set(8, 6, 8);
            camera.lookAt(0, 0, 0);

            // Renderer setup
            renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
            renderer.setSize(container.clientWidth, container.clientHeight);
            renderer.shadowMap.enabled = true;
            renderer.shadowMap.type = THREE.PCFSoftShadowMap;
            renderer.setClearColor(0x0f1419, 1);
            container.appendChild(renderer.domElement);

            // Enhanced lighting
            const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
            scene.add(ambientLight);

            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(10, 10, 5);
            directionalLight.castShadow = true;
            directionalLight.shadow.mapSize.width = 2048;
            directionalLight.shadow.mapSize.height = 2048;
            scene.add(directionalLight);

            const pointLight = new THREE.PointLight(0x667eea, 0.5, 50);
            pointLight.position.set(-10, 10, 10);
            scene.add(pointLight);

            // Mouse controls
            setupMouseControls(container);

            // Grid helper
            const gridHelper = new THREE.GridHelper(10, 10, 0x444444, 0x222222);
            scene.add(gridHelper);

            // Coordinate axes
            const axesHelper = new THREE.AxesHelper(5);
            scene.add(axesHelper);

            // Start animation loop
            animate();

            // Create default shape if no calculation result
            if (!calculationResult) {
                createDefaultShape();
            }
        }

        function setupMouseControls(container) {
            let mouseDown = false;
            let mouseX = 0;
            let mouseY = 0;
            let targetRotationX = 0;
            let targetRotationY = 0;
            let currentRotationX = 0;
            let currentRotationY = 0;

            container.addEventListener('mousedown', (e) => {
                mouseDown = true;
                mouseX = e.clientX;
                mouseY = e.clientY;
                container.style.cursor = 'grabbing';
            });

            container.addEventListener('mouseup', () => {
                mouseDown = false;
                container.style.cursor = 'grab';
            });

            container.addEventListener('mouseleave', () => {
                mouseDown = false;
                container.style.cursor = 'default';
            });

            container.addEventListener('mousemove', (e) => {
                if (!mouseDown) return;
                
                const deltaX = e.clientX - mouseX;
                const deltaY = e.clientY - mouseY;
                
                targetRotationY += deltaX * 0.01;
                targetRotationX += deltaY * 0.01;
                
                mouseX = e.clientX;
                mouseY = e.clientY;
            });

            container.addEventListener('wheel', (e) => {
                e.preventDefault();
                const scale = e.deltaY > 0 ? 1.1 : 0.9;
                camera.position.multiplyScalar(scale);
                camera.position.clampLength(3, 50);
            });

            // Smooth rotation update
            controls.update = () => {
                currentRotationX += (targetRotationX - currentRotationX) * 0.1;
                currentRotationY += (targetRotationY - currentRotationY) * 0.1;
                
                if (currentMesh && !isAnimating) {
                    currentMesh.rotation.x = currentRotationX;
                    currentMesh.rotation.y = currentRotationY;
                }
            };

            container.style.cursor = 'grab';
        }

        function animate() {
            animationId = requestAnimationFrame(animate);
            
            // Update controls
            if (controls.update) {
                controls.update();
            }
            
            // Auto-rotation animation
            if (isAnimating && currentMesh) {
                currentMesh.rotation.y += 0.01;
                currentMesh.rotation.x = Math.sin(Date.now() * 0.001) * 0.1;
            }
            
            // Animate slices if visible
            if (showSlices && sliceMeshes.length > 0) {
                sliceMeshes.forEach((slice, index) => {
                    slice.rotation.y += 0.005 * (index % 2 === 0 ? 1 : -1);
                });
            }
            
            renderer.render(scene, camera);
        }

        function createDefaultShape() {
            // Create a sample parabola solid of revolution
            const geometry = createRevolutionGeometry('x^2', '0', 0, 2, 'disk');
            const material = new THREE.MeshPhongMaterial({ 
                color: 0x667eea, 
                transparent: true, 
                opacity: 0.8,
                side: THREE.DoubleSide,
                shininess: 100
            });

            currentMesh = new THREE.Mesh(geometry, material);
            scene.add(currentMesh);

            // Add some visual enhancements
            const edgesGeometry = new THREE.EdgesGeometry(geometry);
            const edgesMaterial = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.3 });
            const edges = new THREE.LineSegments(edgesGeometry, edgesMaterial);
            currentMesh.add(edges);

            updateVisualizationInfo('x²', '0', 0, 2, 'disk', 25.13);
        }

        // Tab functionality
        function showTab(tabName) {
            const tabs = document.querySelectorAll('.tab-content');
            tabs.forEach(tab => tab.classList.remove('active'));

            const buttons = document.querySelectorAll('.tab-button');
            buttons.forEach(btn => btn.classList.remove('active'));

            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');

            if (tabName === 'visualisasi' && !renderer) {
                setTimeout(initVisualization, 100);
            } else if (tabName === 'visualisasi' && renderer) {
                // Resize renderer when switching to visualization tab
                setTimeout(() => {
                    const container = document.getElementById('visualization');
                    if (container && renderer) {
                        renderer.setSize(container.clientWidth, container.clientHeight);
                        camera.aspect = container.clientWidth / container.clientHeight;
                        camera.updateProjectionMatrix();
                    }
                }, 100);
            }
        }

        // Toggle between disk and washer method
        function toggleMethod() {
            const method = document.getElementById('method').value;
            const function2Group = document.getElementById('function2-group');
            
            if (method === 'washer') {
                function2Group.style.display = 'block';
            } else {
                function2Group.style.display = 'none';
            }
        }

        // Visualization controls
        function toggleAnimation() {
            isAnimating = !isAnimating;
            const btn = event.target;
            btn.textContent = isAnimating ? '⏸️ Berhenti' : '▶️ Putar';
            btn.classList.toggle('active', isAnimating);
        }

        function toggleWireframe() {
            showWireframe = !showWireframe;
            const btn = event.target;
            btn.classList.toggle('active', showWireframe);
            
            if (currentMesh) {
                currentMesh.material.wireframe = showWireframe;
                currentMesh.material.opacity = showWireframe ? 1 : 0.8;
            }
        }

        function resetView() {
            camera.position.set(8, 6, 8);
            camera.lookAt(0, 0, 0);
            if (currentMesh) {
                currentMesh.rotation.set(0, 0, 0);
            }
            isAnimating = false;
            const animBtn = document.querySelector('.control-btn');
            if (animBtn) {
                animBtn.textContent = '▶️ Putar';
                animBtn.classList.remove('active');
            }
        }

        function toggleSlices() {
            showSlices = !showSlices;
            const btn = event.target;
            btn.classList.toggle('active', showSlices);
            
            // Remove existing slices
            sliceMeshes.forEach(slice => scene.remove(slice));
            sliceMeshes = [];
            
            if (showSlices && calculationResult) {
                createSliceVisualization();
            }
        }

        function createSliceVisualization() {
            if (!calculationResult) return;
            
            const { func1, func2, a, b, method } = calculationResult;
            const numSlices = 8;
            
            for (let i = 0; i < numSlices; i++) {
                const x = a + (b - a) * i / (numSlices - 1);
                const outerRadius = Math.abs(evaluateFunction(func1, x));
                const innerRadius = method === 'washer' ? Math.abs(evaluateFunction(func2, x)) : 0;
                
                let geometry;
                if (method === 'washer' && innerRadius > 0) {
                    // Ring geometry
                    const ringShape = new THREE.Shape();
                    ringShape.absarc(0, 0, outerRadius, 0, Math.PI * 2, false);
                    if (innerRadius > 0) {
                        const hole = new THREE.Path();
                        hole.absarc(0, 0, innerRadius, 0, Math.PI * 2, true);
                        ringShape.holes.push(hole);
                    }
                    geometry = new THREE.ShapeGeometry(ringShape);
                } else {
                    // Disk geometry
                    geometry = new THREE.CircleGeometry(outerRadius, 16);
                }
                
                const material = new THREE.MeshBasicMaterial({ 
                    color: new THREE.Color().setHSL(i / numSlices, 0.7, 0.6),
                    transparent: true, 
                    opacity: 0.6,
                    side: THREE.DoubleSide
                });
                
                const slice = new THREE.Mesh(geometry, material);
                slice.position.x = x;
                slice.rotation.y = Math.PI / 2;
                
                scene.add(slice);
                sliceMeshes.push(slice);
            }
        }

        // Calculate volume
        function calculateVolume() {
            const method = document.getElementById('method').value;
            const func1 = document.getElementById('function1').value;
            const func2 = document.getElementById('function2').value;
            const a = parseFloat(document.getElementById('lowerBound').value);
            const b = parseFloat(document.getElementById('upperBound').value);

            // Validation
            if (isNaN(a) || isNaN(b) || a >= b) {
                displayError('Batas integrasi tidak valid. Pastikan a < b.');
                return;
            }

            document.getElementById('loading').style.display = 'block';

            try {
                let volume, steps;

                if (method === 'disk') {
                    const result = calculateDiskVolume(func1, a, b);
                    volume = result.volume;
                    steps = result.steps;
                } else {
                    const result = calculateWasherVolume(func1, func2, a, b);
                    volume = result.volume;
                    steps = result.steps;
                }

                displayResult(volume, steps);
                calculationResult = { method, func1, func2, a, b, volume };
                createVisualization();

            } catch (error) {
                displayError('Error dalam perhitungan: ' + error.message);
            }

            document.getElementById('loading').style.display = 'none';
        }

        function calculateDiskVolume(func, a, b) {
            const steps = [];
            steps.push(`<strong>Metode Cakram:</strong>`);
            steps.push(`Fungsi: f(x) = ${func}`);
            steps.push(`Batas: [${a}, ${b}]`);
            steps.push(`Formula: V = π ∫[${a} to ${b}] [${func}]² dx`);

            // Numerical integration using Simpson's rule
            const n = 1000;
            const h = (b - a) / n;
            let sum = 0;

            for (let i = 0; i <= n; i++) {
                const x = a + i * h;
                const fx = evaluateFunction(func, x);
                const weight = (i === 0 || i === n) ? 1 : (i % 2 === 0) ? 2 : 4;
                sum += weight * fx * fx;
            }

            const volume = Math.PI * (h / 3) * sum;
            
            steps.push(`<strong>Hasil Integrasi Numerik:</strong>`);
            steps.push(`V = ${volume.toFixed(4)} satuan kubik`);

            return { volume, steps };
        }

        function calculateWasherVolume(func1, func2, a, b) {
            const steps = [];
            steps.push(`<strong>Metode Cincin:</strong>`);
            steps.push(`Fungsi luar: R(x) = ${func1}`);
            steps.push(`Fungsi dalam: r(x) = ${func2}`);
            steps.push(`Batas: [${a}, ${b}]`);
            steps.push(`Formula: V = π ∫[${a} to ${b}] ([${func1}]² - [${func2}]²) dx`);

            const n = 1000;
            const h = (b - a) / n;
            let sum = 0;

            for (let i = 0; i <= n; i++) {
                const x = a + i * h;
                const R = evaluateFunction(func1, x);
                const r = evaluateFunction(func2, x);
                const weight = (i === 0 || i === n) ? 1 : (i % 2 === 0) ? 2 : 4;
                sum += weight * (R * R - r * r);
            }

            const volume = Math.PI * (h / 3) * sum;
            
            steps.push(`<strong>Hasil Integrasi Numerik:</strong>`);
            steps.push(`V = ${volume.toFixed(4)} satuan kubik`);

            return { volume, steps };
        }

        function evaluateFunction(funcStr, x) {
            try {
                if (!funcStr || funcStr.trim() === '') return 0;
                
                // Replace common mathematical expressions
                let expr = funcStr.toString().toLowerCase();
                expr = expr.replace(/\s/g, ''); // Remove spaces
                expr = expr.replace(/\^/g, '**');
                expr = expr.replace(/sin/g, 'Math.sin');
                expr = expr.replace(/cos/g, 'Math.cos');
                expr = expr.replace(/tan/g, 'Math.tan');
                expr = expr.replace(/sqrt/g, 'Math.sqrt');
                expr = expr.replace(/log/g, 'Math.log');
                expr = expr.replace(/ln/g, 'Math.log');
                expr = expr.replace(/abs/g, 'Math.abs');
                expr = expr.replace(/exp/g, 'Math.exp');
                expr = expr.replace(/\be\b/g, 'Math.E');
                expr = expr.replace(/\bpi\b/g, 'Math.PI');
                
                // Handle implicit multiplication (2x -> 2*x)
                expr = expr.replace(/(\d)([a-z])/g, '$1*$2');
                expr = expr.replace(/([a-z])(\d)/g, '$1*$2');
                
                // Replace x variable
                expr = expr.replace(/x/g, `(${x})`);

                const result = eval(expr);
                if (isNaN(result) || !isFinite(result)) {
                    throw new Error('Hasil evaluasi tidak valid');
                }
                return result;
            } catch (error) {
                throw new Error(`Tidak dapat mengevaluasi fungsi: ${funcStr} pada x=${x}`);
            }
        }

        function displayResult(volume, steps) {
            const container = document.getElementById('result-container');
            container.innerHTML = `
                <div class="result">
                    <h4>📊 Hasil Perhitungan</h4>
                    <div class="result-value">${volume.toFixed(6)} satuan kubik</div>
                    <div style="margin-top: 10px; font-size: 0.9rem;">
                        ≈ ${volume.toFixed(2)} satuan kubik
                    </div>
                </div>
            `;

            const stepsContainer = document.getElementById('steps-container');
            stepsContainer.innerHTML = `
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; border-left: 4px solid #667eea;">
                    ${steps.map(step => `<p style="margin-bottom: 12px; line-height: 1.6;">${step}</p>`).join('')}
                </div>
            `;
        }

        function displayError(message) {
            const container = document.getElementById('result-container');
            container.innerHTML = `<div class="error">❌ ${message}</div>`;
            
            const stepsContainer = document.getElementById('steps-container');
            stepsContainer.innerHTML = `<div class="error">Perhitungan gagal. Silakan periksa input Anda.</div>`;
        }

        function createVisualization() {
            if (!scene || !calculationResult) return;

            // Remove existing meshes
            if (currentMesh) {
                scene.remove(currentMesh);
            }
            sliceMeshes.forEach(slice => scene.remove(slice));
            sliceMeshes = [];

            const { method, func1, func2, a, b, volume } = calculationResult;

            try {
                // Create geometry for the solid of revolution
                const geometry = createRevolutionGeometry(func1, func2, a, b, method);
                
                // Enhanced material with better visual appeal
                const material = new THREE.MeshPhongMaterial({ 
                    color: method === 'disk' ? 0x667eea : 0xe91e63,
                    transparent: true, 
                    opacity: 0.85,
                    side: THREE.DoubleSide,
                    shininess: 100,
                    specular: 0x222222
                });

                currentMesh = new THREE.Mesh(geometry, material);
                scene.add(currentMesh);

                // Add edges for better definition
                const edgesGeometry = new THREE.EdgesGeometry(geometry, 15);
                const edgesMaterial = new THREE.LineBasicMaterial({ 
                    color: 0xffffff, 
                    transparent: true, 
                    opacity: 0.4,
                    linewidth: 1
                });
                const edges = new THREE.LineSegments(edgesGeometry, edgesMaterial);
                currentMesh.add(edges);

                // Add glow effect
                const glowGeometry = geometry.clone();
                const glowMaterial = new THREE.MeshBasicMaterial({
                    color: method === 'disk' ? 0x667eea : 0xe91e63,
                    transparent: true,
                    opacity: 0.1,
                    side: THREE.BackSide
                });
                const glow = new THREE.Mesh(glowGeometry, glowMaterial);
                glow.scale.multiplyScalar(1.05);
                currentMesh.add(glow);

                updateVisualizationInfo(func1, func2, a, b, method, volume);

                // Reset view and animation
                resetView();
                
            } catch (error) {
                console.error('Error creating visualization:', error);
                updateVisualizationInfo(func1, func2, a, b, method, volume, 'Error dalam visualisasi: ' + error.message);
            }
        }

        function createRevolutionGeometry(func1, func2, a, b, method) {
            const segments = 64; // Higher resolution
            const radialSegments = 32;
            
            const vertices = [];
            const indices = [];
            const normals = [];
            const uvs = [];

            // Generate vertices
            for (let i = 0; i <= segments; i++) {
                const x = a + (b - a) * i / segments;
                const outerRadius = Math.abs(evaluateFunction(func1, x));
                const innerRadius = method === 'washer' ? Math.abs(evaluateFunction(func2, x)) : 0;

                for (let j = 0; j <= radialSegments; j++) {
                    const angle = (j / radialSegments) * Math.PI * 2;
                    const cos = Math.cos(angle);
                    const sin = Math.sin(angle);

                    // Outer surface vertices
                    vertices.push(x, outerRadius * cos, outerRadius * sin);
                    normals.push(0, cos, sin); // Simplified normal calculation
                    uvs.push(i / segments, j / radialSegments);

                    // Inner surface vertices for washer method
                    if (method === 'washer' && innerRadius > 0.001) {
                        vertices.push(x, innerRadius * cos, innerRadius * sin);
                        normals.push(0, -cos, -sin); // Inward facing normals
                        uvs.push(i / segments, j / radialSegments);
                    }
                }
            }

            // Generate indices for faces
            const verticesPerSlice = method === 'washer' ? (radialSegments + 1) * 2 : (radialSegments + 1);
            
            for (let i = 0; i < segments; i++) {
                for (let j = 0; j < radialSegments; j++) {
                    // Outer surface indices
                    const a = i * verticesPerSlice + j * (method === 'washer' ? 2 : 1);
                    const b = a + verticesPerSlice;
                    const c = a + (method === 'washer' ? 2 : 1);
                    const d = b + (method === 'washer' ? 2 : 1);

                    // Two triangles per quad
                    indices.push(a, b, c);
                    indices.push(b, d, c);

                    // Inner surface for washer method
                    if (method === 'washer') {
                        const ai = a + 1;
                        const bi = b + 1;
                        const ci = c + 1;
                        const di = d + 1;

                        indices.push(ai, ci, bi);
                        indices.push(bi, ci, di);
                    }
                }
            }

            // Cap the ends for disk method
            if (method === 'disk') {
                // Add end caps
                const centerStart = vertices.length / 3;
                vertices.push(a, 0, 0); // Center of start cap
                normals.push(-1, 0, 0);
                uvs.push(0.5, 0.5);

                const centerEnd = centerStart + 1;
                vertices.push(b, 0, 0); // Center of end cap
                normals.push(1, 0, 0);
                uvs.push(0.5, 0.5);

                // Connect edges to centers
                for (let j = 0; j < radialSegments; j++) {
                    const next = (j + 1) % radialSegments;
                    
                    // Start cap
                    indices.push(centerStart, j, next);
                    
                    // End cap
                    const endJ = segments * (radialSegments + 1) + j;
                    const endNext = segments * (radialSegments + 1) + next;
                    indices.push(centerEnd, endNext, endJ);
                }
            }

            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
            geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
            geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
            geometry.setIndex(indices);
            
            // Compute proper normals
            geometry.computeVertexNormals();

            return geometry;
        }

        function updateVisualizationInfo(func1, func2, a, b, method, volume, error = null) {
            const container = document.getElementById('visualization-info');
            
            if (error) {
                container.innerHTML = `
                    <div class="error" style="margin-top: 20px;">
                        ${error}
                    </div>
                `;
                return;
            }
            
            const methodName = method === 'disk' ? 'Metode Cakram' : 'Metode Cincin';
            const funcDisplay = method === 'washer' ? 
                `<strong>Luar:</strong> f(x) = ${func1}<br><strong>Dalam:</strong> g(x) = ${func2}` :
                `<strong>Fungsi:</strong> f(x) = ${func1}`;
            
            container.innerHTML = `
                <div class="info-panel">
                    <h4>📊 Informasi Visualisasi</h4>
                    <p><strong>Metode:</strong> ${methodName}</p>
                    <p>${funcDisplay}</p>
                    <p><strong>Interval:</strong> [${a}, ${b}]</p>
                    <p><strong>Volume:</strong> ${volume.toFixed(4)} satuan kubik</p>
                    <p><strong>Warna:</strong> ${method === 'disk' ? 'Biru (solid)' : 'Pink (berongga)'}</p>
                </div>
            `;
        }

        // Handle window resize
        window.addEventListener('resize', () => {
            if (renderer && camera) {
                const container = document.getElementById('visualization');
                if (container) {
                    const width = container.clientWidth;
                    const height = container.clientHeight;
                    
                    camera.aspect = width / height;
                    camera.updateProjectionMatrix();
                    renderer.setSize(width, height);
                }
            }
        });

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', () => {
            // Set default values and initialize
            toggleMethod(); // Set up initial form state
        });

        // Cleanup on page unload
        window.addEventListener('beforeunload', () => {
            if (animationId) {
                cancelAnimationFrame(animationId);
            }
            if (renderer) {
                renderer.dispose();
            }
        });
    </script>
</body>
</html>