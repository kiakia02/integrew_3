<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Volume Benda Putar</title>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Rubik+Bubbles&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Open Sans', sans-serif;
      background-color: #fff;
      padding: 0px;
      text-align: center;
      margin:20px 0;
    }

    .title-box {
      display: inline-block;
      border: 4px solid black;
      border-radius: 20px;
      padding: 1rem 2rem;
      font-family: 'Rubik Bubbles', cursive;
      font-size: 26px;
      color: #D55050;
      box-shadow: 4px 6px #db719b;
      margin-bottom: 2rem;
    }

    h2 {
      font-family: 'Rubik Bubbles', cursive;
      font-size: 13px;
      color: #cc5e5e;
      letter-spacing: 0.5px;
      margin-bottom: 8px;
    }

    .rumus {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin:0 10px;
    }

    .duo {
      display: flex;
      justify-content: center;
      /* align-items:flex-end; */
      gap: 16px;
      flex-wrap: wrap;
      margin-bottom: 30px;
    }

    .rumus-col {
      display: flex;
      flex-direction: column;
      align-items:center;
      max-width: 90%;
    }
    .gambar-sumbu{
        width: 100px;
        padding:10px 0;
    }

    .rumus-btn-img {
      margin: 0;
      
      cursor: pointer;
      display: inline-block;
    }

    .rumus-btn-img img {
      width: 160px;
      height: auto;
    }

    .button {
      display: flex;
      flex-direction: column;
      margin-top: 80px;
    }

    .button button {
      margin: 10px;
      padding: 12px;
      background-color: #ff5757;
      border: 2px solid #f4b9d3;
      border-bottom: 6px solid #a73832;
      color: white;
      font-family: 'Rubik Bubbles', cursive;
      font-size: 18px;
      border-radius: 30px;
      width: 1000px;
      max-width: 250px;
      margin-left: auto;
      margin-right: auto;
    }

    .button button:hover {
      transform: scale(1.03);
    }
    

    /* Popup Style */
    .popup {
      display: none;
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: #ffffcc;
      border: 2px solid #333;
      padding: 15px;
      width: 60%;
      max-width: 320px;
      z-index: 1000;
      border-radius: 15px;
      box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
      text-align: center;
    }
    .gambar-sumbu-y{
        height:100px;
        padding:10px;
    }
    p{
        font-size:10px;
    }
    .popup img {
      width: 90%;
      border-radius: 10px;
    }

    .close-btn {
      position: absolute;
      right: 12px;
      top: 8px;
      font-size: 20px;
      cursor: pointer;
      color: #a73832;
    }

    /* Responsive Tweaks */
    @media (max-width: 480px) {
      .title-box {
        font-size: 22px;
        padding: 10px 14px;
      }

      h2 {
        font-size: 12px;
      }

      .rumus-btn-img img {
        width: 160px;
      }
    }
        .btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
  </style>
</head>
<body>

  <div class="title-box">Menentukan Volume<br>Benda Putar</div>

  <div class="rumus">
    <!-- Dua Rumus Atas -->
    <div class="duo">
      <div class="rumus-col">
        <p>Kurva mengelilingi<br>Sumbu X</p>
        <img class="gambar-sumbu" src="gambar/Integrew-11.png">
        <div class="rumus-btn-img" onclick="openPopup('popup1')">
          <img src="gambar/Integrew-12.png">
        </div>
      </div>

      <div class="rumus-col">
        <p>Kurva mengelilingi<br>Sumbu Y</p>
        <img class="gambar-sumbu-y" src="gambar/Integrew-13.png">
        <div class="rumus-btn-img" onclick="openPopup('popup2')">
          <img src="gambar/Integrew-14.png">
        </div>
      </div>
    </div>

  <!-- Tombol -->
  <div class="button">
    <button onclick="window.location.href='latihansoal.php'">latihan soal</button>
    <button onclick="window.location.href='kuis.php'">kuis</button>
  </div>
<div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='../menu-materi.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>
    
  <!-- Popups -->
  <div class="popup" id="popup1">
    <span class="close-btn" onclick="closePopup('popup1')">&times;</span>
    <img src="gambar/Integrew-10.png">
  </div>

  <div class="popup" id="popup2">
    <span class="close-btn" onclick="closePopup('popup2')">&times;</span>
    <img src="gambar/Integrew-15.png">
  </div>

  <!-- Script -->
  <script>
    function openPopup(id) {
      document.getElementById(id).style.display = 'block';
    }

    function closePopup(id) {
      document.getElementById(id).style.display = 'none';
    }

    window.addEventListener('click', function (e) {
      ['popup1', 'popup2'].forEach(id => {
        const popup = document.getElementById(id);
        if (e.target === popup) {
          popup.style.display = 'none';
        }
      });
    });
  </script>

</body>
</html>
