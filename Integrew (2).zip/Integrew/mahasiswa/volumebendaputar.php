<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalkulator Volume Benda Putar</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/plotly.js/2.24.1/plotly.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjs/11.11.0/math.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI Tahoma', Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
        }

        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        .tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .tab-button {
            padding: 12px 24px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .tab-button.active {
            background: rgba(255, 255, 255, 0.9);
            color: #333;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }

        .tab-button:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-1px);
        }

        .tab-content {
            display: none;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
            margin-bottom: 20px;
        }

        .tab-content.active {
            display: block;
            animation: fadeIn 0.5s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .theory-section {
            margin-bottom: 30px;
        }

        .theory-section h2 {
            color: #4a5568;
            margin-bottom: 15px;
            font-size: 1.8rem;
            border-bottom: 3px solid #667eea;
            padding-bottom: 5px;
        }

        .theory-section h3 {
            color: #2d3748;
            margin: 20px 0 10px 0;
            font-size: 1.3rem;
        }

        .formula {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            margin: 15px 0;
            text-align: center;
            font-size: 1.2rem;
            font-weight: bold;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .calculator-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-top: 20px;
        }

        .input-section {
            background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }
.btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2d3748;
        }

        .input-group input, 
        .input-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
        }

        .input-group input:focus,
        .input-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102, 126, 234, 0.3);
        }

        .calculate-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .calculate-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }

        .result-section {
            background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
            padding: 25px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .result-value {
            font-size: 2rem;
            font-weight: bold;
            color: #2d3748;
            margin: 15px 0;
            padding: 15px;
            background: rgba(255, 255, 255, 0.7);
            border-radius: 10px;
        }

        .graph-container {
            grid-column: 1 / -1;
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .example-section {
            background: linear-gradient(135deg, #d299c2 0%, #fef9d7 100%);
            padding: 25px;
            border-radius: 15px;
            margin: 20px 0;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .example-section h4 {
            color: #2d3748;
            margin-bottom: 10px;
            font-size: 1.2rem;
        }

        .error-message {
            background: #fed7d7;
            color: #c53030;
            padding: 10px;
            border-radius: 8px;
            margin: 10px 0;
            border-left: 4px solid #c53030;
        }

        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }

            .header h1 {
                font-size: 2rem;
            }

            .calculator-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .tabs {
                flex-direction: column;
                align-items: center;
            }

            .tab-button {
                width: 200px;
                text-align: center;
            }

            .tab-content {
                padding: 20px;
            }
        }

        .solution-display {
            background: linear-gradient(135deg, #e8f5e8 0%, #f0f8ff 100%);
            border-radius: 12px;
            padding: 20px;
            margin: 15px 0;
            border-left: 5px solid #4CAF50;
            animation: slideDown 0.5s ease-out;
        }

        .result-calculation {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
            border: 2px solid #4CAF50;
        }

        .result-calculation h5 {
            color: #2d3748;
            margin-bottom: 10px;
        }

        .result-calculation .volume-result {
            font-size: 1.5rem;
            font-weight: bold;
            color: #1a5c1a;
            text-align: center;
            background: linear-gradient(135deg, #90EE90, #98FB98);
            padding: 12px;
            border-radius: 8px;
            margin: 10px 0;
        }

        @media (max-width: 480px) {
            .header h1 {
                font-size: 1.5rem;
            }

            .formula {
                font-size: 1rem;
                padding: 15px;
            }

            .result-value {
                font-size: 1.5rem;
            }

            .solution-display {
                padding: 15px;
            }

            .result-calculation {
                padding: 12px;
            }
        }
        @media (max-width: 768px) {
    .calculator-grid {
        display: flex;
        flex-direction: column;
    }

    .input-section {
        order: 1;
    }

    .graph-container {
        order: 2;
    }

    .result-section {
        order: 3;
    }
}

@media (max-width: 480px) {
    .tab-content {
        padding: 15px;
    }

    .input-group label {
        font-size: 0.95rem;
    }

    .input-group input,
    .input-group select {
        font-size: 1rem;
        padding: 10px;
    }

    .calculate-btn {
        padding: 12px;
        font-size: 1rem;
    }

    .result-value {
        font-size: 1.4rem;
        padding: 12px;
    }

    .result-section h3 {
        font-size: 1.2rem;
    }

    .graph-container {
        padding: 10px;
    }

    #graph {
        height: 300px !important;
    }
}
.graph-responsive {
            width: 100% !important;
            height: auto !important;
            min-height: 250px;
        }

        @media (max-width: 768px) {
            .graph-responsive {
                min-height: 300px !important;
            }
        }

        @media (max-width: 480px) {
            .graph-responsive {
                min-height: 280px !important;
            }
        }

        /* Touch-friendly improvements for mobile */
        @media (hover: none) and (pointer: coarse) {
            .tab-button {
                min-height: 44px;
                min-width: 44px;
            }

            .calculate-btn {
                min-height: 44px;
            }

            .input-group input,
            .input-group select {
                min-height: 44px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔄 Kalkulator Volume Benda Putar</h1>
            <p>Hitung volume benda putar</p>
        </div>

        <div class="tabs">
            <button class="tab-button active" onclick="openTab(event, 'theory')">📚 Teori</button>
            <button class="tab-button" onclick="openTab(event, 'calculator')">🧮 Kalkulator</button>
            <button class="tab-button" onclick="openTab(event, 'examples')">📋 Contoh Soal</button>
        </div>

        <div id="theory" class="tab-content active">
            <div class="theory-section">
                <h2>Volume Benda Putar</h2>
                <p>Volume benda putar adalah volume yang terbentuk ketika suatu daerah diputar mengelilingi suatu sumbu. Ada dua metode utama untuk menghitung volume benda putar:</p>
                
                <h3>1. Rotasi Mengelilingi Sumbu X</h3>
                <p>Ketika daerah yang dibatasi oleh kurva y = f(x), sumbu x, x = a, dan x = b diputar mengelilingi sumbu x:</p>
                <div class="formula">
                    V = π ∫[a,b] [f(x)]² dx
                </div>
                
                <h3>2. Rotasi Mengelilingi Sumbu Y</h3>
                <p>Ketika daerah yang dibatasi oleh kurva x = g(y), sumbu y, y = c, dan y = d diputar mengelilingi sumbu y:</p>
                <div class="formula">
                    V = π ∫[c,d] [g(y)]² dy
                </div>

                <h3>Metode Cakram (Disk Method)</h3>
                <p>Metode ini digunakan ketika daerah yang diputar tidak memiliki lubang di tengah. Volume dihitung dengan menjumlahkan volume cakram-cakram tipis.</p>

                <h3>Kuadran dalam Sistem Koordinat</h3>
                <p>Sistem koordinat Kartesius dibagi menjadi 4 kuadran:</p>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li><strong>Kuadran I:</strong> x > 0, y > 0</li>
                    <li><strong>Kuadran II:</strong> x < 0, y > 0</li>
                    <li><strong>Kuadran III:</strong> x < 0, y < 0</li>
                    <li><strong>Kuadran IV:</strong> x > 0, y < 0</li>
                </ul>
            </div>
        </div>

        <div id="calculator" class="tab-content">
            <div class="calculator-grid">
                <div class="input-section">
                    <h3>Input Parameter</h3>
                    
                    <div class="input-group">
                        <label for="quadrant">Pilih Kuadran:</label>
                        <select id="quadrant" onchange="updateBounds()">
                            <option value="1">Kuadran I (x≥0, y≥0)</option>
                            <option value="2">Kuadran II (x≤0, y≥0)</option>
                            <option value="3">Kuadran III (x≤0, y≤0)</option>
                            <option value="4">Kuadran IV (x≥0, y≤0)</option>
                        </select>
                    </div>

                    <div class="input-group">
                        <label for="axis">Sumbu Rotasi:</label>
                        <select id="axis">
                            <option value="x">Sumbu X</option>
                            <option value="y">Sumbu Y</option>
                        </select>
                    </div>

                    <div class="input-group">
                        <label for="function">Fungsi y = f(x):</label>
                        <input type="text" id="function" placeholder="Contoh: 4 - x^2, x^2, sqrt(x)" />
                        <small style="color: #666; font-size: 0.9em;">Gunakan: ^2 untuk kuadrat, sqrt() untuk akar, * untuk perkalian</small>
                    </div>

                    <div class="input-group">
                        <label for="lowerBound">Batas Bawah:</label>
                        <input type="number" id="lowerBound" value="0" step="0.1" />
                    </div>

                    <div class="input-group">
                        <label for="upperBound">Batas Atas:</label>
                        <input type="number" id="upperBound" value="2" step="0.1" />
                    </div>

                    <button class="calculate-btn" onclick="calculateVolume()">
                        🔄 Hitung Volume
                    </button>
                </div>

                <div class="result-section">
                    <h3>Hasil Perhitungan</h3>
                    <div id="result">
                        <p>Masukkan parameter dan klik "Hitung Volume"</p>
                    </div>
                    <div id="steps" style="text-align: left; margin-top: 20px; font-size: 0.9em; color: #666;"></div>
                </div>

                <div class="graph-container">
                    <h3>Visualisasi Grafik</h3>
                    <div id="graph" style="width: 100%; height: 400px;"></div>
                </div>
            </div>
        </div>

        <div id="examples" class="tab-content">
            <h2>Contoh Soal Interaktif</h2>
            <p style="text-align: center; color: #666; margin-bottom: 30px;">Pilih contoh soal dan sistem akan menghitung jawaban secara otomatis</p>
            
            <div class="example-section">
                <h4>Contoh Soal 1:</h4>
                <p><strong>Soal:</strong> Volume benda putar apabila daerah pada kuadran I yang dibatasi kurva y = 4 - x², sumbu x, dan sumbu y diputar mengelilingi sumbu x sejauh 360° adalah...</p>
                
                <button class="calculate-btn" onclick="loadExample(1)" style="margin: 15px 0;">
                    🔄 Hitung Contoh Soal 1
                </button>
                
                <div id="solution1" class="solution-display" style="display: none;">
                    <div class="formula">
                        <h5>📋 Parameter yang digunakan:</h5>
                        <p>• Fungsi: y = 4 - x²</p>
                        <p>• Kuadran: I (x ≥ 0, y ≥ 0)</p>
                        <p>• Sumbu rotasi: X</p>
                        <p>• Batas: x = 0 sampai x = 2</p>
                    </div>
                    <div id="result1" class="result-calculation"></div>
                </div>
            </div>

            <div class="example-section">
                <h4>Contoh Soal 2:</h4>
                <p><strong>Soal:</strong> Volume benda putar yang terjadi untuk daerah yang dibatasi oleh kurva y = x² dan y = 2x diputar mengelilingi sumbu x sejauh 360° adalah...</p>
                
                <button class="calculate-btn" onclick="loadExample(2)" style="margin: 15px 0;">
                    🔄 Hitung Contoh Soal 2
                </button>
                
                <div id="solution2" class="solution-display" style="display: none;">
                    <div class="formula">
                        <h5>📋 Parameter yang digunakan:</h5>
                        <p>• Fungsi 1: y = x²</p>
                        <p>• Fungsi 2: y = 2x</p>
                        <p>• Metode: Washer (area antara dua kurva)</p>
                        <p>• Sumbu rotasi: X</p>
                        <p>• Batas: x = 0 sampai x = 2</p>
                    </div>
                    <div id="result2" class="result-calculation"></div>
                </div>
            </div>

            <div class="example-section">
                <h4>Contoh Soal 3 (Bonus):</h4>
                <p><strong>Soal:</strong> Volume benda putar untuk daerah yang dibatasi y = √x, sumbu x, dan garis x = 4 diputar mengelilingi sumbu x adalah...</p>
                
                <button class="calculate-btn" onclick="loadExample(3)" style="margin: 15px 0;">
                    🔄 Hitung Contoh Soal 3
                </button>
                
                <div id="solution3" class="solution-display" style="display: none;">
                    <div class="formula">
                        <h5>📋 Parameter yang digunakan:</h5>
                        <p>• Fungsi: y = √x</p>
                        <p>• Kuadran: I (x ≥ 0, y ≥ 0)</p>
                        <p>• Sumbu rotasi: X</p>
                        <p>• Batas: x = 0 sampai x = 4</p>
                    </div>
                    <div id="result3" class="result-calculation"></div>
                </div>
            </div>

            <div class="example-section" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                <h4>💡 Cara Kerja Sistem:</h4>
                <p>1. Klik tombol "Hitung Contoh Soal"</p>
                <p>2. Sistem akan otomatis mengisi parameter di tab Kalkulator</p>
                <p>3. Perhitungan dilakukan secara real-time</p>
                <p>4. Hasil ditampilkan dengan langkah-langkah detail</p>
                <p>5. Grafik visualisasi muncul otomatis</p>
            </div>
        </div>
        <div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='dashboardmahasiswa.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>
    </div>

    <script>
        let currentPlot = null;

        function openTab(evt, tabName) {
            const tabcontent = document.getElementsByClassName("tab-content");
            for (let i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            
            const tablinks = document.getElementsByClassName("tab-button");
            for (let i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
        }

        function updateBounds() {
            const quadrant = document.getElementById('quadrant').value;
            const lowerBound = document.getElementById('lowerBound');
            const upperBound = document.getElementById('upperBound');
            
            switch(quadrant) {
                case '1': // Kuadran I
                    lowerBound.value = 0;
                    upperBound.value = 2;
                    break;
                case '2': // Kuadran II
                    lowerBound.value = -2;
                    upperBound.value = 0;
                    break;
                case '3': // Kuadran III
                    lowerBound.value = -2;
                    upperBound.value = 0;
                    break;
                case '4': // Kuadran IV
                    lowerBound.value = 0;
                    upperBound.value = 2;
                    break;
            }
        }

        function parseFunction(funcStr) {
            // Konversi notasi matematika ke JavaScript
            return funcStr
                .replace(/\^/g, '**')
                .replace(/sqrt\(/g, 'Math.sqrt(')
                .replace(/sin\(/g, 'Math.sin(')
                .replace(/cos\(/g, 'Math.cos(')
                .replace(/tan\(/g, 'Math.tan(')
                .replace(/ln\(/g, 'Math.log(')
                .replace(/log\(/g, 'Math.log10(')
                .replace(/pi/g, 'Math.PI')
                .replace(/e/g, 'Math.E');
        }

        function evaluateFunction(funcStr, x) {
            try {
                const parsedFunc = parseFunction(funcStr);
                return eval(parsedFunc.replace(/x/g, x));
            } catch (error) {
                throw new Error('Fungsi tidak valid');
            }
        }

        function numericalIntegration(func, a, b, n = 1000) {
            const h = (b - a) / n;
            let sum = 0;
            
            for (let i = 0; i <= n; i++) {
                const x = a + i * h;
                const weight = (i === 0 || i === n) ? 1 : (i % 2 === 0) ? 2 : 4;
                try {
                    const y = evaluateFunction(func, x);
                    sum += weight * y * y; // y² untuk volume
                } catch (error) {
                    continue;
                }
            }
            
            return Math.PI * (h / 3) * sum;
        }

        function calculateVolume() {
            const funcStr = document.getElementById('function').value;
            const lowerBound = parseFloat(document.getElementById('lowerBound').value);
            const upperBound = parseFloat(document.getElementById('upperBound').value);
            const axis = document.getElementById('axis').value;
            const quadrant = document.getElementById('quadrant').value;
            
            const resultDiv = document.getElementById('result');
            const stepsDiv = document.getElementById('steps');
            
            try {
                if (!funcStr) {
                    throw new Error('Masukkan fungsi terlebih dahulu');
                }
                
                if (lowerBound >= upperBound) {
                    throw new Error('Batas bawah harus lebih kecil dari batas atas');
                }
                
                // Hitung volume menggunakan integrasi numerik
                const volume = numericalIntegration(funcStr, lowerBound, upperBound);
                
                resultDiv.innerHTML = `
                    <div class="result-value">${volume.toFixed(4)} satuan³</div>
                    <p><strong>Volume Eksakt:</strong> ${(volume/Math.PI).toFixed(4)}π satuan³</p>
                `;
                
                stepsDiv.innerHTML = `
                    <h4>Langkah Perhitungan:</h4>
                    <p>• Fungsi: y = ${funcStr}</p>
                    <p>• Kuadran: ${quadrant}</p>
                    <p>• Sumbu rotasi: ${axis.toUpperCase()}</p>
                    <p>• Batas integrasi: [${lowerBound}, ${upperBound}]</p>
                    <p>• Formula: V = π ∫ [f(x)]² dx</p>
                    <p>• Hasil: V ≈ ${volume.toFixed(4)} satuan³</p>
                `;
                
                // Gambar grafik
                plotGraph(funcStr, lowerBound, upperBound, quadrant);
                
            } catch (error) {
                resultDiv.innerHTML = `<div class="error-message">Error: ${error.message}</div>`;
                stepsDiv.innerHTML = '';
            }
        }

        function plotGraph(funcStr, a, b, quadrant) {
            const x = [];
            const y = [];
            const steps = 200;
            
            // Tentukan range berdasarkan kuadran
            let xMin, xMax, yMin, yMax;
            switch(quadrant) {
                case '1':
                    xMin = Math.min(a, 0) - 1;
                    xMax = Math.max(b, 0) + 1;
                    yMin = -1;
                    yMax = 10;
                    break;
                case '2':
                    xMin = Math.min(a, 0) - 1;
                    xMax = Math.max(b, 0) + 1;
                    yMin = -1;
                    yMax = 10;
                    break;
                case '3':
                    xMin = Math.min(a, 0) - 1;
                    xMax = Math.max(b, 0) + 1;
                    yMin = -10;
                    yMax = 1;
                    break;
                case '4':
                    xMin = Math.min(a, 0) - 1;
                    xMax = Math.max(b, 0) + 1;
                    yMin = -10;
                    yMax = 1;
                    break;
                default:
                    xMin = a - 1;
                    xMax = b + 1;
                    yMin = -5;
                    yMax = 5;
            }
            
            for (let i = 0; i <= steps; i++) {
                const xVal = xMin + (xMax - xMin) * i / steps;
                x.push(xVal);
                try {
                    y.push(evaluateFunction(funcStr, xVal));
                } catch (error) {
                    y.push(null);
                }
            }
            
            // Area yang diputar
            const xFill = [];
            const yFill = [];
            const fillSteps = 100;
            
            for (let i = 0; i <= fillSteps; i++) {
                const xVal = a + (b - a) * i / fillSteps;
                xFill.push(xVal);
                try {
                    yFill.push(evaluateFunction(funcStr, xVal));
                } catch (error) {
                    yFill.push(0);
                }
            }
            
            const data = [
                {
                    x: x,
                    y: y,
                    type: 'scatter',
                    mode: 'lines',
                    name: `y = ${funcStr}`,
                    line: { color: '#667eea', width: 3 }
                },
                {
                    x: xFill,
                    y: yFill,
                    fill: 'tozeroy',
                    type: 'scatter',
                    mode: 'lines',
                    name: 'Area yang diputar',
                    fillcolor: 'rgba(102, 126, 234, 0.3)',
                    line: { color: 'rgba(102, 126, 234, 0.8)', width: 2 }
                }
            ];
            
            const layout = {
                title: {
                    text: `Grafik Fungsi y = ${funcStr} pada Kuadran ${quadrant}`,
                    font: { size: 16 }
                },
                xaxis: {
                    title: 'x',
                    zeroline: true,
                    zerolinecolor: '#333',
                    zerolinewidth: 2,
                    range: [xMin, xMax],
                    gridcolor: '#ddd'
                },
                yaxis: {
                    title: 'y',
                    zeroline: true,
                    zerolinecolor: '#333',
                    zerolinewidth: 2,
                    range: [yMin, yMax],
                    gridcolor: '#ddd'
                },
                plot_bgcolor: '#f8f9fa',
                paper_bgcolor: 'white',
                showlegend: true,
                margin: { l: 50, r: 50, t: 50, b: 50 },
                responsive: true
            };
            
            const config = {
                responsive: true,
                displayModeBar: false
            };
            
            Plotly.newPlot('graph', data, layout, config);
        }

        // Inisialisasi grafik kosong
        window.onload = function() {
            const layout = {
                title: 'Grafik akan muncul setelah perhitungan',
                xaxis: { title: 'x' },
                yaxis: { title: 'y' },
                plot_bgcolor: '#f8f9fa',
                paper_bgcolor: 'white'
            };
            
            Plotly.newPlot('graph', [], layout, {responsive: true, displayModeBar: false});
        };

        // Fungsi untuk memuat contoh soal
        function loadExample(exampleNumber) {
            // Switch ke tab kalkulator
            document.querySelector('.tab-button:nth-child(2)').click();
            
            // Tunggu sebentar untuk transisi tab
            setTimeout(() => {
                switch(exampleNumber) {
                    case 1:
                        // Contoh Soal 1: y = 4 - x², kuadran I, sumbu x
                        document.getElementById('quadrant').value = '1';
                        document.getElementById('axis').value = 'x';
                        document.getElementById('function').value = '4 - x^2';
                        document.getElementById('lowerBound').value = '0';
                        document.getElementById('upperBound').value = '2';
                        
                        // Hitung otomatis
                        calculateVolume();
                        
                        // Tampilkan hasil di tab contoh soal
                        showExampleResult(1);
                        break;
                        
                    case 2:
                        // Contoh Soal 2: Metode washer - implementasi khusus
                        document.getElementById('quadrant').value = '1';
                        document.getElementById('axis').value = 'x';
                        document.getElementById('function').value = '2*x - x^2'; // Pendekatan untuk washer method
                        document.getElementById('lowerBound').value = '0';
                        document.getElementById('upperBound').value = '2';
                        
                        // Hitung dengan metode khusus untuk washer
                        calculateWasherMethod();
                        
                        // Tampilkan hasil di tab contoh soal
                        showExampleResult(2);
                        break;
                        
                    case 3:
                        // Contoh Soal 3: y = √x
                        document.getElementById('quadrant').value = '1';
                        document.getElementById('axis').value = 'x';
                        document.getElementById('function').value = 'sqrt(x)';
                        document.getElementById('lowerBound').value = '0';
                        document.getElementById('upperBound').value = '4';
                        
                        // Hitung otomatis
                        calculateVolume();
                        
                        // Tampilkan hasil di tab contoh soal
                        showExampleResult(3);
                        break;
                }
            }, 500);
        }

        function calculateWasherMethod() {
            // Khusus untuk contoh soal 2: y = x² dan y = 2x
            const volume = calculateWasherVolume();
            
            const resultDiv = document.getElementById('result');
            const stepsDiv = document.getElementById('steps');
            
            resultDiv.innerHTML = `
                <div class="result-value">${volume.toFixed(4)} satuan³</div>
                <p><strong>Volume Eksakt:</strong> ${(volume/Math.PI).toFixed(4)}π satuan³</p>
                <p><strong>Metode:</strong> Washer Method</p>
            `;
            
            stepsDiv.innerHTML = `
                <h4>Langkah Perhitungan (Washer Method):</h4>
                <p>• Fungsi luar: y = 2x</p>
                <p>• Fungsi dalam: y = x²</p>
                <p>• Titik potong: x = 0 dan x = 2</p>
                <p>• Formula: V = π ∫₀² [(2x)² - (x²)²] dx</p>
                <p>• V = π ∫₀² [4x² - x⁴] dx</p>
                <p>• Hasil: V ≈ ${volume.toFixed(4)} satuan³</p>
            `;
            
            // Plot grafik khusus untuk washer method
            plotWasherGraph();
        }

        function calculateWasherVolume() {
            // V = π ∫₀² [(2x)² - (x²)²] dx
            // V = π ∫₀² [4x² - x⁴] dx
            // V = π [4x³/3 - x⁵/5]₀²
            // V = π [32/3 - 32/5] = π [160/15 - 96/15] = 64π/15
            
            const analytical = (64 * Math.PI) / 15;
            return analytical;
        }

        function plotWasherGraph() {
            const x = [];
            const y1 = []; // y = 2x
            const y2 = []; // y = x²
            
            for (let i = 0; i <= 200; i++) {
                const xVal = 3 * i / 200;
                x.push(xVal);
                y1.push(2 * xVal);
                y2.push(xVal * xVal);
            }
            
            // Area antara kurva (untuk x = 0 sampai x = 2)
            const xFill = [];
            const y1Fill = [];
            const y2Fill = [];
            
            for (let i = 0; i <= 100; i++) {
                const xVal = 2 * i / 100;
                xFill.push(xVal);
                y1Fill.push(2 * xVal);
                y2Fill.push(xVal * xVal);
            }
            
            const data = [
                {
                    x: x,
                    y: y1,
                    type: 'scatter',
                    mode: 'lines',
                    name: 'y = 2x',
                    line: { color: '#ff6b6b', width: 3 }
                },
                {
                    x: x,
                    y: y2,
                    type: 'scatter',
                    mode: 'lines',
                    name: 'y = x²',
                    line: { color: '#4ecdc4', width: 3 }
                },
                {
                    x: xFill.concat(xFill.slice().reverse()),
                    y: y1Fill.concat(y2Fill.slice().reverse()),
                    fill: 'toself',
                    type: 'scatter',
                    mode: 'lines',
                    name: 'Area yang diputar',
                    fillcolor: 'rgba(255, 107, 107, 0.3)',
                    line: { color: 'rgba(255, 107, 107, 0.8)', width: 1 }
                }
            ];
            
            const layout = {
                title: 'Washer Method: Area antara y = 2x dan y = x²',
                xaxis: { title: 'x', range: [0, 3], gridcolor: '#ddd' },
                yaxis: { title: 'y', range: [0, 6], gridcolor: '#ddd' },
                plot_bgcolor: '#f8f9fa',
                paper_bgcolor: 'white',
                showlegend: true
            };
            
            Plotly.newPlot('graph', data, layout, {responsive: true, displayModeBar: false});
        }

        function showExampleResult(exampleNumber) {
            // Kembali ke tab contoh soal
            setTimeout(() => {
                document.querySelector('.tab-button:nth-child(3)').click();
                
                // Tampilkan hasil yang sesuai
                const solutionDiv = document.getElementById(`solution${exampleNumber}`);
                const resultDiv = document.getElementById(`result${exampleNumber}`);
                
                if (solutionDiv) {
                    solutionDiv.style.display = 'block';
                    
                    // Ambil hasil dari perhitungan
                    const calculatedResult = document.getElementById('result').innerHTML;
                    const calculatedSteps = document.getElementById('steps').innerHTML;
                    
                    if (resultDiv) {
                        resultDiv.innerHTML = `
                            <h5>🎯 Hasil Perhitungan:</h5>
                            ${calculatedResult}
                            <div style="margin-top: 15px; padding: 10px; background: rgba(255,255,255,0.7); border-radius: 8px;">
                                ${calculatedSteps}
                            </div>
                            <div style="text-align: center; margin-top: 15px;">
                                <small style="color: #666;">✅ Perhitungan selesai! Lihat grafik di tab Kalkulator</small>
                            </div>
                        `;
                    }
                }
            }, 1000);
        }
    </script>
</body>
</html>