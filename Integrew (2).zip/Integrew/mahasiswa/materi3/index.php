<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Luas Daerah dengan Rumus</title>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Rubik+Bubbles&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Open Sans', sans-serif;
      background-color: #fff;
      padding: 2rem;
      text-align: center;
    }

    .title-box {
      display: inline-block;
      border: 4px solid black;
      border-radius: 20px;
      padding: 1rem 2rem;
      font-family: 'Rubik Bubbles', cursive;
      font-size: 22px;
      color: #D55050;
      box-shadow: 4px 6px #db719b;
      margin-bottom: 2rem;
    }

    h2 {
      font-family: 'Rubik Bubbles', cursive;
      font-size: 25px;
      color: #cc5e5e;
      letter-spacing: 1px;
    }
    .rumus-btn-img {
      margin: 30px auto 25px;
      cursor: pointer;
      display: inline-block;
    }

    .rumus-btn-img img {
      width: 190px;
      height: auto;
    }

    .button{
        display: flex;
        flex-direction: column;
        margin-top: 30px;
    }
    .button button{
        margin: 10px;
        padding: 10px 5px;
        background-color: #ff5757;
        border: 2px solid #f4b9d3;
        border-bottom: 6px solid #a73832;
        color: white;
        font-family: 'Rubik Bubbles', cursive;
        font-size: 20px;
        border-radius: 30px;
    }

    .button button:hover {
      transform: scale(1.03);
    }

    /* Popup Style */
    .popup {
      display: none;
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: #ffffcc;
      border: 2px solid #333;
      padding: 25px;
      width: fit-content;
      z-index: 1000;
      border-radius: 15px;
      box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
      text-align: center;
    }

    .popup img {
      width: 200px;
      border-radius: 10px;
    }

    .close-btn {
      position: absolute;
      right: 12px;
      top: 8px;
      font-size: 20px;
      cursor: pointer;
      color: #a73832;
    }
    p{
      font-size:11px;
      text-align: justify;
    }
        .btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
  </style>
</head>
<body>

  <div class="title-box">Menghitung luas daerah menggunakan rumus</div>

  <!-- Tombol Rumus Gambar -->
  <div class="rumus-btn-img" id="btnRumus">
    <p>Berikut rumus untuk menghitung luas daerah datar.</p>
    <img src="gambar/integrew-3.png" alt="D = b² - 4ac">
  </div>

  <!-- Tombol Latihan & Kuis -->
  <div class="button">
    <button onclick="window.location.href='latihansoal.php'">latihan soal</button>
    <button onclick="window.location.href='kuis.php'">kuis</button>
  </div>
  <div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='../menu-materi.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>

  <!-- Popup -->
  <div class="popup" id="popupRumus">
    <span class="close-btn" onclick="closePopup()">&times;</span>
    <img src="gambar/integrew-4.png" alt="Penjelasan Rumus">
  </div>

  <!-- Script -->
  <script>
    const popup = document.getElementById('popupRumus');
    const btnRumus = document.getElementById('btnRumus');

    btnRumus.addEventListener('click', function () {
      popup.style.display = 'block';
    });

    function closePopup() {
      popup.style.display = 'none';
    }

    window.addEventListener('click', function (event) {
      if (event.target === popup) {
        popup.style.display = 'none';
      }
    });
  </script>

</body>
</html>
