<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalkulator Panjang Kurva Integral</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjs/11.11.0/math.min.js"></script>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
        }
.btn-group {
      text-align: center;
      margin-bottom: 20px;
    }

    .btn-nav {
      background-color: maroon;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(128, 0, 0, 0.3);
    }

    .btn-nav:hover {
      background-color: #990000;
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(128, 0, 0, 0.4);
    }
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }

        .tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 5px;
        }

        .tab {
            flex: 1;
            max-width: 200px;
            padding: 15px 20px;
            text-align: center;
            background: transparent;
            border: none;
            border-radius: 10px;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .tab.active {
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 16px rgba(31, 38, 135, 0.4);
        }

        .tab:hover {
            background: rgba(255, 255, 255, 0.15);
        }

        .content {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }

        .formula-section {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border-radius: 15px;
            padding: 25px;
            margin: 20px 0;
            border-left: 5px solid #667eea;
        }

        .formula {
            font-size: 1.3rem;
            text-align: center;
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin: 15px 0;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
            font-family: 'Courier New', monospace;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }

        .input-group input, .input-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .input-group input:focus, .input-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 50px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .btn:active {
            transform: translateY(0);
        }

        .result {
            background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
            border-radius: 15px;
            padding: 25px;
            margin-top: 20px;
            border-left: 5px solid #4ecdc4;
        }

        .result h3 {
            color: #2c3e50;
            margin-bottom: 15px;
        }

        .steps {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-top: 15px;
        }

        .step {
            margin-bottom: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }

        .graph-container {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-top: 20px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }

        .example-card {
            background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
            border-radius: 15px;
            padding: 25px;
            margin: 20px 0;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }

        .example-card h3 {
            color: #d63384;
            margin-bottom: 15px;
        }

        .instruction {
            background: #e3f2fd;
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
            border-left: 4px solid #2196f3;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }

            .header h1 {
                font-size: 2rem;
            }

            .tabs {
                flex-direction: column;
            }

            .tab {
                max-width: none;
                margin: 2px 0;
            }

            .content {
                padding: 20px;
            }

            .formula {
                font-size: 1.1rem;
                padding: 15px;
            }
        }

        .warning {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 12px;
            margin: 10px 0;
            color: #856404;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧮 Kalkulator Panjang Kurva Integral</h1>
            <p>Hitung panjang kurva menggunakan integral dengan mudah dan akurat</p>
        </div>

        <div class="tabs">
            <button class="tab active" onclick="showTab('theory')">📚 Materi</button>
            <button class="tab" onclick="showTab('calculator')">🧮 Kalkulator</button>
            <button class="tab" onclick="showTab('examples')">📝 Contoh Soal</button>
        </div>

        <div id="theory" class="tab-content active">
            <div class="content">
                <h2>📐 Konsep Panjang Kurva</h2>
                <p>Panjang kurva adalah jarak sepanjang kurva dari satu titik ke titik lainnya. Dalam kalkulus, kita dapat menghitung panjang kurva menggunakan integral.</p>

                <div class="formula-section">
                    <h3>📊 Rumus untuk Kurva y = f(x)</h3>
                    <div class="formula">
                        L = ∫[a to b] √(1 + (dy/dx)²) dx
                    </div>
                    <p><strong>Dimana:</strong></p>
                    <ul>
                        <li>L = Panjang kurva</li>
                        <li>a, b = Batas bawah dan atas integral</li>
                        <li>dy/dx = Turunan dari fungsi y = f(x)</li>
                    </ul>
                </div>

                <div class="formula-section">
                    <h3>📈 Rumus untuk Kurva x = g(y)</h3>
                    <div class="formula">
                        L = ∫[c to d] √(1 + (dx/dy)²) dy
                    </div>
                    <p><strong>Dimana:</strong></p>
                    <ul>
                        <li>L = Panjang kurva</li>
                        <li>c, d = Batas bawah dan atas integral</li>
                        <li>dx/dy = Turunan dari fungsi x = g(y)</li>
                    </ul>
                </div>

                <div class="instruction">
                    <h4>💡 Cara Penggunaan Kalkulator:</h4>
                    <ol>
                        <li>Pilih jenis kurva (y = f(x) atau x = g(y))</li>
                        <li>Masukkan fungsi dengan notasi yang benar</li>
                        <li>Tentukan batas integral</li>
                        <li>Klik tombol "Hitung Panjang Kurva"</li>
                    </ol>
                </div>

                <div class="warning">
                    <strong>⚠️ Petunjuk Penulisan Fungsi:</strong><br>
                    • Gunakan notasi matematis standar: x^2, sqrt(x), sin(x), cos(x), log(x)<br>
                    • Contoh: x^2 + 3*x - 1, sqrt(4 - x^2), sin(x) + cos(x)
                </div>
            </div>
        </div>

        <div id="calculator" class="tab-content">
            <div class="content">
                <h2>🧮 Kalkulator Panjang Kurva</h2>
                
                <div class="input-group">
                    <label for="curveType">Pilih Jenis Kurva:</label>
                    <select id="curveType" onchange="updateFormula()">
                        <option value="y">y = f(x)</option>
                        <option value="x">x = g(y)</option>
                    </select>
                </div>

                <div class="input-group">
                    <label for="function" id="functionLabel">Masukkan Fungsi y = f(x):</label>
                    <input type="text" id="function" placeholder="Contoh: x^2 + 3*x - 1">
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="input-group">
                        <label for="lowerBound" id="lowerLabel">Batas Bawah (a):</label>
                        <input type="number" id="lowerBound" step="0.1" placeholder="0">
                    </div>
                    <div class="input-group">
                        <label for="upperBound" id="upperLabel">Batas Atas (b):</label>
                        <input type="number" id="upperBound" step="0.1" placeholder="1">
                    </div>
                </div>

                <button class="btn" onclick="calculateCurveLength()">🚀 Hitung Panjang Kurva</button>

                <div id="calculatorResult"></div>
            </div>
        </div>

        <div id="examples" class="tab-content">
            <div class="content">
                <h2>📝 Contoh Soal</h2>
                
                <div class="example-card">
                    <h3>Contoh 1: Kurva y = x²</h3>
                    <p><strong>Soal:</strong> Hitunglah panjang kurva y = x² dari x = 0 sampai x = 1</p>
                    <p><strong>Fungsi:</strong> x^2</p>
                    <p><strong>Batas:</strong> a = 0, b = 1</p>
                    <button class="btn" onclick="loadExample1()">📊 Hitung Contoh Ini</button>
                </div>

                <div class="example-card">
                    <h3>Contoh 2: Kurva y = √x</h3>
                    <p><strong>Soal:</strong> Hitunglah panjang kurva y = √x dari x = 0 sampai x = 4</p>
                    <p><strong>Fungsi:</strong> sqrt(x)</p>
                    <p><strong>Batas:</strong> a = 0, b = 4</p>
                    <button class="btn" onclick="loadExample2()">📊 Hitung Contoh Ini</button>
                </div>

                <div class="example-card">
                    <h3>Contoh 3: Kurva x = y²</h3>
                    <p><strong>Soal:</strong> Hitunglah panjang kurva x = y² dari y = 0 sampai y = 2</p>
                    <p><strong>Fungsi:</strong> y^2</p>
                    <p><strong>Batas:</strong> c = 0, d = 2</p>
                    <button class="btn" onclick="loadExample3()">📊 Hitung Contoh Ini</button>
                </div>
            </div>
        </div>
        <div class="btn-group">
      <button class="btn-nav" onclick="window.location.href='dashboardmahasiswa.php'" style="margin-top:20px;">← Kembali ke Beranda</button>
    </div>
    </div>

    <script>
        function showTab(tabName) {
            const tabs = document.querySelectorAll('.tab');
            const contents = document.querySelectorAll('.tab-content');
            
            tabs.forEach(tab => tab.classList.remove('active'));
            contents.forEach(content => content.classList.remove('active'));
            
            event.target.classList.add('active');
            document.getElementById(tabName).classList.add('active');
        }

        function updateFormula() {
            const curveType = document.getElementById('curveType').value;
            const functionLabel = document.getElementById('functionLabel');
            const lowerLabel = document.getElementById('lowerLabel');
            const upperLabel = document.getElementById('upperLabel');
            
            if (curveType === 'y') {
                functionLabel.textContent = 'Masukkan Fungsi y = f(x):';
                lowerLabel.textContent = 'Batas Bawah (a):';
                upperLabel.textContent = 'Batas Atas (b):';
            } else {
                functionLabel.textContent = 'Masukkan Fungsi x = g(y):';
                lowerLabel.textContent = 'Batas Bawah (c):';
                upperLabel.textContent = 'Batas Atas (d):';
            }
        }

        function calculateCurveLength() {
            const curveType = document.getElementById('curveType').value;
            const functionStr = document.getElementById('function').value;
            const lowerBound = parseFloat(document.getElementById('lowerBound').value);
            const upperBound = parseFloat(document.getElementById('upperBound').value);

            if (!functionStr || isNaN(lowerBound) || isNaN(upperBound)) {
                alert('Mohon lengkapi semua input!');
                return;
            }

            try {
                let result;
                if (curveType === 'y') {
                    result = calculateYCurve(functionStr, lowerBound, upperBound);
                } else {
                    result = calculateXCurve(functionStr, lowerBound, upperBound);
                }

                displayResult(result, curveType, functionStr, lowerBound, upperBound);
                
            } catch (error) {
                alert('Error dalam perhitungan: ' + error.message);
            }
        }

        function calculateYCurve(functionStr, a, b) {
            // Hitung turunan menggunakan definisi simbolik
            const derivative = math.derivative(functionStr, 'x');
            const derivativeStr = derivative.toString();
            
            // Fungsi integrand: sqrt(1 + (dy/dx)^2)
            const integrandStr = `sqrt(1 + (${derivativeStr})^2)`;
            
            // Hitung integral menggunakan metode Simpson yang lebih akurat
            const length = simpsonRule(integrandStr, 'x', a, b, 10000);
            
            return {
                originalFunction: functionStr,
                derivative: derivativeStr,
                integrand: integrandStr,
                length: length,
                variable: 'x',
                lowerBound: a,
                upperBound: b
            };
        }

        function calculateXCurve(functionStr, c, d) {
            // Hitung turunan dx/dy
            const derivative = math.derivative(functionStr, 'y');
            const derivativeStr = derivative.toString();
            
            // Fungsi integrand: sqrt(1 + (dx/dy)^2)
            const integrandStr = `sqrt(1 + (${derivativeStr})^2)`;
            
            // Hitung integral menggunakan metode Simpson
            const length = simpsonRule(integrandStr, 'y', c, d, 10000);
            
            return {
                originalFunction: functionStr,
                derivative: derivativeStr,
                integrand: integrandStr,
                length: length,
                variable: 'y',
                lowerBound: c,
                upperBound: d
            };
        }

        function simpsonRule(functionStr, variable, a, b, n) {
            // Pastikan n genap
            if (n % 2 !== 0) n++;
            
            const h = (b - a) / n;
            let sum = 0;
            
            for (let i = 0; i <= n; i++) {
                const x = a + i * h;
                const scope = {};
                scope[variable] = x;
                
                try {
                    const value = math.evaluate(functionStr, scope);
                    if (isFinite(value) && !isNaN(value)) {
                        if (i === 0 || i === n) {
                            sum += value;
                        } else if (i % 2 === 1) {
                            sum += 4 * value;
                        } else {
                            sum += 2 * value;
                        }
                    }
                } catch (e) {
                    // Jika ada error evaluasi, skip titik ini
                    console.warn(`Error evaluating at ${variable} = ${x}:`, e);
                }
            }
            
            return (h / 3) * sum;
        }

        function displayResult(result, curveType, functionStr, lowerBound, upperBound) {
            const resultDiv = document.getElementById('calculatorResult');
            const curveLabel = curveType === 'y' ? 'y' : 'x';
            const independentVar = curveType === 'y' ? 'x' : 'y';
            const bounds = curveType === 'y' ? 
                `dari x = ${lowerBound} sampai x = ${upperBound}` : 
                `dari y = ${lowerBound} sampai y = ${upperBound}`;
            
            // Format derivative untuk tampilan yang lebih baik
            let derivativeDisplay = result.derivative;
            
            resultDiv.innerHTML = `
                <div class="result">
                    <h3>📊 Hasil Perhitungan</h3>
                    <p><strong>Fungsi:</strong> ${curveLabel} = ${functionStr}</p>
                    <p><strong>Interval:</strong> ${bounds}</p>
                    <p><strong>Panjang Kurva:</strong> <span style="font-size: 1.2em; color: #667eea; font-weight: bold;">${result.length.toFixed(6)} satuan</span></p>
                    
                    <div class="steps">
                        <h4>🔍 Langkah-langkah Penyelesaian:</h4>
                        
                        <div class="step">
                            <strong>Langkah 1: Menentukan Turunan</strong><br>
                            Diberikan: ${curveLabel} = ${functionStr}<br><br>
                            Hitung turunan:<br>
                            <div style="text-align: center; font-family: 'Courier New', monospace; font-size: 1.1em; margin: 10px 0; padding: 10px; background: #f0f0f0; border-radius: 5px;">
                                d${curveLabel}/d${independentVar} = ${derivativeDisplay}
                            </div>
                        </div>
                        
                        <div class="step">
                            <strong>Langkah 2: Menyusun Rumus Panjang Kurva</strong><br>
                            Rumus panjang kurva untuk ${curveLabel} = f(${independentVar}):<br>
                            <div style="text-align: center; font-family: 'Courier New', monospace; font-size: 1.1em; margin: 10px 0; padding: 10px; background: #f0f0f0; border-radius: 5px;">
                                L = ∫<sub>${lowerBound}</sub><sup>${upperBound}</sup> √(1 + (d${curveLabel}/d${independentVar})²) d${independentVar}
                            </div>
                        </div>
                        
                        <div class="step">
                            <strong>Langkah 3: Substitusi Turunan</strong><br>
                            Substitusikan d${curveLabel}/d${independentVar} = ${derivativeDisplay}:<br>
                            <div style="text-align: center; font-family: 'Courier New', monospace; font-size: 1.1em; margin: 10px 0; padding: 10px; background: #f0f0f0; border-radius: 5px;">
                                L = ∫<sub>${lowerBound}</sub><sup>${upperBound}</sup> √(1 + (${derivativeDisplay})²) d${independentVar}
                            </div>
                        </div>
                        
                        <div class="step">
                            <strong>Langkah 4: Sederhanakan Integrand</strong><br>
                            Fungsi yang akan diintegralkan:<br>
                            <div style="text-align: center; font-family: 'Courier New', monospace; font-size: 1.1em; margin: 10px 0; padding: 10px; background: #f0f0f0; border-radius: 5px;">
                                f(${independentVar}) = √(1 + (${derivativeDisplay})²)
                            </div>
                        </div>
                        
                        <div class="step">
                            <strong>Langkah 5: Evaluasi Integral</strong><br>
                            Menggunakan metode numerik (Simpson's Rule):<br>
                            <div style="text-align: center; font-family: 'Courier New', monospace; font-size: 1.1em; margin: 10px 0; padding: 10px; background: #f0f0f0; border-radius: 5px;">
                                L = ∫<sub>${lowerBound}</sub><sup>${upperBound}</sup> √(1 + (${derivativeDisplay})²) d${independentVar} = ${result.length.toFixed(6)}
                            </div>
                        </div>
                        
                        <div class="step" style="background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); border-left: 4px solid #4ecdc4;">
                            <strong>🎯 Kesimpulan:</strong><br>
                            Panjang kurva ${curveLabel} = ${functionStr} dari ${independentVar} = ${lowerBound} sampai ${independentVar} = ${upperBound} adalah <strong>${result.length.toFixed(6)} satuan</strong>
                        </div>
                    </div>
                </div>
            `;
        }

        function plotGraph(functionStr, lowerBound, upperBound, curveType) {
            // Fungsi ini dihapus karena grafik tidak diperlukan
        }

        function loadExample1() {
            showTab('calculator');
            setTimeout(() => {
                document.getElementById('curveType').value = 'y';
                document.getElementById('function').value = 'x^2';
                document.getElementById('lowerBound').value = '0';
                document.getElementById('upperBound').value = '1';
                updateFormula();
                calculateCurveLength();
            }, 100);
        }

        function loadExample2() {
            showTab('calculator');
            setTimeout(() => {
                document.getElementById('curveType').value = 'y';
                document.getElementById('function').value = 'sqrt(x)';
                document.getElementById('lowerBound').value = '0';
                document.getElementById('upperBound').value = '4';
                updateFormula();
                calculateCurveLength();
            }, 100);
        }

        function loadExample3() {
            showTab('calculator');
            setTimeout(() => {
                document.getElementById('curveType').value = 'x';
                document.getElementById('function').value = 'y^2';
                document.getElementById('lowerBound').value = '0';
                document.getElementById('upperBound').value = '2';
                updateFormula();
                calculateCurveLength();
            }, 100);
        }

        // Initialize
        updateFormula();
    </script>
</body>
</html>