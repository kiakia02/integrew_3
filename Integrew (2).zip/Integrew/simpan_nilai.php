<?php
header('Content-Type: application/json');
session_start();

// Konfigurasi database
$host     = 'localhost';
$dbname   = 'dbintegrew';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Koneksi database gagal: ' . $e->getMessage()]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$skor       = $data['skor'];
$materi     = $data['materi'];
$jenis      = $data['jenis'];
$kelas_user = $_SESSION['kelas'] ?? '';
$nama_user  = $_SESSION['nama'] ?? '';

if (empty($kelas_user) || empty($nama_user) || empty($materi) || !is_numeric($skor)) {
    echo json_encode(['status' => 'error', 'message' => 'Data tidak valid.']);
    exit;
}

try {
    $stmt = $pdo->prepare("INSERT INTO nilai (kelas, nama, materi, jenis, skor) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$kelas_user, $nama_user, $materi, $jenis, $skor]);
    echo json_encode(['status' => 'success']);
    exit;
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan nilai: ' . $e->getMessage()]);
    exit;
}
?>