<?php
include "../db.php";
session_start();

$login_error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role     = strtolower(trim($_POST['role']));

    // Validasi input tidak boleh kosong
    if (empty($username) || empty($password) || empty($role)) {
        $login_error = "Semua field harus diisi!";
    } else {
        // Cek koneksi database
        if (!$conn) {
            $login_error = "Koneksi database gagal!";
        } else {
            // Gunakan LOWER untuk pencocokan case-insensitive di SQL
            $stmt = $conn->prepare("SELECT * FROM user WHERE username = ? AND password = ? AND LOWER(role) = ?");
            
            if ($stmt) {
                $stmt->bind_param("sss", $username, $password, $role);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows == 1) {
                    $user_data = $result->fetch_assoc();
                    
                    // Set session data
                    $_SESSION['username'] = $username;
                    $_SESSION['role'] = $role;
                    $_SESSION['user_id'] = $user_data['id'] ?? null; // Jika ada kolom id
                    $_SESSION['nama'] = $user_data['nama'] ?? $username;
                    
                    // Jika mahasiswa, ambil data kelas
                    if ($role === 'mahasiswa') {
                        // Ambil kelas mahasiswa dari database
                        $kelas_stmt = $conn->prepare("SELECT kelas FROM user WHERE username = ?");
                        $kelas_stmt->bind_param("s", $username);
                        $kelas_stmt->execute();
                        $kelas_result = $kelas_stmt->get_result();
                        
                        if ($kelas_result->num_rows == 1) {
                            $kelas_data = $kelas_result->fetch_assoc();
                            $_SESSION['kelas'] = trim($kelas_data['kelas']); // Set kelas ke session
                        } else {
                            // Jika tidak ada kelas, set default atau error
                            $_SESSION['kelas'] = '';
                        }
                        $kelas_stmt->close();
                    }

                    // Redirect berdasarkan role
                    if ($role === 'admin') {
                        header("Location: ../admin/admin.php");
                        exit;
                    } elseif ($role === 'mahasiswa') {
                        header("Location: ../mahasiswa/dashboardmahasiswa.php");
                        exit;
                    } elseif ($role === 'dosen') {
                        header("Location: ../dosen/dosen.php");
                        exit;
                    }
                } else {
                    $login_error = "Login gagal! Username, password, atau role salah.";
                }

                $stmt->close();
            } else {
                $login_error = "Error dalam query database: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Integrew Login</title>
    <style>
body {
    background-color: white;
    text-align: center;
    font-family: 'Fredoka One', cursive;
    margin: 0;
    padding: 0 10px;
}

.title {
    font-size: 70px;
    color: #d4504c;
    margin-top: 200px;
    letter-spacing: 2px;
    text-shadow: 2px 2px 0 #ffffff, 4px 4px 0 #d4504c;
}

.login-form {
    margin: 100px auto;
    max-width: 480px;
    width: 100%;
}

.login-form input,
.login-form select {
    width: 100%;
    padding: 18px;
    margin: 30px 0;
    border: 3px solid #7b2e2e;
    border-radius: 14px;
    font-size: 22px;
    font-weight: bold;
    color: #555;
    box-shadow: 4px 4px #b45252;
    font-family: 'Fredoka One', cursive;
    background-color: white;
    box-sizing: border-box;
}

.login-form select {
    appearance: none;
    background-image: url("data:image/svg+xml;utf8,<svg fill='gray' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>");
    background-repeat: no-repeat;
    background-position: right 14px center;
    background-size: 24px;
}

.login-form button {
    background-color: #fbc271;
    color: white;
    font-size: 26px;
    padding: 16px;
    border: none;
    border-radius: 14px;
    font-family: 'Fredoka One', cursive;
    box-shadow: none;
    cursor: pointer;
    width: 100%;
    box-sizing: border-box;
    margin-top:50px;
}

.login-form button:hover {
    background-color: #f9b655;
}

.error {
    color: red;
    font-family: 'Fredoka One', cursive;
    margin-top: 14px;
    font-size: 18px;
}

/* Responsif untuk layar kecil */
@media (max-width: 480px) {
    .title {
        font-size: 100px;
        margin-top: 110px;
    }

    .login-form input,
    .login-form select,
    .login-form button {
        font-size: 50px;
        padding: 46px;
    }
}

    </style>
</head>
<body>
    <h1 class="title">Integrew</h1>

    <?php if (!empty($login_error)): ?>
        <p class="error"><?= htmlspecialchars($login_error) ?></p>
    <?php endif; ?>

    <form method="POST" class="login-form">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <select name="role" required>
            <option value="" disabled selected>Role</option>
            <option value="admin">Admin & Dosen</option>
            <option value="mahasiswa">Mahasiswa</option>
        </select>
        <button type="submit">Masuk</button>
    </form>
</body>
</html>
