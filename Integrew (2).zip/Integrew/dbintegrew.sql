-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2025 at 12:29 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbintegrew`
--

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `iddosen` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `namadosen` varchar(50) NOT NULL,
  `matakuliah` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`iddosen`, `username`, `password`, `namadosen`, `matakuliah`, `role`) VALUES
(1062571, '2345', '2345', 'Indah Riezky Pratiwi', 'Kalkulus', 'Dosen'),
(1062572, 'iniimle', 'imel', 'Vivin Mahatvira', 'Pemrograman Web Lanjut', 'Dosen');

-- --------------------------------------------------------

--
-- Table structure for table `latihansoal`
--

CREATE TABLE `latihansoal` (
  `id` int(11) NOT NULL,
  `judul_latihan` varchar(255) NOT NULL,
  `soal` text DEFAULT NULL,
  `opsi_a` text DEFAULT NULL,
  `opsi_b` text DEFAULT NULL,
  `opsi_c` text DEFAULT NULL,
  `opsi_d` text DEFAULT NULL,
  `opsijawaban` varchar(255) DEFAULT NULL,
  `jawaban` text DEFAULT NULL,
  `kelas` varchar(100) DEFAULT NULL,
  `materi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `latihansoal`
--

INSERT INTO `latihansoal` (`id`, `judul_latihan`, `soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsijawaban`, `jawaban`, `kelas`, `materi`) VALUES
(6, 'Integral tak tentu', 'Berapakah hasil dari ∫5x dx', '2x^2 + C', '5x^2 + x + C', '(5/2)x^2 + C', '5x + C', 'B', '∫5x dx= (5/2)x^2 +C', '1 TRPL A', 'materi1'),
(8, 'Dasar Integral', 'Jika F\'(x) = 2x + 5 dan F(0) = 1, maka F(x) adalah...', 'x² + 5x + 1', 'x² + 5x + C', '2 + 1', 'x² + 5x - 1', 'A', 'Integralkan F\'(x): F(x) = x² + 5x + C.\r\nCari C dengan F(0)=1:\r\n1 = (0)² + 5(0) + C\r\n1 = C.\r\nHasil: F(x) = x² + 5x + 1.', '1 TRPL B', 'materi1'),
(9, 'Dasar Integral', 'Nilai dari ∫₀^(π/2) sin x dx adalah...', '0', '1', '-1', 'π/2', 'B', 'Integral dari sin x adalah -cos x.\r\nHitung batas:\r\n-cos(π/2) = 0.\r\n-cos(0) = -1.\r\nKurangkan: 0 - (-1) = 1.', '1 TRPL B', 'materi1'),
(10, 'Dasar Integral', 'Hasil dari ∫ (e³ˣ) dx adalah...', 'e³ˣ + C', '3e³ˣ + C', '(1/3)e³ˣ + C', 'e³ˣ / 3x + C', 'C', 'Integral dari e^(ax) adalah (1/a)e^(ax).\r\nDi sini a=3. Jadi, (1/3)e³ˣ + C.', '1 TRPL B', 'materi1'),
(11, 'Dasar Integral', 'Jika ∫₋₂² f(x) dx = 9 dan ∫₁² f(x) dx = 3, maka ∫₋₂¹ f(x) dx adalah...', '5', '8', '2', '6', 'D', 'Gunakan sifat integral: ∫₋₂² = ∫₋₂¹ + ∫₁².\r\n9 = ∫₋₂¹ f(x) dx + 3.\r\nJadi, ∫₋₂¹ f(x) dx = 9 - 3 = 6.', '1 TRPL B', 'materi1'),
(12, 'Dasar Integral', 'Hasil dari ∫ (5x⁴ + 2x³ - x² + 8) dx adalah...', 'x⁵ + (1/2)x⁴ - (1/3)x³ + 8x + C', 'x⁵ + 2x⁴ - x³ + 8x + C', '20x³ + 6x² - 2x + C', '5x⁵ + 2x⁴ - x³ + 8x + C', 'A', 'Integralkan setiap suku dengan menambah pangkatnya 1 dan membagi dengan pangkat baru:\r\n∫ 5x⁴ dx = x⁵\r\n∫ 2x³ dx = (1/2)x⁴\r\n∫ -x² dx = -(1/3)x³\r\n∫ 8 dx = 8x\r\nGabungkan dan tambah C.', '1 TRPL B', 'materi1'),
(13, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh y = x², sumbu-x, dari x = 0 sampai x = 3 adalah...', '9 satuan luas', '11/2 satuan luas', '13/2 satuan luas', '17/2 satuan luas', 'A', 'Kurva selalu di atas sumbu-x pada interval tersebut.\r\nIntegral tak tentu: (1/3)x³.\r\nHitung: [ (1/3)x³ ]₀³ = (1/3)(3)³ - 0 = 9 - 0 = 9.', '1 TRPL B', 'materi2'),
(14, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh kurva x = y² - 4 dan sumbu-y, dari y = 0 sampai y = 3 adalah...', '19/3 satuan luas', '17/3 satuan luas', '23/3 satuan luas', '25/3 satuan luas', 'C', 'Kurva memotong sumbu-y di y = 2 dan y = -2.\r\nInterval [0, 2] di kiri sumbu-y (x < 0), interval [2, 3] di kanan sumbu-y (x > 0).\r\nIntegral tak tentu: (1/3)y³ - 4y.\r\nHitung: | ∫₀² (y² - 4) dy | + ∫₂³ (y² - 4) dy.\r\n∫₀² (y² - 4) dy = [ (1/3)y³ - 4y ]₀² = ( (1/3)(2)³ - 4(2) ) - 0 = (8/3 - 8) = -16/3. Luas 1 = |-16/3| = 16/3.\r\n∫₂³ (y² - 4) dy = [ (1/3)y³ - 4y ]₂³ = ( (1/3)(3)³ - 4(3) ) - ( (1/3)(2)³ - 4(2) ) = (9 - 12) - (8/3 - 8) = -3 - (-16/3) = -9/3 + 16/3 = 7/3. Luas 2 = 7/3.\r\nTotal Luas: 16/3 + 7/3 = 23/3.', '1 TRPL B', 'materi2'),
(15, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh y = (x + 1)², sumbu-x, garis x = -2, dan x = 0 adalah...', '2/3 satuan luas', '4/3 satuan luas', '8/3 satuan luas', '10/3 satuan luas', 'A', 'Kurva selalu di atas sumbu-x.\r\nIntegral tak tentu: ∫ (x + 1)² dx = (1/3)(x + 1)³.\r\nHitung: [ (1/3)(x + 1)³ ]₋₂⁰ = (1/3)(0 + 1)³ - (1/3)(-2 + 1)³ = (1/3)(1)³ - (1/3)(-1)³ = 1/3 - (-1/3) = 2/3.', '1 TRPL B', 'materi2'),
(16, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh y = x⁴ - 1 dan sumbu-x, dari x = -1 sampai x = 1 adalah...', '4/5 satuan luas', '8/5 satuan luas', '2/5 satuan luas', '12/5 satuan luas', 'B', 'Titik potong sumbu-x: x⁴ - 1 = 0 → (x² - 1)(x² + 1) = 0 → x = -1 dan x = 1 (karena x² + 1 = 0 tidak ada solusi real).\r\nKurva di bawah sumbu-x pada interval [-1, 1]. Ambil nilai mutlak.\r\nIntegral tak tentu: (1/5)x⁵ - x.\r\nHitung: | [ (1/5)x⁵ - x ]₋₁¹ | = | ( (1/5)(1)⁵ - 1 ) - ( (1/5)(-1)⁵ - (-1) ) |\r\n= | (1/5 - 1) - (-1/5 + 1) | = | (-4/5) - (4/5) | = |-8/5| = 8/5.', '1 TRPL B', 'materi2'),
(17, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh y = x dan y = x³ adalah...', '1/2 satuan luas', '1/4 satuan luas', '1/3 satuan luas', '1/6 satuan luas', 'A', 'Titik potong: x = x³ → x³ - x = 0 → x(x² - 1) = 0 → x = -1, x = 0, x = 1.\r\nInterval [-1, 0]: y = x³ di atas y = x. Interval [0, 1]: y = x di atas y = x³.\r\nIntegral tak tentu:\r\nUntuk x³ - x: (1/4)x⁴ - (1/2)x².\r\nUntuk x - x³: (1/2)x² - (1/4)x⁴.\r\nHitung: ∫₋₁⁰ (x³ - x) dx + ∫₀¹ (x - x³) dx.\r\nUntuk ∫₋₁⁰ (x³ - x) dx: F(0) - F(-1) = 0 - (1/4 - 1/2) = 1/4.\r\nUntuk ∫₀¹ (x - x³) dx: G(1) - G(0) = (1/2 - 1/4) - 0 = 1/4.\r\nTotal Luas: 1/4 + 1/4 = 1/2.', '1 TRPL B', 'materi2'),
(18, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh kurva y = 2x² dan y = 10x adalah...', '125/3 satuan luas', '50/3 satuan luas', '25/3 satuan luas', '100/3 satuan luas', 'A', 'Titik potong: x = 0 dan x = 5.\r\nFungsi selisih: y_atas - y_bawah = 10x - 2x² (a=-2).\r\nRumus Luas: |a/6| (x₂ - x₁ )³.\r\nLuas = |-2/6| (5 - 0)³ = 125/3.', '1 TRPL B', 'materi3'),
(19, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh y = x² - 2x dan y = x adalah...', '9/2 satuan luas', '7/2 satuan luas', '5/2 satuan luas', '3/2 satuan luas', 'A', 'Titik potong: x = 0 dan x = 3.\r\nFungsi selisih: y_atas - y_bawah = x - (x² - 2x) = -x² + 3x (a=-1).\r\nRumus Luas: |a/6| (x₂ - x₁ )³.\r\nLuas = |-1/6| (3 - 0)³ = 9/2.', '1 TRPL B', 'materi3'),
(20, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh kurva x = y² - 2y dan sumbu-y adalah...', '2/3 satuan luas', '1/3 satuan luas', '4/3 satuan luas', '1 satuan luas', 'C', 'Titik potong sumbu-y: y = 0 dan y = 2.\r\nRumus Luas: |a/6| (y₂ - y₁ )³. Di sini a=1 (dari y²).\r\nLuas = |1/6| (2 - 0)³ = 4/3.', '1 TRPL B', 'materi3'),
(21, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh y = -x² - 2x dan sumbu-x adalah...', '4/3 satuan luas', '1/3 satuan luas', '2/3 satuan luas', '1 satuan luas', 'A', 'Titik potong sumbu-x: x = 0 dan x = -2.\r\nRumus Luas: |a/6| (x₂ - x₁ )³. Di sini a=-1.\r\nLuas = |-1/6| (0 - (-2))³ = 4/3.', '1 TRPL B', 'materi3'),
(22, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh kurva y = x² - 1 dan y = 2x + 2 adalah...', '32/3 satuan luas', '64/3 satuan luas', '8/3 satuan luas', '4/3 satuan luas', 'A', 'Titik potong: x = -1 dan x = 3.\r\nFungsi selisih: (2x + 2) - (x² - 1) = -x² + 2x + 3 (a=-1).\r\nRumus Luas: |a/6| (x₂ - x₁ )³.\r\nLuas = |-1/6| (3 - (-1))³ = 32/3.', '1 TRPL B', 'materi3'),
(23, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x² dan y = 2x diputar mengelilingi sumbu-y adalah...', '8π/3 satuan volume', '4π/3 satuan volume', '16π/3 satuan volume', '32π/3 satuan volume', 'A', 'Titik potong: x² = 2x → x = 0 dan x = 2.\r\nUbah ke x=f(y): Untuk y = x², x = √y (kuadran I). Untuk y = 2x, x = y/2.\r\nBatas y: Jika x=2, y=4. Jadi batas y dari 0 sampai 4.\r\nRumus Volume (Metode Cincin): V = π ∫cd [ (R(y))² - (r(y))² ] dy. (R(y) = √y, r(y) = y/2)\r\nIntegral: V = π ∫₀⁴ ( (√y)² - (y/2)² ) dy = π ∫₀⁴ (y - y²/4) dy.\r\nHitung: π [ (1/2)y² - (1/12)y³ ]₀⁴ = π [ (1/2)(4)² - (1/12)(4)³ ] - 0 = π [ 8 - 64/12 ] = π [ 8 - 16/3 ] = π [ 24/3 - 16/3 ] = 8π/3.', '1 TRPL B', 'materi4'),
(24, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh x = √y, sumbu-y, garis y = 1, dan y = 4 diputar mengelilingi sumbu-y adalah...', '17π/2 satuan volume', '5π/2 satuan volume', '13π/2 satuan volume', '15π/2 satuan volume', 'D', 'Rumus Volume (Metode Cakram): V = π ∫cd [g(y)]² dy.\r\nFungsi dan Batas: g(y) = √y, c=1, d=4.\r\nIntegral: V = π ∫₁⁴ (√y)² dy = π ∫₁⁴ y dy.\r\nHitung: π [ (1/2)y² ]₁⁴ = π [ (1/2)(4)² - (1/2)(1)² ] = π [ 8 - 1/2 ] = π [ 16/2 - 1/2 ] = 15π/2.', '1 TRPL B', 'materi4'),
(25, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x² + 1, sumbu-x, garis x = 0, dan x = 1 diputar mengelilingi sumbu-x adalah...', '16π/15 satuan volume', '28π/15 satuan volume', '34π/15 satuan volume', '46π/15 satuan volume', 'B', 'Rumus Volume (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi dan Batas: f(x) = x² + 1, a=0, b=1.\r\nIntegral: V = π ∫₀¹ (x² + 1)² dx = π ∫₀¹ (x⁴ + 2x² + 1) dx.\r\nHitung: π [ (1/5)x⁵ + (2/3)x³ + x ]₀¹ = π [ (1/5)(1)⁵ + (2/3)(1)³ + 1 ] - 0 = π [ 1/5 + 2/3 + 1 ] = π [ 3/15 + 10/15 + 15/15 ] = 28π/15.', '1 TRPL B', 'materi4'),
(26, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x dan y = x³ diputar mengelilingi sumbu-x adalah...', '2π/21 satuan volume', '4π/21 satuan volume', '8π/21 satuan volume', 'π/21 satuan volume', 'B', 'Titik potong: x = x³ → x³ - x = 0 → x(x² - 1) = 0 → x = -1, x = 0, x = 1.\r\nUntuk x dari 0 sampai 1, y=x di atas y=x³. Integral dari 0 sampai 1.\r\nRumus Volume (Metode Cincin): V = π ∫ab [ (R(x))² - (r(x))² ] dx. (R(x) = x, r(x) = x³)\r\nIntegral: V = π ∫₀¹ ( x² - (x³)² ) dx = π ∫₀¹ (x² - x⁶) dx.\r\nHitung: π [ (1/3)x³ - (1/7)x⁷ ]₀¹ = π [ (1/3)(1)³ - (1/7)(1)⁷ ] - 0 = π [ 1/3 - 1/7 ] = π [ 7/21 - 3/21 ] = 4π/21.', '1 TRPL B', 'materi4'),
(27, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = 4 - x², sumbu-x, diputar mengelilingi sumbu-x adalah...', '128π/15 satuan volume', '64π/15 satuan volume', '32π/15 satuan volume', '16π/15 satuan volume', 'C', 'Batas: y = 0 → 4 - x² = 0 → x = -2 dan x = 2.\r\nRumus Volume (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nIntegral: V = π ∫₋₂² (4 - x²)² dx = π ∫₋₂² (16 - 8x² + x⁴) dx.\r\nHitung: π [ 16x - (8/3)x³ + (1/5)x⁵ ]₋₂² = π [ (32 - 64/3 + 32/5) - (-32 + 64/3 - 32/5) ]\r\n= 2π [ 16 - 64/3 + 32/5 ] = 2π [ (240 - 320 + 96)/15 ] = 2π [ 16/15 ] = 32π/15.', '1 TRPL B', 'materi4'),
(28, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x² dan y = x diputar mengelilingi sumbu-y adalah...', 'π/30 satuan volume', 'π/6 satuan volume', '2π/15 satuan volume', '4π/15 satuan volume', 'B', 'Titik potong: x² = x → x = 0 dan x = 1.\r\nUbah ke x=f(y): Untuk y = x², x = √y. Untuk y = x, x = y.\r\nBatas y: Jika x=1, y=1. Jadi batas y dari 0 sampai 1.\r\nRumus (Metode Cincin): V = π ∫cd [ (R(y))² - (r(y))² ] dy. (R(y) = √y, r(y) = y)\r\nIntegral: V = π ∫₀¹ ( (√y)² - y² ) dy = π ∫₀¹ (y - y²) dy.\r\nHitung: π [ (1/2)y² - (1/3)y³ ]₀¹ = π [ (1/2)(1)² - (1/3)(1)³ ] - 0 = π [ 1/2 - 1/3 ] = π [ 3/6 - 2/6 ] = π/6.', '1 TRPL B', 'materi5'),
(29, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = sin x, sumbu-x, dari x = 0 sampai x = π diputar mengelilingi sumbu-x adalah...', 'π²/2 satuan volume', 'π²/3 satuan volume', 'π²/4 satuan volume', 'π²/6 satuan volume', 'A', 'Rumus (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi & Batas: f(x) = sin x, a=0, b=π.\r\nIntegral: V = π ∫₀^π sin² x dx. Gunakan identitas sin² x = (1 - cos(2x))/2.\r\nV = π ∫₀^π (1 - cos(2x))/2 dx = (π/2) [ x - (1/2)sin(2x) ]₀^π.\r\nHitung: (π/2) [ (π - (1/2)sin(2π)) - (0 - (1/2)sin(0)) ] = (π/2) [ (π - 0) - 0 ] = π²/2.', '1 TRPL B', 'materi5'),
(30, 'Volume Benda Putar', 'Volume benda putar jika daerah yang dibatasi oleh x = y², x = 4 diputar mengelilingi sumbu-y adalah...', '128π/5 satuan volume', '256π/5 satuan volume', '512π/5 satuan volume', '64π/5 satuan volume', 'B', 'Titik potong: y² = 4 → y = -2 dan y = 2.\r\nRumus (Metode Cincin): V = π ∫cd [ (R(y))² - (r(y))² ] dy. (R(y) = 4, r(y) = y²)\r\nIntegral: V = π ∫₋₂² ( 4² - (y²)² ) dy = π ∫₋₂² (16 - y⁴) dy.\r\nHitung: π [ 16y - (1/5)y⁵ ]₋₂² = π [ (16(2) - (1/5)(2)⁵) - (16(-2) - (1/5)(-2)⁵) ]\r\n= π [ (32 - 32/5) - (-32 + 32/5) ] = π [ 32 - 32/5 + 32 - 32/5 ] = π [ 64 - 64/5 ] = π [ 320/5 - 64/5 ] = 256π/5.', '1 TRPL B', 'materi5'),
(31, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x² dan sumbu-x dari x = 0 sampai x = 1 diputar mengelilingi sumbu-y adalah...', 'π/2 satuan volume', 'π/4 satuan volume', 'π/3 satuan volume', 'π/6 satuan volume', 'A', 'Metode Kulit Tabung: V = ∫ab 2πx h(x) dx.\r\nFungsi & Batas: h(x) = x², a=0, b=1.\r\nIntegral: V = ∫₀¹ 2πx (x²) dx = 2π ∫₀¹ x³ dx.\r\nHitung: 2π [ (1/4)x⁴ ]₀¹ = 2π [ (1/4)(1)⁴ - 0 ] = 2π(1/4) = π/2.', '1 TRPL B', 'materi5'),
(32, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x, sumbu-y, garis y = 1, dan y = 3 diputar mengelilingi sumbu-y adalah...', '8π/3 satuan volume', '26π/3 satuan volume', '13π/3 satuan volume', '4π/3 satuan volume', 'B', 'Rumus (Metode Cakram): V = π ∫cd [g(y)]² dy.\r\nFungsi & Batas: g(y) = y, c=1, d=3.\r\nIntegral: V = π ∫₁³ y² dy.\r\nHitung: π [ (1/3)y³ ]₁³ = π [ (1/3)(3)³ - (1/3)(1)³ ] = π [ 9 - 1/3 ] = π [ 27/3 - 1/3 ] = 26π/3.', '1 TRPL B', 'materi5'),
(33, 'Panjang Busur Dengan Integral', 'Tentukan panjang busur dari kurva x = (2/3)(y+1)^(3/2) dari y = 0 sampai y = 2.', '(10√3 - 2)/3 satuan panjang', '(16 - 4√2)/3 satuan panjang', '(16√3 - 2)/3 satuan panjang', '(10√10 - 2√2)/3 satuan panjang', 'B', 'Turunan: dx/dy = √(y+1).\r\n√(1 + (dx/dy)²): √(1 + y + 1) = √(y + 2).\r\nPanjang Busur: L = ∫₀² √(y + 2) dy.\r\nHitung: [ (2/3)(y + 2)^(3/2) ]₀² = (2/3)(4)^(3/2) - (2/3)(2)^(3/2) = 16/3 - 4√2/3 = (16 - 4√2)/3.', '1 TRPL B', 'materi6'),
(34, 'Panjang Busur Dengan Integral', 'Panjang busur kurva y = ln(cos x) dari x = 0 sampai x = π/4 adalah...', 'ln(√2 - 1) satuan panjang', 'ln(√2 + 1) satuan panjang', '√2 - 1 satuan panjang', '√2 + 1 satuan panjang', 'B', 'Turunan: dy/dx = -tan x.\r\n√(1 + (dy/dx)²): √(1 + tan² x) = √sec² x = sec x (karena di kuadran I).\r\nPanjang Busur: L = ∫₀^(π/4) sec x dx.\r\nHitung: [ ln|sec x + tan x| ]₀^(π/4) = ln|√2 + 1| - ln|1 + 0| = ln(√2 + 1).', '1 TRPL B', 'materi6'),
(35, 'Panjang Busur Dengan Integral', 'Panjang busur kurva y = (eˣ + e⁻ˣ)/2 (cosh x) dari x = 0 sampai x = 1 adalah...', 'e + 1/e)/2 - 1 satuan panjang', '(e - 1/e)/2 satuan panjang', 'e + 1/e)/ - 1 satuan panjang', '(e - 1/e)/2 + 1 satuan panjang', 'B', 'Fungsi: y = cosh x.\r\nTurunan: dy/dx = sinh x.\r\n√(1 + (dy/dx)²): √(1 + sinh² x) = √cosh² x = cosh x.\r\nPanjang Busur: L = ∫₀¹ cosh x dx.\r\nHitung: [ sinh x ]₀¹ = (e¹ - e⁻¹)/2 - (e⁰ - e⁰)/2 = (e - 1/e)/2.', '1 TRPL B', 'materi6'),
(36, 'Panjang Busur Dengan Integral', 'Tentukan panjang busur dari kurva y = (x² + 2)^(3/2) / 3 dari x = 0 sampai x = 2.', '14/3 satuan panjang', '22/3 satuan panjang', '20/3 satuan panjang', '18/3 satuan panjang', 'A', 'Turunan: dy/dx = x(x² + 2)^(1/2).\r\n√(1 + (dy/dx)²): √(1 + x⁴ + 2x²) = x² + 1.\r\nPanjang Busur: L = ∫₀² (x² + 1) dx.\r\nHitung: [ (1/3)x³ + x ]₀² = (8/3 + 2) = 14/3.', '1 TRPL B', 'materi6'),
(37, 'Panjang Busur Dengan Integral', 'Panjang busur kurva y = x²/2 dari x = 0 sampai x = √3 adalah...', '√3 + (1/2)ln(√3+2) satuan panjang', '(√3)/2 + ln(√3+2) satuan panjang', '(√3)/2 + (1/2)ln(√3+2) satuan panjang', '√3 + ln(√3+2) satuan panjang', 'A', 'Turunan: dy/dx = x.\r\n√(1 + (dy/dx)²): √(1 + x²).\r\nPanjang Busur: L = ∫₀^√3 √(1 + x²) dx.\r\nHitung: Gunakan rumus integral √(a²+x²) = (x/2)√(a²+x²) + (a²/2)ln|x + √(a²+x²)|.\r\n[ (x/2)√(1+x²) + (1/2)ln|x + √(1+x²)| ]₀^√3 = √3 + (1/2)ln(√3 + 2).', '1 TRPL B', 'materi6');

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `id_level` int(11) NOT NULL,
  `nama_level` varchar(100) NOT NULL,
  `urutan` int(11) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`id_level`, `nama_level`, `urutan`, `deskripsi`) VALUES
(1, 'Integral fungsi sederhana', 1, 'Mengenal bentuk dasar integral'),
(2, 'Integral fungsi pangkat', 2, 'Latihan integral fungsi berpangkat'),
(3, 'Integral fungsi trigonometri', 3, 'Integral sin, cos, dll'),
(4, 'Integral tentu', 4, 'Menggunakan batas bawah & atas'),
(5, 'Luas daerah', 5, 'Menghitung luas dengan integral'),
(6, 'Luas daerah dengan rumus', 6, 'Menghitung luas dengan rumus D = b² - 4ac, '),
(7, 'Volume benda dalam ruang', 7, 'Menghitung volume dengan rumus bangun ruang'),
(8, 'Volume benda putar dengan integral', 8, 'Menghitung volume dengan metode cakram/tabung');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `idmhs` int(11) NOT NULL,
  `namamhs` varchar(50) NOT NULL,
  `npm` int(11) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `tugas` varchar(50) NOT NULL,
  `nilai` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE `nilai` (
  `id` int(11) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `materi` varchar(50) NOT NULL,
  `jenis` varchar(10) NOT NULL,
  `skor` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`id`, `kelas`, `nama`, `materi`, `jenis`, `skor`, `tanggal`) VALUES
(24, '1 TRPL B', 'agus', 'materi1', 'latihan', 0, '2025-07-01 22:25:33');

-- --------------------------------------------------------

--
-- Table structure for table `quizsoal`
--

CREATE TABLE `quizsoal` (
  `id` int(11) NOT NULL,
  `judul_quiz` varchar(255) DEFAULT NULL,
  `soal` text DEFAULT NULL,
  `opsi_a` text DEFAULT NULL,
  `opsi_b` text DEFAULT NULL,
  `opsi_c` text DEFAULT NULL,
  `opsi_d` text DEFAULT NULL,
  `opsijawaban` varchar(255) NOT NULL,
  `jawaban` text DEFAULT NULL,
  `kelas` varchar(100) DEFAULT NULL,
  `materi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quizsoal`
--

INSERT INTO `quizsoal` (`id`, `judul_quiz`, `soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsijawaban`, `jawaban`, `kelas`, `materi`) VALUES
(34, 'Integral Tak Tentu', 'Hitung integral dari fungsi berikut ini. \r\n∫ 4x dx', '2x² + C', '4x² + C', 'x² + C', '8x + C', 'A', 'Gunakan aturan integral \r\n∫ ax dx = (a/2) x² + C, maka\r\n\r\n∫ 4x dx = (4/2) x² + C =  2x² + C', '1 TRPL A', 'materi1'),
(35, 'Integral Tak Tentu', 'Hitung integral dari fungsi berikut ini. ∫ 4x dx', '2x² + C', '4x² + C', 'x² + C', '8x + C', 'A', 'Gunakan aturan integral \r\n∫ ax dx = (a/2) x² + C, maka\r\n\r\n∫ 4x dx = (4/2) x² + C =  2x² + C', '1 TRPL B', 'materi1'),
(36, 'Integral Tak Tentu', 'Tentukan hasil dari: \r\n∫ ( 3x² + 2x -5) dx', 'x³ + x² - 5x + C', 'x³ + x² + 5x + C', 'x³ - x² + 5x + C', 'x³ + 2x² + 5x + C', 'A', 'Integral dilakukan per suku:\r\n∫ 3x² = x³ , ∫ 2x = x² , ∫ -5 = -5x,\r\ngabungkan:\r\nx³ + x² - 5x + C', '1 TRPL A', 'materi1'),
(37, 'Integral Tak Tentu', 'Tentukan hasil dari: ∫ ( 3x² + 2x -5) dx', 'x³ + x² - 5x + C', 'x³ + x² + 5x + C', 'x³ - x² + 5x + C', 'x³ + 2x² + 5x + C', 'A', 'Integral dilakukan per suku: \r\n∫ 3x² = x³ , ∫ 2x = x² , ∫ -5 = -5x, \r\n\r\ngabungkan: \r\nx³ + x² - 5x + C', '1 TRPL B', 'materi1'),
(38, 'Menghitung Luas Daerah', 'Diberikan dua fungsi f(x) = x dan g(x) = x². Jika f(x) ≥ g(x), maka bentuk fungsi yang menggambarkan luas daerah antara keduanya adalah..', 'f(x) + g(x)', 'f(x) - g(x)', 'g(x) - f(x)', 'f(x) . g(x)', 'B', 'Luas antara dua kurva diberikan oleh Luas = f(x) - g(x) \r\nJika f(x)≥g(x), maka bentuk fungsi yang menggambarkan luas adalah f(x) - g(x)', '1 TRPL A', 'materi2'),
(39, 'Menghitung Luas Daerah', 'Diberikan dua fungsi f(x) = x dan g(x) = x². Jika f(x) ≥ g(x), maka bentuk fungsi yang menggambarkan luas daerah antara keduanya adalah..', 'f(x) + g(x)', 'f(x) - g(x)', 'g(x)-f(x)', 'f(x) . g(x)', 'B', 'Luas antara dua kurva diberikan oleh Luas = f(x) - g(x) Jika f(x)≥g(x), maka bentuk fungsi yang menggambarkan luas adalah f(x) - g(x)', '1 TRPL B', 'materi2'),
(40, 'Menghitung Luas Daerah', 'Dua fungsi f(x) = 2x dan g(x) = x² memiliki selisih nilai fungsinya h(x) = 2x - x². Luas antara kedua kurva dapat dicari dengan..', 'Menurunkan fungsi h(x)', 'Mengintegralkan fungsi h(x)', 'Menjumlahkan fungsi f(x) dan g(x)', 'Mengalikan fungsi f(x) dan g(x)', 'B', 'Untuk menghitung luas daerah antara dua kurva, kita kurangkan kedua fungsi, lalu integralkan hasilnya. Jadi:\r\n\r\nLuas = ∫(f(x) − g(x)) dx=∫ h(x) dx', '1 TRPL A', 'materi2'),
(41, 'Menghitung Luas Daerah', 'Diberikan dua fungsi f(x) = x dan g(x) = x². Jika f(x) ≥ g(x), maka bentuk fungsi yang menggambarkan luas daerah antara keduanya adalah..', 'Menurunkan fungsi h(x)', 'Mengintegralkan fungsi h(x)', 'Menjumlahkan fungsi f(x) dan g(x)', 'Mengalikan fungsi f(x) dan g(x)', 'B', 'Luas antara dua kurva diberikan oleh Luas = f(x) - g(x) Jika f(x)≥g(x), maka bentuk fungsi yang menggambarkan luas adalah f(x) - g(x)', '1 TRPL B', 'materi2'),
(42, 'Menghitung luas daerah dengan rumus', 'Diketahui persamaan kuadrat y = x² - 4x + 4. Nilai diskriminannya adalah...', '0', '4', '8', '16', 'A', 'Rumus diskriminan: D = b² - 4ac\r\n\r\nDengan a= 1, b = -4, c = 4, \r\nmaka:\r\nD = (-4)² - 4(1)(4) = 16 - 16 = 0\r\n\r\nDiskriminan nol berarti grafik bersinggungan dengan sumbu x (akar kembar).', '1 TRPL A', 'materi3'),
(43, 'Menghitung luas daerah dengan rumus', 'Diketahui persamaan kuadrat y = x² - 4x + 4. Nilai diskriminannya adalah...', '0', '4', '8', '16', 'A', 'Rumus diskriminan: D = b² - 4ac \r\n\r\nDengan a= 1, b = -4, c = 4, \r\nmaka: \r\nD = (-4)² - 4(1)(4) = 16 - 16 = 0 \r\n\r\nDiskriminan nol berarti grafik bersinggungan dengan sumbu x (akar kembar).', '1 TRPL B', 'materi3'),
(44, 'Menghitung luas daerah dengan rumus', 'Jika sebuah persamaan kuadrat memiliki nilai diskriminan lebih kecil dari 0, maka grafik parabola...', 'Memotong sumbu x di dua titik', 'Tidak memotong sumbu x sama sekali', 'Bersinggungan dengan sumbu x', 'Selalu berada di atas sumbu x', 'B', 'Diskriminan < 0 artinya akar-akar persamaan tidak real (imajiner), sehingga grafik tidak memotong sumbu x.', '1 TRPL A', 'materi3'),
(45, 'Menghitung luas daerah dengan rumus', 'Jika sebuah persamaan kuadrat memiliki nilai diskriminan lebih kecil dari 0, maka grafik parabola...', 'Memotong sumbu x di dua titik', 'Tidak memotong sumbu x sama sekali', 'Bersinggungan dengan sumbu x', 'Selalu berada di atas sumbu x', 'B', 'Diskriminan < 0 artinya akar-akar persamaan tidak real (imajiner), sehingga grafik tidak memotong sumbu x.', '1 TRPL B', 'materi3'),
(46, 'Volume Benda dalam Ruang', 'Volume benda putar yang terbentuk jika daerah yang dibatasi oleh y = 2, sumbu-x, sumbu-y, dan garis x = 3 diputar mengelilingi sumbu-x adalah...', '4π satuan volume', '6π satuan volume', '9π satuan volume', '12π satuan volume', 'D', 'Benda yang terbentuk adalah tabung.\r\nVolume = phi * integral dari 0 sampai 3 dari (2)^2 dx\r\nVolume = phi * integral dari 0 sampai 3 dari 4 dx\r\nVolume = phi * [4x] dari 0 sampai 3\r\nVolume = phi * (4 * 3 - 4 * 0)\r\nVolume = 12 phi satuan volume.', '1 TRPL A', 'materi4'),
(47, 'Volume Benda dalam Ruang', 'Volume benda putar yang terbentuk jika daerah yang dibatasi oleh y = 2, sumbu-x, sumbu-y, dan garis x = 3 diputar mengelilingi sumbu-x adalah...', '4π satuan volume', '6π satuan volume', '9π satuan volume', '12π satuan volume', 'D', 'Benda yang terbentuk adalah tabung.\r\nVolume = phi * integral dari 0 sampai 3 dari (2)^2 dx\r\nVolume = phi * integral dari 0 sampai 3 dari 4 dx\r\nVolume = phi * [4x] dari 0 sampai 3\r\nVolume = phi * (4 * 3 - 4 * 0)\r\nVolume = 12 phi satuan volume.', '1 TRPL B', 'materi4'),
(48, 'Volume Benda Putar', 'Tentukan volume benda putar jika daerah yang dibatasi oleh x = 1, sumbu-x, sumbu-y, dan garis y = 2 diputar mengelilingi sumbu-y.', 'π satuan volume', '3π satuan volume', '2π satuan volume', '12π satuan volume', 'C', 'Benda yang terbentuk adalah tabung.\r\nVolume = phi * integral dari 0 sampai 2 dari (1)^2 dy\r\nVolume = phi * integral dari 0 sampai 2 dari 1 dy\r\nVolume = phi * [y] dari 0 sampai 2\r\nVolume = phi * (2 - 0)\r\nVolume = 2 phi satuan volume.', '1 TRPL A', 'materi5'),
(49, 'Panjang Busur dengan Integral', 'Tentukan panjang busur kurva y = 3x dari x = 0 sampai x = 1.', '2 * akar(10) satuan panjang', '3 * akar(10) satuan panjang', 'akar(10) satuan panjang', '5 * akar(10) satuan panjang', 'C', 'Cari dy/dx:\r\ny = 3x\r\ndy/dx = 3\r\n\r\nCari akar(1 + (dy/dx)^2):\r\nakar(1 + 3^2) = akar(1 + 9) = akar(10)\r\n\r\nIntegralkan:\r\nPanjang busur = integral dari 0 sampai 1 dari akar(10) dx\r\nPanjang busur = [akar(10) * x] dari 0 sampai 1\r\nPanjang busur = akar(10) * 1 - akar(10) * 0', '1 TRPL A', 'materi6'),
(50, 'Dasar Integral', 'Hasil dari ∫ (6x⁵ - 4x³ + 7x) dx adalah...', 'x⁶ - x⁴ + (7/2)x² + C', '30x⁴ - 12x² + 7 + C', 'x⁶ - 4x⁴ + 7x² + C', '6x⁶ - 4x⁴ + 7x² + C', 'A', 'Integral xⁿ: Tambah pangkat 1, bagi dengan pangkat baru.\r\n∫ 6x⁵ dx = x⁶\r\n∫ -4x³ dx = -x⁴\r\n∫ 7x dx = (7/2)x²\r\nGabungkan dan tambah C.', '1 TRPL B', 'materi1'),
(51, 'Dasar Integral', 'Jika f(x) = 5x - 4, maka ∫ f(x) dx adalah...', '5 + C', '(5/2)x² - 4x + C', '5x² - 4x + C', '(1/2)x² - 4x + C', 'B', '∫ 5x dx = (5/2)x²\r\n∫ -4 dx = -4x\r\nGabungkan dan tambah C.', '1 TRPL B', 'materi1'),
(52, 'Dasar Integral', 'Tentukan hasil dari ∫ (4x + 1)² dx.', '(1/3)(4x+1)³ + C', '(1/12)(4x+1)³ + C', '(1/48)(4x+1)³ + C', '(4x+1)³ + C', 'B', 'Gunakan aturan rantai terbalik: ∫ (ax+b)ⁿ dx = (1/a) * (1/(n+1)) * (ax+b)ⁿ⁺¹ + C.\r\nDi sini a=4, n=2. Jadi (1/4) * (1/3) * (4x+1)³ = (1/12)(4x+1)³.', '1 TRPL B', 'materi1'),
(53, 'Dasar Integral', 'Nilai dari ∫₀² (x³ - x) dx adalah...', '0', '2', '-2', '4', 'B', '1.	Integral tak tentu: (1/4)x⁴ - (1/2)x².\r\n2.	Hitung batas:\r\n	(1/4)(2)⁴ - (1/2)(2)² = (1/4)(16) - (1/2)(4) = 4 - 2 = 2.\r\n	(1/4)(0)⁴ - (1/2)(0)² = 0.\r\n3.	Kurangkan: 2 - 0 = 2.', '1 TRPL B', 'materi1'),
(54, 'Dasar Integral', 'Hasil dari ∫ (cos x + 1/x) dx adalah...', '-sin x + ln|x| + C', 'sin x + ln|x| + C', 'cos x + ln|x| + C', 'sin x - 1/x² + C', 'B', 'Integral dari cos x adalah sin x.\r\nIntegral dari 1/x adalah ln|x|.\r\nGabungkan dan tambah C.', '1 TRPL B', 'materi1'),
(55, 'Dasar Integral', 'Diketahui F(x) adalah antiturunan dari f(x) = 3x² - 6x. Jika F(1) = 2, maka F(x) adalah...', 'x³ - 3x² + 2', 'x³ - 3x² + 4', 'x³ - 3x² + 6', '6x - 6 + 2', 'B', 'Integralkan f(x): F(x) = x³ - 3x² + C.\r\nCari C dengan F(1)=2:\r\n2 = (1)³ - 3(1)² + C\r\n2 = 1 - 3 + C\r\n2 = -2 + C, jadi C = 4.\r\nHasil: F(x) = x³ - 3x² + 4.', '1 TRPL B', 'materi1'),
(56, 'Dasar Integral', 'Jika ∫₀⁵ f(x) dx = 12 dan ∫₀² f(x) dx = 7, maka ∫₂⁵ f(x) dx adalah...', '5', '19', '-5', '84', 'A', 'Gunakan sifat integral: ∫₀⁵ = ∫₀² + ∫₂⁵.\r\n12 = 7 + ∫₂⁵ f(x) dx.\r\nJadi, ∫₂⁵ f(x) dx = 12 - 7 = 5.', '1 TRPL B', 'materi1'),
(57, 'Dasar Integral', 'Tentukan hasil dari ∫ (1/x³) dx.', '-1/(2x²) + C', '1/(2x²) + C', '-3/x⁴ + C', '-2/x² + C', 'A', 'Ubah 1/x³ menjadi x⁻³.\r\nIntegralkan x⁻³: x^(-3+1) / (-3+1) = x⁻² / -2 = -1/(2x²).\r\nTambah C.', '1 TRPL B', 'materi1'),
(58, 'Dasar Integral', 'Nilai dari ∫₀² (3x² + 4x) dx adalah...', '8', '12', '16', '20', 'C', 'Integral tak tentu: x³ + 2x².\r\nHitung batas:\r\n(2)³ + 2(2)² = 8 + 2(4) = 8 + 8 = 16.\r\n(0)³ + 2(0)² = 0.\r\nKurangkan: 16 - 0 = 16.', '1 TRPL B', 'materi1'),
(59, 'Dasar Integral', 'Hasil dari ∫ (x⁴ - x + 1/x²) dx adalah...', '(1/5)x⁵ - (1/2)x² - 1/x + C', '4x³ - 1 - 2/x³ + C', '(1/5)x⁵ - x² + 1/x + C', '(1/5)x⁵ - (1/2)x² + 1/x + C', 'A', '∫ x⁴ dx = (1/5)x⁵\r\n∫ -x dx = -(1/2)x²\r\nUbah 1/x² menjadi x⁻². Integral x⁻² adalah -x⁻¹ = -1/x.\r\nGabungkan dan tambah C.', '1 TRPL B', 'materi1'),
(60, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh kurva y = x² + 2, sumbu-x, garis x = 0, dan x = 1 adalah...', '5/3 satuan luas', '7/3 satuan luas', '8/3 satuan luas', '4/3 satuan luas', 'B', 'Integral tak tentu: ∫ (x² + 2) dx = (1/3)x³ + 2x.\r\nHitung: ( (1/3)(1)³ + 2(1) ) - ( (1/3)(0)³ + 2(0) ) = (1/3 + 2) - 0 = 1/3 + 6/3 = 7/3.', '1 TRPL B', 'materi2'),
(61, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh y = 3x - 1, sumbu-x, garis x = 1, dan x = 2 adalah...', '7/2 satuan luas', '3/2 satuan luas', '5/2 satuan luas', '9/2 satuan luas', 'A', 'Integral tak tentu: ∫ (3x - 1) dx = (3/2)x² - x.\r\nHitung: ( (3/2)(2)² - 2 ) - ( (3/2)(1)² - 1 ) = (6 - 2) - (3/2 - 1) = 4 - (1/2) = 8/2 - 1/2 = 7/2.', '1 TRPL B', 'materi2'),
(62, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh kurva y = 1 - x², sumbu-x, garis x = 0, dan x = 2 adalah...', '2/3 satuan luas', '2 satuan luas', '6/3 satuan luas', '8/3 satuan luas', 'B', 'Kurva memotong sumbu-x di x = 1 dan x = -1.\r\nInterval [0, 1] di atas sumbu-x, interval [1, 2] di bawah sumbu-x. Jumlahkan nilai mutlak integralnya.\r\nIntegral tak tentu: x - (1/3)x³.\r\nHitung: ∫₀¹ (1 - x²) dx + |∫₁² (1 - x²) dx|\r\n= [ (1 - 1/3) - 0 ] + | [ (2 - 8/3) - (1 - 1/3) ] |\r\n= [2/3] + | [-2/3 - 2/3] | = 2/3 + |-4/3| = 2/3 + 4/3 = 6/3 = 2.', '1 TRPL B', 'materi2'),
(63, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh y = x² dan y = 2x adalah...', '1 satuan luas', '2/3 satuan luas', '1/3 satuan luas', '4/3 satuan luas', 'D', 'Titik potong: x² = 2x → x² - 2x = 0 → x(x - 2) = 0. Jadi, x = 0 dan x = 2.\r\nIntegral: ∫₀² (kurva atas - kurva bawah) dx = ∫₀² (2x - x²) dx.\r\nHitung: [ x² - (1/3)x³ ]₀² = ( (2)² - (1/3)(2)³ ) - 0 = 4 - 8/3 = 12/3 - 8/3 = 4/3.', '1 TRPL B', 'materi2'),
(64, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh kurva y = x² - x dan garis y = 2x adalah...', '6/2 satuan luas', '7/2 satuan luas', '9/2 satuan luas', '3/2 satuan luas', 'C', 'Titik potong: x² - x = 2x → x² - 3x = 0 → x(x - 3) = 0. Jadi, x = 0 dan x = 3.\r\nIntegral: ∫₀³ (kurva atas - kurva bawah) dx = ∫₀³ ( 2x - (x² - x) ) dx = ∫₀³ (3x - x²) dx.\r\nHitung: [ (3/2)x² - (1/3)x³ ]₀³ = ( (3/2)(3)² - (1/3)(3)³ ) - 0 = (27/2 - 9) = 27/2 - 18/2 = 9/2.', '1 TRPL B', 'materi2'),
(65, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh kurva y = -x² + 4 dan sumbu-x adalah...', '3/3 satuan luas', '16/3 satuan luas', '8/3 satuan luas', '32/3 satuan luas', 'D', 'Titik potong sumbu-x: -x² + 4 = 0 → x² = 4 → x = -2 dan x = 2.\r\nKurva di atas sumbu-x pada interval tersebut.\r\nIntegral: ∫₋₂² (-x² + 4) dx.\r\nHitung: [ -(1/3)x³ + 4x ]₋₂² = ( -(1/3)(2)³ + 4(2) ) - ( -(1/3)(-2)³ + 4(-2) ) = (-8/3 + 8) - (8/3 - 8) = (16/3) - (-16/3) = 32/3.', '1 TRPL B', 'materi2'),
(66, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh kurva x = y³ dan sumbu-y dari y = 0 sampai y = 1 adalah...', '1 satuan luas', '1/2 satuan luas', '1/4 satuan luas', '1/2 satuan luas', 'C', 'Integralkan terhadap y. Batas y dari 0 sampai 1.\r\nIntegral tak tentu: ∫ y³ dy = (1/4)y⁴.\r\nHitung: [ (1/4)y⁴ ]₀¹ = (1/4)(1)⁴ - (1/4)(0)⁴ = 1/4 - 0 = 1/4.', '1 TRPL B', 'materi2'),
(67, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh y = 6, sumbu-x, garis x = -1, dan x = 2 adalah...', '12 satuan luas', '18 satuan luas', '6 satuan luas', '9 satuan luas', 'B', 'Ini adalah persegi panjang. Lebar = 2 - (-1) = 3. Tinggi = 6.\r\nIntegral tak tentu: ∫ 6 dx = 6x.\r\nHitung: [ 6x ]₋₁² = 6(2) - 6(-1) = 12 - (-6) = 18.', '1 TRPL B', 'materi2'),
(68, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh y = x² - 4 dan sumbu-x dari x = -1 sampai x = 1 adalah...', '10/3 satuan luas', '16/3 satuan luas', '22/3 satuan luas', '4/3 satuan luas', 'C', 'Kurva y = x² - 4 selalu di bawah sumbu-x pada interval [-1, 1]. Ambil nilai mutlak.\r\nIntegral tak tentu: (1/3)x³ - 4x.\r\nHitung: | [ (1/3)x³ - 4x ]₋₁¹ | = | ( (1/3)(1)³ - 4(1) ) - ( (1/3)(-1)³ - 4(-1) ) |\r\n= | (1/3 - 4) - (-1/3 + 4) | = | (-11/3) - (11/3) | = |-22/3| = 22/3.', '1 TRPL B', 'materi2'),
(69, 'Menghitung Luas Daerah', 'Luas daerah yang dibatasi oleh y = -x² + 5x dan sumbu-x adalah...', '125/3 satuan luas', '50/3 satuan luas', '25/6 satuan luas', '125/6 satuan luas', 'D', 'Titik potong sumbu-x: -x² + 5x = 0 → x(-x + 5) = 0. Jadi, x = 0 dan x = 5.\r\nKurva di atas sumbu-x pada interval tersebut.\r\nIntegral tak tentu: -(1/3)x³ + (5/2)x².\r\nHitung: [ -(1/3)x³ + (5/2)x² ]₀⁵ = ( -(1/3)(5)³ + (5/2)(5)² ) - 0 = (-125/3 + 125/2) = (-250/6 + 375/6) = 125/6.', '1 TRPL B', 'materi2'),
(70, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh kurva y = x² - 4x dan sumbu-x adalah...', '16/3 satuan luas', '32/3 satuan luas', '8/3 satuan luas', '4/3 satuan luas', 'B', 'Titik potong sumbu-x: x = 0 dan x = 4.\r\nRumus Luas: |a/6| (x₂ - x₁ )³. Di sini a=1.\r\nLuas = |1/6| (4 - 0)³ = 32/3.', '1 TRPL B', 'materi3'),
(71, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh kurva y = -x² + 9 dan sumbu-x adalah...', '36 satuan luas', '18 satuan luas', '72 satuan luas', '64 satuan luas', 'A', 'Titik potong sumbu-x: x = -3 dan x = 3.\r\nRumus Luas: |a/6| (x₂ - x₁ )³. Di sini a=-1.\r\nLuas = |-1/6| (3 - (-3))³ = 36', '1 TRPL B', 'materi3'),
(72, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh y = x² dan y = 4 adalah...', '32/3 satuan luas', '16/3 satuan luas', '8/3 satuan luas', '4/3 satuan luas', 'A', 'Titik potong: x = -2 dan x = 2.\r\nFungsi selisih: y_atas - y_bawah = 4 - x² (a=-1).\r\nRumus Luas: |a/6| (x₂ - x₁ )³.\r\nLuas = |-1/6| (2 - (-2))³ = 32/3.', '1 TRPL B', 'materi3'),
(73, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh y = x² - x dan sumbu-x adalah...', '1/3 satuan luas', '1/6 satuan luas', '2/3 satuan luas', '1/2 satuan luas', 'B', 'Titik potong sumbu-x: x = 0 dan x = 1.\r\nRumus Luas: |a/6| (x₂ - x₁ )³. Di sini a=1.\r\nLuas = |1/6| (1 - 0)³ = 1/6.', '1 TRPL B', 'materi3'),
(74, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh y = x² dan y = 2x adalah...', '2/3 satuan luas', '4/3 satuan luas', '1/3 satuan luas', '1 satuan luas', 'B', 'Titik potong: x = 0 dan x = 2.\r\nFungsi selisih: y_atas - y_bawah = 2x - x² (a=-1).\r\nRumus Luas: |a/6| (x₂ - x₁ )³.\r\nLuas = |-1/6| (2 - 0)³ = 4/3.', '1 TRPL B', 'materi3'),
(75, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh kurva y = x², sumbu-x, garis x = 0, dan x = 2 diputar mengelilingi sumbu-x adalah...', '16π/5 satuan volume', '32π/5 satuan volume', '4π/5 satuan volume', '8π/5 satuan volume', 'B', 'Rumus Volume (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi dan Batas: f(x) = x², a=0, b=2.\r\nIntegral: V = π ∫₀² (x²)² dx = π ∫₀² x⁴ dx.\r\nHitung: π [ (1/5)x⁵ ]₀² = π [ (1/5)(2)⁵ - (1/5)(0)⁵ ] = π [ 32/5 - 0 ] = 32π/5.', '1 TRPL B', 'materi4'),
(76, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh kurva y = x, sumbu-x, garis x = 0, dan x = 3 diputar mengelilingi sumbu-x adalah...', '3π satuan volume', '6π satuan volume', '9π satuan volume', '12π satuan volume', 'C', 'Rumus Volume (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi dan Batas: f(x) = x, a=0, b=3.\r\nIntegral: V = π ∫₀³ x² dx.\r\nHitung: π [ (1/3)x³ ]₀³ = π [ (1/3)(3)³ - (1/3)(0)³ ] = π [ 9 - 0 ] = 9π.', '1 TRPL B', 'materi4'),
(77, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh kurva y = √x, sumbu-x, garis x = 0, dan x = 4 diputar mengelilingi sumbu-x adalah...', '4π satuan volume', '8π satuan volume', '16π satuan volume', '2π satuan volume', 'B', 'Fungsi dan Batas: f(x) = √x, a=0, b=4.\r\nIntegral: V = π ∫₀⁴ (√x)² dx = π ∫₀⁴ x dx.\r\nHitung: π [ (1/2)x² ]₀⁴ = π [ (1/2)(4)² - (1/2)(0)² ] = π [ 8 - 0 ] = 8π.', '1 TRPL B', 'materi4'),
(78, 'Volume Benda dalam Ruang', 'Volume benda putar jika daerah yang dibatasi oleh x = y, sumbu-y, dari y = 0 sampai y = 2 diputar mengelilingi sumbu-y adalah...', '8π/3 satuan volume', '4π/3 satuan volume', '2π/3 satuan volume', '16π/3 satuan volume', 'A', 'Rumus Volume (Metode Cakram): V = π ∫cd [g(y)]² dy.\r\nFungsi dan Batas: g(y) = y, c=0, d=2.\r\nIntegral: V = π ∫₀² y² dy.\r\nHitung: π [ (1/3)y³ ]₀² = π [ (1/3)(2)³ - (1/3)(0)³ ] = π [ 8/3 - 0 ] = 8π/3.', '1 TRPL B', 'materi4'),
(79, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x² dan y = x diputar mengelilingi sumbu-x adalah...', '2π/15 satuan volume', '4π/15 satuan volume', '8π/15 satuan volume', 'π/15 satuan volume', 'A', 'Titik potong: x² = x → x = 0 dan x = 1.\r\nRumus Volume (Metode Cincin): V = π ∫ab [ (R(x))² - (r(x))² ] dx. (R(x) = x, r(x) = x²)\r\nIntegral: V = π ∫₀¹ (x² - (x²)²) dx = π ∫₀¹ (x² - x⁴) dx.\r\nHitung: π [ (1/3)x³ - (1/5)x⁵ ]₀¹ = π [ (1/3)(1)³ - (1/5)(1)⁵ ] - 0 = π [ 1/3 - 1/5 ] = π [ 5/15 - 3/15 ] = 2π/15.', '1 TRPL B', 'materi4'),
(80, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh kurva y = x + 1, sumbu-x, garis x = 0, dan x = 2 diputar mengelilingi sumbu-x adalah...', '14π/3 satuan volume', '26π/3 satuan volume', '8π/3 satuan volume', '10π/3 satuan volume', 'B', 'Rumus (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi & Batas: f(x) = x + 1, a=0, b=2.\r\nIntegral: V = π ∫₀² (x + 1)² dx = π ∫₀² (x² + 2x + 1) dx.\r\nHitung: π [ (1/3)x³ + x² + x ]₀² = π [ (1/3)(2)³ + (2)² + 2 ] - 0 = π [ 8/3 + 4 + 2 ] = π [ 8/3 + 18/3 ] = 26π/3.', '1 TRPL B', 'materi5'),
(81, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh kurva y = 3x, sumbu-x, garis x = 0, dan x = 1 diputar mengelilingi sumbu-x adalah...', 'π satuan volume', '3π satuan volume', '9π satuan volume', '6π satuan volume', 'B', 'Rumus (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi & Batas: f(x) = 3x, a=0, b=1.\r\nIntegral: V = π ∫₀¹ (3x)² dx = π ∫₀¹ 9x² dx.\r\nHitung: π [ 3x³ ]₀¹ = π [ 3(1)³ - 0 ] = 3π.', '1 TRPL B', 'materi5'),
(82, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh kurva y = √(x+1), sumbu-x, garis x = 0, dan x = 3 diputar mengelilingi sumbu-x adalah...', '4π satuan volume', '2π satuan volume', '8π satuan volume', '15π/2 satuan volume', 'D', 'Rumus (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi & Batas: f(x) = √(x+1), a=0, b=3.\r\nIntegral: V = π ∫₀³ (√(x+1))² dx = π ∫₀³ (x + 1) dx.\r\nHitung: π [ (1/2)x² + x ]₀³ = π [ (1/2)(3)² + 3 ] - 0 = π [ 9/2 + 3 ] = π [ 9/2 + 6/2 ] = 15π/2.', '1 TRPL B', 'materi5'),
(83, 'Volume Benda Putar', 'Volume benda putar jika daerah yang dibatasi oleh x = y + 1, sumbu-y, dari y = 0 sampai y = 2 diputar mengelilingi sumbu-y adalah...', '8π/3 satuan volume', '10π/3 satuan volume', '14π/3 satuan volume', '26π/3 satuan volume', 'D', 'Rumus (Metode Cakram): V = π ∫cd [g(y)]² dy.\r\nFungsi & Batas: g(y) = y + 1, c=0, d=2.\r\nIntegral: V = π ∫₀² (y + 1)² dy = π ∫₀² (y² + 2y + 1) dy.\r\nHitung: π [ (1/3)y³ + y² + y ]₀² = π [ (1/3)(2)³ + (2)² + 2 ] - 0 = π [ 8/3 + 4 + 2 ] = π [ 8/3 + 18/3 ] = 26π/3.', '1 TRPL B', 'materi5'),
(84, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x² dan y = 3x diputar mengelilingi sumbu-x adalah...', '81π/5 satuan volume', '243π/5 satuan volume', '162π/5 satuan volume', '54π/5 satuan volume', 'C', 'Titik potong: x² = 3x → x² - 3x = 0 → x(x - 3) = 0. Jadi, x = 0 dan x = 3.\r\nRumus (Metode Cincin): V = π ∫ab [ (R(x))² - (r(x))² ] dx. (R(x) = 3x, r(x) = x²)\r\nIntegral: V = π ∫₀³ ( (3x)² - (x²)² ) dx = π ∫₀³ (9x² - x⁴) dx.\r\nHitung: π [ 3x³ - (1/5)x⁵ ]₀³ = π [ 3(3)³ - (1/5)(3)⁵ ] - 0 = π [ 81 - 243/5 ] = π [ 405/5 - 243/5 ] = 162π/5.', '1 TRPL B', 'materi5'),
(85, 'Panjang Busur Dengan Integral', 'Tentukan panjang busur dari kurva y = 2x + 3 dari x = 0 sampai x = 4.', '4 satuan panjang', '2√5 satuan panjang', '4√5 satuan panjang', '8 satuan panjang', 'C', 'Turunan: dy/dx = 2.\r\nPanjang Busur: L = ∫₀⁴ √(1 + (2)²) dx = ∫₀⁴ √5 dx.\r\nHitung: [ √5 x ]₀⁴ = 4√5.', '1 TRPL B', 'materi6'),
(86, 'Panjang Busur Dengan Integral', 'Panjang busur kurva y = (2/3)x^(3/2) dari x = 0 sampai x = 3 adalah...', '14/3 satuan panjang', '19/3 satuan panjang', '4/3 satuan panjang', '1/3 satuan panjang', 'A', 'Turunan: dy/dx = √x.\r\n√(1 + (dy/dx)²): √(1 + x).\r\nPanjang Busur: L = ∫₀³ √(1 + x) dx.\r\nHitung: [ (2/3)(1 + x)^(3/2) ]₀³ = (2/3)(4)^(3/2) - (2/3)(1)^(3/2) = 16/3 - 2/3 = 14/3.', '1 TRPL B', 'materi6'),
(87, 'Panjang Busur Dengan Integral', 'Tentukan panjang busur dari kurva x = (2/3)y^(3/2) dari y = 1 sampai y = 3.', '(10√3 - 4√2)/3 satuan panjang', '(16 - 4√2)/3 satuan panjang', '(16√2 - 2)/3 satuan panjang', '(10√10 - 2√2)/3 satuan panjang', 'B', 'Turunan: dx/dy = √y.\r\n√(1 + (dx/dy)²): √(1 + y).\r\nPanjang Busur: L = ∫₁³ √(1 + y) dy.\r\nHitung: [ (2/3)(1 + y)^(3/2) ]₁³ = (2/3)(4)^(3/2) - (2/3)(2)^(3/2) = 16/3 - 4√2/3 = (16 - 4√2)/3.', '1 TRPL B', 'materi6'),
(88, 'Panjang Busur Dengan Integral', 'Panjang busur kurva y = (x² / 2) - (ln x / 4) dari x = 1 sampai x = 2 adalah...', '(3/4) - (1/4)ln 2 satuan panjang', '(5/4) - (1/4)ln 2 satuan panjang', '(3/2) + (1/4)ln 2 satuan panjang', '(3/4) + (1/4)ln 2 satuan panjang', 'C', 'Turunan: dy/dx = x - 1/(4x).\r\n√(1 + (dy/dx)²): x + 1/(4x).\r\nPanjang Busur: L = ∫₁² (x + 1/(4x)) dx.\r\nHitung: [ (1/2)x² + (1/4)ln|x| ]₁² = (2 + (1/4)ln 2) - (1/2 + 0) = 3/2 + (1/4)ln 2.', '1 TRPL B', 'materi6'),
(89, 'Panjang Busur Dengan Integral', 'Panjang busur kurva y = (1/3)(x² + 2)^(3/2) dari x = 0 sampai x = 1 adalah...', '5/3 satuan panjang', '7/3 satuan panjang', '8/3 satuan panjang', '4/3 satuan panjang', 'D', 'Turunan: dy/dx = x(x² + 2)^(1/2).\r\n√(1 + (dy/dx)²): √(1 + x⁴ + 2x²) = √(x² + 1)² = x² + 1.\r\nPanjang Busur: L = ∫₀¹ (x² + 1) dx.\r\nHitung: [ (1/3)x³ + x ]₀¹ = 1/3 + 1 = 4/3.', '1 TRPL B', 'materi6'),
(90, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh y = x² - 4 dan y = x - 2 adalah...', '9/2 satuan luas', '7/2 satuan luas', '5/2 satuan luas', '3/2 satuan luas', 'A', 'Titik potong: x = -1 dan x = 2.\r\nFungsi selisih: (x - 2) - (x² - 4) = -x² + x + 2 (a=-1).\r\nRumus Luas: |a/6| (x₂ - x₁ )³.\r\nLuas = |-1/6| (2 - (-1))³ = 9/2.', '1 TRPL B', 'materi3'),
(91, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh kurva x = y² - 4 dan sumbu-y adalah...', '64/3 satuan luas', '128/3 satuan luas', '32/3 satuan luas', '16/3 satuan luas', 'C', 'Titik potong sumbu-y: y = -2 dan y = 2.\r\nRumus Luas: |a/6| (y₂ - y₁ )³. Di sini a=1 (dari y²).\r\nLuas = |1/6| (2 - (-2))³ = 32/3.', '1 TRPL B', 'materi3'),
(92, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh y = -x² + 2x dan sumbu-x adalah...', '4/3 satuan luas', '1/3 satuan luas', '2/3 satuan luas', '1 satuan luas', 'A', 'Titik potong sumbu-x: x = 0 dan x = 2.\r\nRumus Luas: |a/6| (x₂ - x₁ )³. Di sini a=-1.\r\nLuas = |-1/6| (2 - 0)³ = 4/3.', '1 TRPL B', 'materi3'),
(93, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh y = x² - 2x - 3 dan sumbu-x adalah...', '32/3 satuan luas', '16/3 satuan luas', '8/3 satuan luas', '4/3 satuan luas', 'A', 'Titik potong sumbu-x: x = -1 dan x = 3.\r\nRumus Luas: |a/6| (x₂ - x₁ )³. Di sini a=1.\r\nLuas = |1/6| (3 - (-1))³ = 32/3.', '1 TRPL B', 'materi3'),
(94, 'Menghitung Luas Daerah menggunakan Rumus', 'Luas daerah yang dibatasi oleh y = x² - 4x + 3 dan sumbu-x adalah...', '8/3 satuan luas', '4/3 satuan luas', '2/3 satuan luas', '16/3 satuan luas', 'B', 'Titik potong sumbu-x: x = 1 dan x = 3.\r\nRumus Luas: |a/6| (x₂ - x₁ )³. Di sini a=1.\r\nLuas = |1/6| (3 - 1)³ = 4/3.', '1 TRPL B', 'materi3'),
(95, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x dan y = √x diputar mengelilingi sumbu-x adalah...', 'π/6 satuan volume', 'π/2 satuan volume', 'π/3 satuan volume', '2π/3 satuan volume', 'A', 'Titik potong: x = √x → x² = x → x = 0 dan x = 1.\r\nRumus Volume (Metode Cincin): V = π ∫ab [ (R(x))² - (r(x))² ] dx. (R(x) = √x, r(x) = x)\r\nIntegral: V = π ∫₀¹ ( (√x)² - x² ) dx = π ∫₀¹ (x - x²) dx.\r\nHitung: π [ (1/2)x² - (1/3)x³ ]₀¹ = π [ (1/2)(1)² - (1/3)(1)³ ] - 0 = π [ 1/2 - 1/3 ] = π [ 3/6 - 2/6 ] = π/6.', '1 TRPL B', 'materi4'),
(96, 'Volume Benda dalam Ruang', 'Volume benda putar jika daerah yang dibatasi oleh x = y² dan x = y diputar mengelilingi sumbu-y adalah...', '4π/15 satuan volume', 'π/15 satuan volume', '2π/15 satuan volume', 'π/30 satuan volume', 'C', 'Titik potong: y² = y → y = 0 dan y = 1.\r\nRumus Volume (Metode Cincin): V = π ∫cd [ (R(y))² - (r(y))² ] dy. (R(y) = y, r(y) = y²)\r\nIntegral: V = π ∫₀¹ (y² - (y²)²) dy = π ∫₀¹ (y² - y⁴) dy.\r\nHitung: π [ (1/3)y³ - (1/5)y⁵ ]₀¹ = π [ (1/3)(1)³ - (1/5)(1)⁵ ] - 0 = π [ 1/3 - 1/5 ] = π [ 5/15 - 3/15 ] = 2π/15.', '1 TRPL B', 'materi4'),
(97, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = 2x, sumbu-x, garis x = 0, dan x = 2 diputar mengelilingi sumbu-x adalah...', '16π/3 satuan volume', '32π/3 satuan volume', '8π/3 satuan volume', '4π/3 satuan volume', 'B', 'Rumus Volume (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi dan Batas: f(x) = 2x, a=0, b=2.\r\nIntegral: V = π ∫₀² (2x)² dx = π ∫₀² 4x² dx.\r\nHitung: π [ (4/3)x³ ]₀² = π [ (4/3)(2)³ - 0 ] = π [ 32/3 - 0 ] = 32π/3.', '1 TRPL B', 'materi4'),
(98, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x³, sumbu-x, garis x = 0, dan x = 1 diputar mengelilingi sumbu-x adalah...', 'π/7 satuan volume', '2π/7 satuan volume', 'π/4 satuan volume', '4π/7 satuan volume', 'A', 'Rumus Volume (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi dan Batas: f(x) = x³, a=0, b=1.\r\nIntegral: V = π ∫₀¹ (x³)² dx = π ∫₀¹ x⁶ dx.\r\nHitung: π [ (1/7)x⁷ ]₀¹ = π [ (1/7)(1)⁷ - 0 ] = π/7.', '1 TRPL B', 'materi4'),
(99, 'Volume Benda dalam Ruang', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = 1 - x², sumbu-x, di kuadran I, diputar mengelilingi sumbu-x adalah...', '16π/15 satuan volume', '8π/15 satuan volume', '2π/15 satuan volume', '4π/15 satuan volume', 'B', 'Batas di kuadran I: y = 0 → 1 - x² = 0 → x = 1 (karena x ≥ 0). Jadi, a=0, b=1.\r\nRumus Volume (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nIntegral: V = π ∫₀¹ (1 - x²)² dx = π ∫₀¹ (1 - 2x² + x⁴) dx.\r\nHitung: π [ x - (2/3)x³ + (1/5)x⁵ ]₀¹ = π [ 1 - 2/3 + 1/5 ] - 0 = π [ 15/15 - 10/15 + 3/15 ] = 8π/15.', '1 TRPL B', 'materi4'),
(100, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x + 1 dan y = 2 diputar mengelilingi sumbu-x, dari x = 0 sampai x = 1 adalah...', 'π/3 satuan volume', '5π/3 satuan volume', 'π satuan volume', '4π/3 satuan volume', 'B', 'Rumus (Metode Cincin): V = π ∫ab [ (R(x))² - (r(x))² ] dx. (R(x) = 2, r(x) = x + 1)\r\nIntegral: V = π ∫₀¹ ( 2² - (x + 1)² ) dx = π ∫₀¹ (4 - (x² + 2x + 1)) dx = π ∫₀¹ (-x² - 2x + 3) dx.\r\nHitung: π [ -(1/3)x³ - x² + 3x ]₀¹ = π [ -(1/3)(1)³ - (1)² + 3(1) ] - 0 = π [ -1/3 - 1 + 3 ] = π [ -1/3 + 2 ] = π [ -1/3 + 6/3 ] = 5π/3.', '1 TRPL B', 'materi5'),
(101, 'Volume Benda Putar', 'Volume benda putar jika daerah yang dibatasi oleh x = y + 1 dan x = 2 diputar mengelilingi sumbu-y, dari y = 0 sampai y = 1 adalah...', 'π/3 satuan volume', '2π/3 satuan volume', 'π satuan volume', '5π/3 satuan volume', 'D', 'Rumus (Metode Cincin): V = π ∫cd [ (R(y))² - (r(y))² ] dy. (R(y) = 2, r(y) = y + 1)\r\nIntegral: V = π ∫₀¹ ( 2² - (y + 1)² ) dy = π ∫₀¹ (4 - (y² + 2y + 1)) dy = π ∫₀¹ (-y² - 2y + 3) dy.\r\nHitung: π [ -(1/3)y³ - y² + 3y ]₀¹ = π [ -(1/3)(1)³ - (1)² + 3(1) ] - 0 = π [ -1/3 - 1 + 3 ] = π [ -1/3 + 2 ] = π [ -1/3 + 6/3 ] = 5π/3.', '1 TRPL B', 'materi5'),
(102, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = x², sumbu-x, garis x = 1, dan x = 3 diputar mengelilingi sumbu-x adalah...', '121π/5 satuan volume', '242π/5 satuan volume', '484π/5 satuan volume', '605π/5 satuan volume', 'B', 'Rumus (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi & Batas: f(x) = x², a=1, b=3.\r\nIntegral: V = π ∫₁³ (x²)² dx = π ∫₁³ x⁴ dx.\r\nHitung: π [ (1/5)x⁵ ]₁³ = π [ (1/5)(3)⁵ - (1/5)(1)⁵ ] = π [ 243/5 - 1/5 ] = 242π/5.', '1 TRPL B', 'materi5'),
(103, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = √(x+4), sumbu-x, garis x = 0, dan x = 5 diputar mengelilingi sumbu-x adalah...', '40π/2 satuan volume', '50π/2 satuan volume', '45π/2 satuan volume', '65π/2 satuan volume', 'D', 'Rumus (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nFungsi & Batas: f(x) = √(x+4), a=0, b=5.\r\nIntegral: V = π ∫₀⁵ (√(x+4))² dx = π ∫₀⁵ (x + 4) dx.\r\nHitung: π [ (1/2)x² + 4x ]₀⁵ = π [ (1/2)(5)² + 4(5) ] - 0 = π [ 25/2 + 20 ] = π [ 25/2 + 40/2 ] = 65π/2.', '1 TRPL B', 'materi5'),
(104, 'Volume Benda Putar', 'Volume benda putar yang terjadi jika daerah yang dibatasi oleh y = 1 - x, sumbu-x, dan sumbu-y diputar mengelilingi sumbu-x adalah...', 'π/3 satuan volume', '2π/3 satuan volume', 'π satuan volume', '4π/3 satuan volume', 'A', 'Batas: Kurva memotong sumbu-x di x=1, dan sumbu-y di y=1. Jadi, a=0, b=1.\r\nRumus (Metode Cakram): V = π ∫ab [f(x)]² dx.\r\nIntegral: V = π ∫₀¹ (1 - x)² dx = π ∫₀¹ (1 - 2x + x²) dx.\r\nHitung: π [ x - x² + (1/3)x³ ]₀¹ = π [ 1 - 1 + 1/3 ] - 0 = π [ 1/3 ] = π/3.', '1 TRPL B', 'materi5'),
(105, 'Panjang Busur Dengan Integral', 'Panjang busur kurva x = (1/3)(y² + 2)^(3/2) dari y = 0 sampai y = 1 adalah...', '4/3 satuan panjang', '1/3 satuan panjang', '2/3 satuan panjang', '5/3 satuan panjang', 'A', 'Turunan: dx/dy = y(y² + 2)^(1/2).\r\n√(1 + (dx/dy)²): √(1 + y⁴ + 2y²) = √(y² + 1)² = y² + 1.\r\nPanjang Busur: L = ∫₀¹ (y² + 1) dy.\r\nHitung: [ (1/3)y³ + y ]₀¹ = 1/3 + 1 = 4/3.', '1 TRPL B', 'materi6'),
(106, 'Panjang Busur Dengan Integral', 'Tentukan panjang busur dari kurva y = x³ / 3 + 1/(4x) dari x = 1 sampai x = 2.', '13/8 satuan panjang', '59/24 satuan panjang', '21/8 satuan panjang', '25/8 satuan panjang', 'B', 'Turunan: dy/dx = x² - 1/(4x²).\r\n√(1 + (dy/dx)²): x² + 1/(4x²).\r\nPanjang Busur: L = ∫₁² (x² + 1/(4x²)) dx.\r\nHitung: [ (1/3)x³ - 1/(4x) ]₁² = (8/3 - 1/8) - (1/3 - 1/4) = 59/24.', '1 TRPL B', 'materi6'),
(107, 'Panjang Busur Dengan Integral', 'Panjang busur dari kurva y = 4x - 1 dari x = 1 sampai x = 3 adalah...', '2√17 satuan panjang', '4√17 satuan panjang', '√17 satuan panjang', '3√17 satuan panjang', 'A', 'Turunan: dy/dx = 4.\r\nPanjang Busur: L = ∫₁³ √(1 + 4²) dx = ∫₁³ √17 dx.\r\nHitung: [ √17 x ]₁³ = 3√17 - √17 = 2√17.', '1 TRPL B', 'materi6'),
(108, 'Panjang Busur Dengan Integral', 'Panjang busur dari kurva y = (1/6)x³ + 1/(2x) dari x = 1 sampai x = 2 adalah...', '17/12 satuan panjang', '19/12 satuan panjang', '23/12 satuan panjang', '25/12 satuan panjang', 'A', 'Turunan: dy/dx = (1/2)x² - 1/(2x²).\r\n√(1 + (dy/dx)²): (1/2)x² + 1/(2x²).\r\nPanjang Busur: L = ∫₁² ( (1/2)x² + 1/(2x²) ) dx.\r\nHitung: [ (1/6)x³ - 1/(2x) ]₁² = (8/6 - 1/4) - (1/6 - 1/2) = 17/12.', '1 TRPL B', 'materi6'),
(109, 'Panjang Busur Dengan Integral', 'Panjang busur kurva y = x dari x = 0 sampai x = 5.', '2√2 satuan panjang', '4√2 satuan panjang', '3√2 satuan panjang', '5√2 satuan panjang', 'D', 'Turunan: dy/dx = 1.\r\nPanjang Busur: L = ∫₀⁵ √(1 + 1²) dx = ∫₀⁵ √2 dx.\r\nHitung: [ √2 x ]₀⁵ = 5√2.', '1 TRPL B', 'materi6');

-- --------------------------------------------------------

--
-- Table structure for table `soal_level`
--

CREATE TABLE `soal_level` (
  `id_soal_level` int(11) NOT NULL,
  `id_level` int(11) DEFAULT NULL,
  `pertanyaan` text DEFAULT NULL,
  `gambar` varchar(255) NOT NULL,
  `opsi_a` varchar(255) DEFAULT NULL,
  `opsi_b` varchar(255) DEFAULT NULL,
  `opsi_c` varchar(255) DEFAULT NULL,
  `opsi_d` varchar(255) DEFAULT NULL,
  `jawaban_benar` char(1) DEFAULT NULL,
  `pembahasan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `soal_level`
--

INSERT INTO `soal_level` (`id_soal_level`, `id_level`, `pertanyaan`, `gambar`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `jawaban_benar`, `pembahasan`) VALUES
(1, 1, 'Hitung ∫2x dx = ..', '', '(1/2)x² + C', 'x² + C', '2x + C', 'x + C', 'B', '\\[\r\n\\int 2x \\, dx = x^2 + C\r\n\\]\r\nGunakan rumus dasar integral \\( \\int x^n dx = \\frac{1}{n+1} x^{n+1} + C \\). Karena \\( n = 1 \\), maka hasilnya adalah \\( x^2 + C \\).'),
(2, 1, 'Hasil dari ∫ 5x dx adalah ...', '', '5x² + C', '5x + C', '(5/2)x² + C', 'x⁵ + C', 'C', '\\[\r\n\\int 5x \\, dx = \\frac{5}{2}x^2 + C\r\n\\]\r\nKonstanta 5 bisa dikeluarkan dari integral: \\( 5 \\int x \\, dx = 5 \\cdot \\frac{1}{2}x^2 = \\frac{5}{2}x^2 + C \\).'),
(3, 1, 'Bentuk umum ∫ ax dx adalah ...', '', '(a/2)x² + C', 'ax + C', '(2a)x + C', 'a + x + C', 'A', '\\[\r\n\\int ax \\, dx = \\frac{a}{2}x^2 + C\r\n\\]\r\nKonstanta \\( a \\) bisa dikeluarkan: \\( a \\int x \\, dx = a \\cdot \\frac{1}{2}x^2 \\).'),
(4, 1, '∫ 3 dx = ...', '', '(3/2)x² + C', '3x + C', '9x+C', 'x³ + C', 'B', '\\[\r\n\\int 3 \\, dx = 3x + C\r\n\\]\r\nKarena \\( \\int a \\, dx = ax + C \\) untuk konstanta \\( a \\).'),
(5, 2, ' ∫ x³ dx = ...', '', '(1/3)x³ + C', '(1/4)x⁴ + C', 'x⁴ + C', '3x² + C', 'B', '\\[\r\n\\int x^2 \\, dx = \\frac{1}{3}x^3 + C\r\n\\]\r\nGunakan rumus \\( \\int x^n dx = \\frac{1}{n+1} x^{n+1} + C \\) dengan \\( n = 2 \\).'),
(6, 2, 'Hasil dari ∫ 2x⁴ dx adalah...', '', '(2/5)x⁵ + C', '(2/4)x⁴ + C', '(1/5)x⁵ + C', '2x⁵ + C', 'A', '\\[\r\n\\int 2x^4 \\, dx = \\frac{2}{5}x^5 + C\r\n\\]\r\nKonstanta 2 dikalikan hasil integral dari \\( x^4 \\), yaitu \\( \\frac{1}{5}x^5 \\).'),
(7, 2, '∫ x⁵ dx =...', '', '(1/6)x⁶ + C', '(1/5)x⁵ + C', 'x⁶ + C', '6x⁵ + C', 'A', '\\[\r\n\\int x^6 \\, dx = \\frac{1}{7}x^7 + C\r\n\\]\r\nDengan \\( n = 6 \\), maka hasil integral: \\( \\frac{1}{n+1}x^{n+1} = \\frac{1}{7}x^7 + C \\).'),
(8, 2, 'Berapakah hasil dari ∫ -3x² dx', '', '-x³ + C', '-x² + C', '-x³ - C', '-x³', 'A', '\\[\r\n\\int -3x^2 \\, dx = -x^3 + C\r\n\\]\r\nKonstanta -3 dikalikan hasil integral \\( x^2 \\): \\( -3 \\cdot \\frac{1}{3}x^3 = -x^3 + C \\).'),
(9, 3, 'Hasil dari  ∫ sin x dx adalah...', '', 'cos x + C', '-cos x + C', '-sin x + C', 'tan x + C', 'B', '\\[\r\n\\int \\sin x \\, dx = -\\cos x + C\r\n\\]\r\nIntegral dari \\( \\sin x \\) adalah \\( -\\cos x \\), berdasarkan tabel integral dasar trigonometri.'),
(10, 3, '∫ cos x dx', '', '-sin x + C', 'tan x + C', 'sin x + C', '-cos x + C', 'C', '\\[\r\n\\int \\cos x \\, dx = \\sin x + C\r\n\\]\r\nGunakan aturan dasar: turunan dari \\( \\sin x \\) adalah \\( \\cos x \\), sehingga integralnya adalah \\( \\sin x + C \\).'),
(11, 3, 'Berapakah hasil dari ∫ sec² x dx?', '', 'cot x + C', '-tan x + C', 'tan x + C', 'sec x + C', 'C', '\\[\r\n\\int \\sec^2 x \\, dx = \\tan x + C\r\n\\]\r\nKarena turunan dari \\( \\tan x \\) adalah \\( \\sec^2 x \\), maka integralnya adalah \\( \\tan x + C \\).'),
(12, 3, '∫sec x tan x dx =...', '', 'sec x + C', 'csc x + C', 'tan x + C', '-sec x + C', 'A', '\\[\r\n\\int \\sec x \\tan x \\, dx = \\sec x + C\r\n\\]\r\nTurunan dari \\( \\sec x \\) adalah \\( \\sec x \\tan x \\), sehingga kebalikannya adalah integral dari \\( \\sec x \\tan x \\) yaitu \\( \\sec x + C \\).'),
(13, 4, '\\( \\int_{0}^{2} x \\, dx \\)\r\n\r\n', '', '2', '4', '1', '3', 'B', '\\[\r\n\\int_{0}^{2} x \\, dx = \\left[ \\frac{1}{2}x^2 \\right]_0^2 = \\frac{1}{2}(2)^2 - \\frac{1}{2}(0)^2 = 2\r\n\\]\r\nGunakan rumus integral tentu \\( \\int_a^b f(x) dx = F(b) - F(a) \\), dengan \\( F(x) = \\frac{1}{2}x^2 \\).'),
(14, 4, '\\( \\int_{1}^{3} x^2 \\, dx \\)', '', '\\( \\frac{26}{3} \\)', '\\( \\frac{9}{2} \\)', '10', '6', 'A', '\\[\r\n\\int_{1}^{3} x^2 \\, dx = \\left[ \\frac{1}{3}x^3 \\right]_1^3 = \\frac{1}{3}(27) - \\frac{1}{3}(1) = \\frac{26}{3}\r\n\\]\r\nGunakan aturan: \\( \\int x^n dx = \\frac{1}{n+1}x^{n+1} + C \\) lalu hitung batas atas dan bawahnya.'),
(15, 5, 'Apa rumus untuk menghitung luas daerah yang diarsir pada kurva di bawah?', 'kurva2.png', '\\(\\int_{x_1}^{x_2} f(x) \\, dx\\)', '\\(\\int_{x_2}^{x_1} f(x) \\, dx\\)', '\\(\\int_{x_1}^{x_2} f(x) \\, dy\\)', '\\(\\int_{x_1}^{x_2} f\'(x) \\, dx\\)', 'A', '\\[\r\n\\text{Luas} = \\int_{x_1}^{x_2} f(x) \\, dx\r\n\\]\r\nKarena kurva \\( y = f(x) \\) dibatasi oleh sumbu-X (\\( y = 0 \\)) dan garis vertikal \\( x = x_1 \\) dan \\( x = x_2 \\), maka luas daerah yang diarsir dihitung menggunakan integral tentu dari \\( f(x) \\) terhadap \\( x \\).'),
(16, 5, 'Tentukan rumus integral yang digunakan untuk menghitung luas daerah kurva yang diarsir pada gambar di bawah.', 'kurva3.png', '\\(\\int_{x_1}^{x_2} f(x) \\, dx\\)', '\\(-\\int_{x_1}^{x_2} f(x) \\, dx\\)', '\\(\\int_{x_2}^{x_1} f(x) \\, dx\\)', '`(\\int_{x_1}^{x_2}', 'B', '\\[\r\n\\text{Luas} = \\left| \\int_{x_1}^{x_2} f(x) \\, dx \\right|\r\n\\]\r\nKarena fungsi \\( f(x) \\) berada di bawah sumbu-X, hasil integral \\( \\int_{x_1}^{x_2} f(x) \\, dx \\) akan bernilai negatif. Maka untuk mendapatkan luas (yang selalu positif), diambil nilai mutlak dari hasil integral tersebut.'),
(17, 5, 'Apa rumus integral untuk menghitung luas daerah yang diarsir pada gambar?', 'kurva4.png', '\\( \\int_{y_1}^{y_2} [f(y) - g(y)] \\, dy \\)', '\\( \\int_{y_1}^{y_2} [g(y) - f(y)] \\, dy \\)', '\\( \\int_{y_1}^{y_2} f(y) \\, dy \\)', '\\( \\int_{y_1}^{y_2} g(y) \\, dy \\)', 'B', '\\[\r\n\\text{Luas} = \\int_{y_1}^{y_2} \\left[ g(y) - f(y) \\right] \\, dy\r\n\\]\r\nKarena daerah dibatasi secara horizontal oleh dua kurva \\( x = f(y) \\) (kiri) dan \\( x = g(y) \\) (kanan), maka panjang horizontalnya adalah \\( g(y) - f(y) \\), dan luas dihitung dengan mengintegrasikan terhadap \\( y \\).'),
(18, 5, 'Apa rumus integral untuk menghitung luas daerah yang diarsir pada gambar?', 'kurva5.png', '\\( \\int_{a}^{b} g(x) \\, dx + \\int_{b}^{c} [f(x) - h(x)] \\, dx \\)', '\\( \\int_{a}^{b} g(x) \\, dx - \\int_{b}^{c} [f(x) - h(x)] \\, dx \\)', '\\( \\int_{a}^{c} [f(x) - g(x)] \\, dx \\)', '\\( \\int_{a}^{c} f(x) \\, dx - g(x) \\, dx \\)', 'A', '\\[\r\n\\text{Luas} = \\int_{a}^{b} \\left[ g(x) - h(x) \\right] \\, dx + \\int_{b}^{c} \\left[ f(x) - h(x) \\right] \\, dx\r\n\\]\r\nDaerah diarsir terdiri dari dua bagian:\r\n\\begin{itemize}\r\n  \\item Dari \\( a \\) ke \\( b \\): selisih antara atas \\( g(x) \\) dan bawah \\( h(x) \\)\r\n  \\item Dari \\( b \\) ke \\( c \\): selisih antara atas \\( f(x) \\) dan bawah \\( h(x) \\)\r\n\\end{itemize}\r\nMasing-masing dihitung dengan integral selisih fungsi atas dan bawah, lalu dijumlahkan.'),
(19, 6, 'Hitunglah luas daerah yang dibatasi oleh kurva ( y = x^2 + 4x + 6 ) dan garis ( y = 2 - x ). Berapa luas daerahnya?', '', 'Luas = \\( \\frac{9}{2} \\)', 'Luas = \\( \\frac{11}{2} \\)', 'Luas = \\( \\frac{7}{2} \\)', 'Luas = \\( \\frac{27}{4} \\)', 'A', '\\[\r\n\\text{Langkah-langkah:}\r\n\\]\r\n\r\n1. \\text{Cari titik potong:}\r\n\\[\r\nx^2 + 4x + 6 = 2 - x \\Rightarrow x^2 + 5x + 4 = 0 \\Rightarrow (x+1)(x+4) = 0\r\n\\]\r\n\\[\r\nx = -1 \\quad \\text{dan} \\quad x = -4\r\n\\]\r\n\r\n2. \\text{Fungsi atas: } y = 2 - x \\quad \\text{dan bawah: } y = x^2 + 4x + 6\r\n\r\n3. \\text{Integral luas:}\r\n\\[\r\nL = \\int_{-4}^{-1} \\left[ (2 - x) - (x^2 + 4x + 6) \\right] dx = \\int_{-4}^{-1} (-x^2 - 5x - 4) dx\r\n\\]\r\n\r\n4. \\text{Hitung integral:}\r\n\\[\r\n= \\left[ -\\frac{1}{3}x^3 - \\frac{5}{2}x^2 - 4x \\right]_{-4}^{-1}\r\n\\]\r\n\r\n5. \\text{Evaluasi:}\r\n\\[\r\n= \\left( -\\frac{1}{3}(-1)^3 - \\frac{5}{2}(-1)^2 - 4(-1) \\right) - \\left( -\\frac{1}{3}(-4)^3 - \\frac{5}{2}(-4)^2 - 4(-4) \\right)\r\n\\]\r\n\\[\r\n= \\left( \\frac{1}{3} - \\frac{5}{2} + 4 \\right) - \\left( \\frac{64}{3} - 40 + 16 \\right)\r\n= \\frac{9}{2}\r\n\\]\r\n\r\n\\[\r\n\\boxed{\\text{Luas} = \\frac{9}{2}}\r\n\\]\r\n'),
(20, 6, 'Hitunglah luas daerah yang dibatasi oleh kurva ( y = x^2 - 4 ) dan sumbu x dari ( x = -2 ) hingga ( x = 2 )', '', 'Luas = \\( \\frac{32}{3} \\)', 'Luas = \\( \\frac{16}{3} \\)', 'Luas = \\( \\frac{64}{3} \\)', 'Luas = \\( 8 \\)', 'A', '\\[\r\n\\text{Luas} = \\int_{-2}^{2} |x^2 - 4| \\, dx\r\n\\]\r\nKarena \\( x^2 - 4 < 0 \\) untuk \\( -2 < x < 2 \\), maka:\r\n\\[\r\n= - \\int_{-2}^{2} (x^2 - 4) \\, dx = \\int_{-2}^{2} (4 - x^2) \\, dx\r\n\\]\r\n\r\nHitung:\r\n\\[\r\n\\int_{-2}^{2} (4 - x^2) dx = \\left[ 4x - \\frac{1}{3}x^3 \\right]_{-2}^{2} = \\frac{16}{3} - ( -\\frac{16}{3} ) = \\frac{32}{3}\r\n\\]\r\n\r\n\\[\r\n\\boxed{\\text{Luas} = \\frac{32}{3}}\r\n\\]\r\n'),
(21, 6, 'Hitunglah luas daerah antara kurva ( y = x^2 + 2x ) dan sumbu x dari ( x = -2 ) ke ( x = 0 )', '', 'Luas = \\( \\frac{4}{3} \\)', 'Luas = \\( 2 \\)', 'Luas = \\( \\frac{2}{3} \\)', 'Luas = \\( \\frac{8}{3} \\)', 'A', '\\[\r\n\\text{Luas} = \\int_{-2}^{0} |x^2 + 2x| \\, dx\r\n\\]\r\nKarena pada interval tersebut \\( x^2 + 2x < 0 \\), maka:\r\n\\[\r\n= \\int_{-2}^{0} -(x^2 + 2x) \\, dx = \\int_{-2}^{0} (-x^2 - 2x) \\, dx\r\n\\]\r\n\r\nHitung:\r\n\\[\r\n= \\left[ -\\frac{1}{3}x^3 - x^2 \\right]_{-2}^{0} = 0 - ( \\frac{8}{3} - 4 ) = \\frac{4}{3}\r\n\\]\r\n\r\n\\[\r\n\\boxed{\\text{Luas} = \\frac{4}{3}}\r\n\\]\r\n'),
(22, 6, 'Hitunglah luas daerah yang dibatasi oleh ( y = 3x + 1 ) dan ( y = x^2 )', '', 'Luas \\( \\approx 4.68 \\)', 'Luas \\( \\approx 3.14 \\)', 'Luas \\( \\approx 5.00 \\)', 'Luas \\( \\approx 2.71 \\)', 'A', '\\[\r\n\\text{Luas} = \\int_{x_1}^{x_2} \\left[ (3x + 1) - x^2 \\right] \\, dx = \\int_{x_1}^{x_2} (3x + 1 - x^2) \\, dx\r\n\\]\r\nCari titik potong dengan menyamakan fungsi:\r\n\\[\r\n3x + 1 = x^2 \\Rightarrow x^2 - 3x - 1 = 0 \\Rightarrow x = \\frac{3 \\pm \\sqrt{13}}{2}\r\n\\]\r\nFungsi atas: \\( 3x + 1 \\), fungsi bawah: \\( x^2 \\), maka:\r\n\\[\r\n\\text{Luas} = \\int_{\\frac{3 - \\sqrt{13}}{2}}^{\\frac{3 + \\sqrt{13}}{2}} (3x + 1 - x^2) \\, dx\r\n\\]\r\n'),
(23, 6, 'Hitunglah luas daerah yang dibatasi oleh parabola ( y = -x^2 + 4 ) dan sumbu-x', '', 'Luas = \\( \\frac{32}{3} \\)', 'Luas = \\( 16 \\)', 'Luas = \\( \\frac{64}{3} \\)', 'Luas = \\( 8 \\)', 'A', '\\[\r\n\\text{Luas} = \\int_{-2}^{2} (-x^2 + 4) \\, dx\r\n\\]\r\nKarena parabola \\( y = -x^2 + 4 \\) memotong sumbu-X di \\( x = -2 \\) dan \\( x = 2 \\), dan berada di atas sumbu-X, maka integral bisa langsung dihitung:\r\n\\[\r\n= \\left[ -\\frac{1}{3}x^3 + 4x \\right]_{-2}^{2} = \\frac{16}{3} - ( -\\frac{16}{3} ) = \\frac{32}{3}\r\n\\]\r\n\r\n\\[\r\n\\boxed{\\text{Luas} = \\frac{32}{3}}\r\n\\]\r\n'),
(24, 7, 'Diketahui daerah yang dibatasi oleh ( y = x^{1/2} ), ( x = 0 ), dan ( x = 4 ), diputar terhadap sumbu-x. Berapakah volume benda yang terbentuk?', '', 'Volume = \\( 8\\pi \\)', 'Volume = \\( 16\\pi \\)', 'Volume = \\( 4\\pi \\)', 'Volume = \\( 12\\pi \\)', 'A', '\\[\r\n\\text{Volume} = \\pi \\int_{a}^{b} [f(x)]^2 dx\r\n\\]\r\nDengan \\( f(x) = \\sqrt{x} = x^{1/2} \\), maka:\r\n\\[\r\n[f(x)]^2 = x\r\n\\]\r\nBatas: \\( x = 0 \\) sampai \\( x = 4 \\)\r\n\r\n\\[\r\nV = \\pi \\int_{0}^{4} x \\, dx = \\pi \\left[ \\frac{1}{2}x^2 \\right]_0^4 = \\pi \\cdot 8 = \\boxed{8\\pi}\r\n\\]\r\n'),
(25, 7, 'Diketahui daerah yang dibatasi oleh ( y = x^2 ) dari ( x = 0 ) sampai ( x = 2 ), diputar terhadap sumbu-x. Berapakah volume benda putar yang dihasilkan?', '', 'Volume = \\( \\frac{16}{5}\\pi \\)', 'Volume = \\( \\frac{32}{5}\\pi \\)', 'Volume = \\( \\frac{8}{5}\\pi \\)', 'Volume = \\( \\frac{36}{5}\\pi \\)', 'B', '\\[\r\n\\text{Volume} = \\pi \\int_{a}^{b} [f(x)]^2 dx\r\n\\]\r\nDengan \\( f(x) = x^2 \\Rightarrow [f(x)]^2 = x^4 \\)\r\n\r\n\\[\r\nV = \\pi \\int_{0}^{2} x^4 \\, dx = \\pi \\left[ \\frac{1}{5}x^5 \\right]_0^2 = \\pi \\cdot \\frac{32}{5}\r\n\\]\r\n\r\n\\[\r\n\\boxed{V = \\frac{32}{5}\\pi}\r\n\\]\r\n'),
(26, 7, 'Hitunglah volume benda putar yang dihasilkan jika daerah di bawah grafik ( y = 2x ) dari ( x = 0 ) hingga ( x = 3 ) diputar terhadap sumbu-x.', '', 'Volume = \\( 27\\pi \\)', 'Volume = \\( 18\\pi \\)', 'Volume = \\( 36\\pi \\)', 'Volume = \\( 9\\pi \\)', 'C', '\\[\r\n\\text{Volume} = \\pi \\int_{a}^{b} [f(x)]^2 dx\r\n\\]\r\nDengan \\( f(x) = 2x \\Rightarrow [f(x)]^2 = 4x^2 \\)\r\n\r\n\\[\r\nV = \\pi \\int_{0}^{3} 4x^2 dx = 4\\pi \\int_{0}^{3} x^2 dx = 4\\pi \\left[ \\frac{1}{3}x^3 \\right]_0^3 = 4\\pi \\cdot 9 = \\boxed{36\\pi}\r\n\\]\r\n'),
(27, 7, 'Hitunglah volume benda putar yang dihasilkan jika daerah di bawah grafik ( y = 2x ) dari ( x = 0 ) hingga ( x = 3 ) diputar terhadap sumbu-x.', '', 'Volume = \\( 27\\pi \\)', 'Volume = \\( 18\\pi \\)', 'Volume = \\( 36\\pi \\)', 'Volume = \\( 9\\pi \\)', 'C', '\\[\r\n\\text{Volume} = \\pi \\int_{a}^{b} [f(x)]^2 \\, dx\r\n\\]\r\nDengan \\( f(x) = 2x \\Rightarrow [f(x)]^2 = 4x^2 \\)\r\n\r\n\\[\r\nV = \\pi \\int_{0}^{3} 4x^2 \\, dx = 4\\pi \\int_{0}^{3} x^2 \\, dx = 4\\pi \\cdot \\left[ \\frac{1}{3}x^3 \\right]_0^3 = 4\\pi \\cdot 9 = \\boxed{36\\pi}\r\n\\]\r\n'),
(28, 8, 'Hitunglah volume benda putar yang dihasilkan oleh daerah di bawah kurva \\( y = x \\), dari \\( x = 0 \\) hingga \\( x = 3 \\), diputar terhadap sumbu-x!', '', 'Volume = \\( 6\\pi \\)', 'Volume = \\( 12\\pi \\)', 'Volume = \\( 9\\pi \\)', 'Volume = \\( 3\\pi \\)', 'C', '\\[\r\n\\text{Volume} = \\pi \\int_{a}^{b} [f(x)]^2 \\, dx\r\n\\]\r\nDengan \\( f(x) = x \\Rightarrow [f(x)]^2 = x^2 \\)\r\n\r\n\\[\r\nV = \\pi \\int_{0}^{3} x^2 \\, dx = \\pi \\left[ \\frac{1}{3}x^3 \\right]_0^3 = \\pi \\cdot 9 = \\boxed{9\\pi}\r\n\\]\r\n'),
(29, 8, 'Diberikan fungsi \\( y = 2x + 1 \\) dari \\( x = 0 \\) sampai \\( x = 2 \\). Hitunglah volume benda putar terhadap sumbu-x.', '', 'Volume = \\( \\frac{50}{3}\\pi \\)', 'Volume = \\( \\frac{62}{3}\\pi \\)', 'Volume = \\( \\frac{44}{3}\\pi \\)', 'Volume = \\( \\frac{36}{3}\\pi \\)', 'B', '\\[\r\n\\text{Volume} = \\pi \\int_{0}^{2} (2x + 1)^2 \\, dx = \\pi \\int_{0}^{2} (4x^2 + 4x + 1) \\, dx\r\n\\]\r\nHitung masing-masing:\r\n\\[\r\n\\int_0^2 4x^2 dx = \\frac{32}{3}, \\quad \\int_0^2 4x dx = 8, \\quad \\int_0^2 1 dx = 2\r\n\\]\r\n\r\nTotal:\r\n\\[\r\nV = \\pi (\\frac{32}{3} + 8 + 2) = \\pi \\cdot \\frac{62}{3} = \\boxed{\\frac{62}{3}\\pi}\r\n\\]\r\n'),
(30, 8, 'Hitunglah volume benda putar yang dihasilkan oleh daerah di bawah grafik \\( y = 3 \\), dari \\( x = 0 \\) sampai \\( x = 2 \\), diputar terhadap sumbu-x.', '', 'Volume = \\( 18\\pi \\)', 'Volume = \\( 12\\pi \\)', 'Volume = \\( 9\\pi \\)', 'Volume = \\( 6\\pi \\)', 'A', '\\[\r\n\\text{Volume} = \\pi \\int_{0}^{2} (3)^2 \\, dx = \\pi \\int_{0}^{2} 9 \\, dx = 9\\pi \\cdot (2 - 0) = \\boxed{18\\pi}\r\n\\]\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nama` varchar(50) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `nama`, `kelas`, `role`) VALUES
(1, '1062460', '1062460', 'zaskia', '', 'admin'),
(96, '1062432', '1062432', 'agus', '1 TRPL B', 'Mahasiswa'),
(97, '1062433', '1062433', 'alief', '1 TRPL B', 'Mahasiswa'),
(101, '1062459', '1062459', 'Vivi Apriyanti', '1 TRPL A', 'Mahasiswa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`iddosen`);

--
-- Indexes for table `latihansoal`
--
ALTER TABLE `latihansoal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`id_level`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`idmhs`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quizsoal`
--
ALTER TABLE `quizsoal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `soal_level`
--
ALTER TABLE `soal_level`
  ADD PRIMARY KEY (`id_soal_level`),
  ADD KEY `id_level` (`id_level`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dosen`
--
ALTER TABLE `dosen`
  MODIFY `iddosen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1062573;

--
-- AUTO_INCREMENT for table `latihansoal`
--
ALTER TABLE `latihansoal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `id_level` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `idmhs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `quizsoal`
--
ALTER TABLE `quizsoal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `soal_level`
--
ALTER TABLE `soal_level`
  MODIFY `id_soal_level` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
